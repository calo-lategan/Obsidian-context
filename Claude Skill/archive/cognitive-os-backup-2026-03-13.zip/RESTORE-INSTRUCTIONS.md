# Cowork Cognitive OS Backup — Restore Guide

## Contents

| Folder | What |
|---|---|
| `skills/onstart-onthinking/` | Omega-AGI-v4 cognitive OS skill (mandatory on every response) |
| `skills/advanced-research-methodology/` | Deep research methodology skill (AES, DAFx, arXiv, patents, multi-language) |
| `plugins/omega-agi-cognitive-os/` | Omega-AGI plugin (wraps the onstart-onthinking skill as installable plugin) |
| `global-instructions/CLAUDE.md` | Global directives enforcing the cognitive protocol |

## Restore on New Desktop

### 1. Skills → `Documents/Claude/Skills/skills/`
Copy both folders from `skills/` into:
- **Windows**: `C:\Users\<YOU>\Documents\Claude\Skills\skills\`
- **macOS**: `~/Documents/Claude/Skills/skills/`

### 2. Plugin → Local Plugin Marketplace
Copy `plugins/omega-agi-cognitive-os/` into:
- **Windows**: `C:\Users\<YOU>\Documents\Claude\.local-plugins\marketplaces\local-desktop-app-uploads\omega-agi-cognitive-os\`
- **macOS**: `~/Documents/Claude/.local-plugins/marketplaces/local-desktop-app-uploads/omega-agi-cognitive-os/`

Or zip it as a `.plugin` file and install via the Cowork plugin installer.

### 3. Global Instructions → `.claude/CLAUDE.md`
Copy `global-instructions/CLAUDE.md` to:
- **Windows**: `C:\Users\<YOU>\Documents\Claude\.claude\CLAUDE.md`
- **macOS**: `~/Documents/Claude/.claude/CLAUDE.md`

This ensures the cognitive protocol loads on every response automatically.
