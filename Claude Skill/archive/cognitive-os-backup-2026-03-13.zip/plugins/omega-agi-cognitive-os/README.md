# Omega-AGI-v4 Cognitive OS

Master cognitive protocol that governs all reasoning, planning, execution, memory, and self-evolution across every Claude response.

## Components

| Component | Type | Purpose |
|-----------|------|---------|
| `onstart-onthinking` | Skill | Full Omega-AGI-v4 protocol — cyclical cognition, elastic token economics, adaptive planning, memory banks, agentic orchestration, self-evolution, and execution laws |

## Setup

Install the plugin, then add the following to your `.claude/CLAUDE.md` to enforce mandatory loading:

```markdown
## MANDATORY COGNITIVE PROTOCOL

The `onstart-onthinking` skill is **always active**. Before any response, the Omega-AGI-v4 cognitive OS is already running.

## Response Quality Laws

1. Zero conversational filler
2. No pre-execution narration
3. Parallel tool calls always
4. Token economy — every word earns its place
5. Chain-of-Draft in Execution mode
```

## What It Does

- **Phase 0**: Contextual initialization, mode vector determination, skill loading, zero-shot research
- **Phase 1**: Elastic token economics, Markovian context folding, dual-layer compression
- **Phase 2**: Adaptive Chain-of-Draft, elastic Tree-of-Thoughts with shadow pool, ambiguity preservation
- **Phase 3**: Long-horizon memory banks, second-order simulation, git-like state management
- **Phase 4**: Agentic orchestration, cognitive diversity injection, structured tool outputs
- **Phase 5**: In-situ optimization (CLIO reflex), root cause analysis, skill generation
- **Phase 6**: Parallelism laws, token laws, contextual quality enforcement
