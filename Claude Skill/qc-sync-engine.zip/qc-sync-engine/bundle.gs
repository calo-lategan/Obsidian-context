/*
================================================================================
ALLOWED APIS — every call this project may make
(verified against developers.google.com/apps-script/advanced/drive — Apr 2026)
--------------------------------------------------------------------------------
Drive.Files.get(fileId, {supportsAllDrives:true, fields:'id,name,parents,mimeType,md5Checksum,modifiedTime,size'})
Drive.Files.list({q, corpora:'allDrives', includeItemsFromAllDrives:true, supportsAllDrives:true, pageSize, pageToken, fields, orderBy:'modifiedTime desc'})
Drive.Files.create({name, parents, mimeType}, blob, {supportsAllDrives:true, fields:'id,name,parents'})
Drive.Files.update(fileMeta, fileId, blob, {supportsAllDrives:true, addParents, removeParents, fields})
Drive.Files.remove(fileId, {supportsAllDrives:true})         // trashes (does NOT hard-delete)
Drive.Files.copy({name, parents}, fileId, {supportsAllDrives:true, fields:'id,name,parents'})
Drive.Files.watch({id, type:'web_hook', address, expiration}, fileId, {supportsAllDrives:true})
Drive.Channels.stop({id, resourceId})

SpreadsheetApp:
  Sheet.getRange(r,c,nr,nc).getValues()         // ONE call per tab at context-build
  Sheet.getRange(r,c,nr,nc).getBackgrounds()    // ONE call per tab at context-build
  Sheet.getRange(r,c,nr,nc).setValues(v2d)      // ONE call per dirty tab at flush
  Sheet.getRange(r,c,nr,nc).setBackgrounds(bg)  // ONE call per dirty tab at flush
  Sheet.getRange(r,c,nr,nc).setWrapStrategy(SpreadsheetApp.WrapStrategy.CLIP)
  SpreadsheetApp.getActiveSpreadsheet().toast(msg, title, secs)

PropertiesService.getScriptProperties().{get,set,delete,deleteAll}Property(...)
PropertiesService.getScriptProperties().getProperties()  // one call, cached

Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, str, Utilities.Charset.UTF_8)
Utilities.base64Decode / base64Encode
Utilities.newBlob / blob.getBytes()

UrlFetchApp.fetch(url, {method, headers, payload, muteHttpExceptions:true})  // 30s cap
UrlFetchApp.fetchAll([{url, headers, muteHttpExceptions:true}, ...])       // parallel batch

ScriptApp.newTrigger('resumeSync').timeBased().after(60_000).create()
ScriptApp.getProjectTriggers() -> filter -> deleteTrigger
ScriptApp.getScriptId()

LockService.getScriptLock().tryLock(0)  // non-blocking; abort if another sync active

ANTI-PATTERNS (WILL BREAK SHARED DRIVES OR QUOTAS):
  DriveApp.*                          - does NOT support Shared Drives reliably
  Drive.Files.create() without parents in Shared Drive
  Drive.Files.* without supportsAllDrives:true
  range.setValue / range.setBackground  - 30-50x slower than batch
  for-row getValue loops               - blows execution time budget
  OCR / Drive.Files.export(mimeType:'text/plain')  - NOT the PDF text layer
  Blocking LockService.waitLock(ms)    - use tryLock(0) and bail
  installTrigger created INSIDE long-running loop (counts against limit)
================================================================================
*/

// ============================ IDENTIFIERS ===================================
const SHEET_ID            = '1G1mP78mIpVpddiWkut-d2Br04RaXTf5PW-VnIS3ayOA';
const SOURCE_FOLDER_ID    = '1CgZ2q64X4kOgVkOxLcEbsSeH9AJbbFiU';   // 33-char canonical
const WORKSPACE_NAME      = '_QC_Workspace';
const ACTIVE_FOLDER_NAME  = 'Active';
const ARCHIVE_FOLDER_NAME = 'Archive';
const DIAGNOSTIC_TAB      = '_Diagnostic';
const LOGS_TAB            = '_Logs';

// ============================ COLORS =========================================
// The engine OWNS these two — paints them and may freely repaint over them.
const COLOR_DEFECT        = '#ff9999';   // engine red — defective checkbox cell
const COLOR_NO_INSPECTION = '#ffd966';   // engine orange — no PDF for this plant

// Whitelist of backgrounds the engine treats as "safe to overwrite".
// Anything ELSE on a row marks the row as user-managed -> SKIP entire row.
// Includes #b7e1cd because that is the legacy "passed inspection" green that
// already covers ~280 rows in the live sheet — without it, every existing
// checked row would be flagged as user-highlighted and skipped.
const ENGINE_OWNED_COLORS = new Set([
  '',
  '#ffffff',
  null,
  COLOR_DEFECT,
  COLOR_NO_INSPECTION,
  '#b7e1cd'                              // legacy green check — must be whitelisted
]);

// Colors observed in the wild that MUST trigger user-highlight skip:
//   #ff0000  - Ablution critical (e.g. "Door cylinder needs to be replaced")
//   #4a86e8  - Ablution scrap/decommissioned
//   #ffff00  - Cabins/Shower unit user review marker (1100+ cells on Cabins)
// Anything not in ENGINE_OWNED_COLORS triggers skip - no enumeration needed.

// ============================ EXECUTION LIMITS ==============================
const EXEC_SOFT_CAP_MS           = 4 * 60 * 1000 + 30 * 1000;  // 4:30 - bail
const LOCK_TIMEOUT_MS            = 0;                           // non-blocking
const INSURANCE_TRIGGER_DELAY_MS = 60 * 1000;                   // 60s after bail
const FETCH_BATCH_SIZE           = 50;                           // fetchAll concurrency cap

// ============================ FILENAME PARSING ==============================
// Permissive: any combination of letters/digits/dots/underscores/hyphens for the
// plant ID, then `-YYMMDD ` then any check-type then optional ` (N)` browser
// duplicate marker then `.pdf`. Validation that the plant exists in a tab
// happens AFTER extraction, not in the regex.
//
// Verified against the 22 real PDFs in the source folder + the local test PDF:
//   ABL.F.40.01-260404 POST PDI.pdf
//   ABL.F.40.01-260404 POST PDI (1).pdf      <- tolerated
//   DR.2.T.32.9-260407 POST PDI.pdf
//   DR.2T.40.01-260407 POST PDI.pdf          <- typo: missing dot - accepted
//   DR.2.TS.32.5-260404 POST PDI.pdf
//   PB-260403 POST PDI.pdf                   <- bare 2-letter - accepted, routed by lookup
//   STC.20.6-260331 POST PDI.pdf
//   PL.107-260330 POST PDI.pdf
const FILENAME_RX = /^\s*([A-Z0-9._-]+?)-(\d{6})\s+(.+?)(?:\s*\(\d+\))?\.pdf$/i;

// ============================ PLANT -> TAB ROUTING ==========================
// Used ONLY when an unknown plant arrives via PDF and the engine needs to
// decide which tab to insert it into. The first-pass resolver scans every
// in-scope tab's column D for an exact match BEFORE falling through to this
// table — these rules only apply to brand-new plants.
//
// Order matters: longest/most-specific prefix MUST come first to prevent
// short prefixes from swallowing long ones (e.g. FLX.* must beat SHC.*
// when matching FLX.SHC.* filenames).
const PREFIX_RULES = [
  { rx: /^FLX\./i,        tab: 'Flexiloo'    },   // beats SHC fallback inside FLX.SHC.*
  { rx: /^DA\.PL\./i,     tab: 'Portaloo'    },
  { rx: /^PL\./i,         tab: 'Portaloo'    },
  { rx: /^DR\.2T?\./i,    tab: 'DRS'         },   // tolerates DR.2T.* typo
  { rx: /^4DR\.ABL\./i,   tab: 'Ablution'    },
  { rx: /^D\.ABL\./i,     tab: 'Ablution'    },
  { rx: /^VIPABL/i,       tab: 'Ablution'    },
  { rx: /^ABL\./i,        tab: 'Ablution'    },
  { rx: /^SHC\./i,        tab: 'Shower unit' },
  { rx: /^MH\./i,         tab: 'Messhall'    },
  { rx: /^TB\./i,         tab: 'Cabins'      },
  { rx: /^OPO\./i,        tab: 'Cabins'      },
  { rx: /^STC\./i,        tab: 'Cabins'      },
  { rx: /^F\.P\.O\./i,    tab: 'Flatpack'    }
];

// In-scope tabs. Anything else (EZGO, Clubcar, Polaris, Kawasaki, Summary,
// New Flatpack, NEW Flexiloos) is OUT OF SCOPE - engine never reads from
// or writes to those tabs.
const IN_SCOPE_TABS = ['DRS','Ablution','Shower unit','Messhall','Cabins','Flatpack','Flexiloo','Portaloo'];

// ============================ COMMENTS COLUMN OVERRIDE ======================
// Most tabs have a header literally named "Comments". Shower unit doesn't -
// it uses "STATUS" as the catch-all column. Engine consults this map first,
// then falls back to scanning row 1 for /^comments?$/i.
const COMMENTS_HEADER_BY_TAB = {
  'Shower unit': 'STATUS'
};

// ============================ MANUAL-ONLY COLUMNS ===========================
// Headers the engine NEVER writes to - reserved for human input only.
// Case-insensitive match.
const MANUAL_ONLY_HEADERS = new Set([
  'Door keys',
  'Keys',
  'Notes'
]);

// ============================ SHEET <- PDF MAPPING ==========================
// SHEET_TO_PDF[tab][sheetHeader] = [pdfLabel1, pdfLabel2, ...]
//
// For a sheet checkbox to become TRUE, EVERY listed pdfLabel must be ✅ (or N/A).
// If ANY listed label is ❌, the sheet cell becomes FALSE + painted red.
// Labels are matched case-insensitive against the parsed PDF item label.
//
// PDF items NOT listed for any sheet header are silently ignored - they are
// "extra" inspection items the form tracks but the sheet doesn't aggregate.
//
// ALIASES tolerate the typos and casing differences observed in real data:
//   "Wash Besin" (PDF) <-> "Washbasin" (sheet)
//   "Light"      (PDF) <-> "Lights"    (sheet)
//   "Floor"      (PDF) <-> "Flooring"  (sheet)
//
// Mappings below are seeded from the ABL.F.40.01 PDF + DRS sheet inspection.
// Other tabs reuse the same PDF item vocabulary the inspectors fill in;
// extend as more PDF samples arrive.
const SHEET_TO_PDF = {

  Ablution: {
    'Flooring':       ['floor'],
    'Walls':          ['structural damage', 'interior damage', 'exterior damage'],
    'Ceiling':        ['structural damage', 'interior damage', 'exterior damage'],
    'Window':         ['window'],
    'WC':             ['wc', 'wc seat cover'],
    'Urinal':         ['urinal'],
    'Interior paint': ['interior paint'],
    'exterior paint': ['exterior paint'],
    'Mirror':         ['mirror'],
    'Washbasin':      ['wash besin', 'water taps'],
    'Lights':         ['light'],
    'Exhaust Fan':    ['exhaust fan'],
    'Door':           ['door']
  },

  DRS: {
    'Flooring':       ['floor'],
    'Walls':          ['structural damage', 'interior damage', 'exterior damage'],
    'Ceiling':        ['structural damage', 'interior damage', 'exterior damage'],
    'Fittings':       ['fittings'],
    'Mirror':         ['mirror'],
    'Washbasin':      ['wash besin', 'water taps'],
    'Toilet':         ['wc', 'wc seat cover'],
    'Door':           ['door'],
    'Shower':         ['shower'],
    'Lights':         ['light'],
    'Windows':        ['window'],
    'Interior paint': ['interior paint'],
    'Exterior paint': ['exterior paint'],
    'ACs':            ['ac']
  },

  'Shower unit': {
    'Flooring':       ['floor'],
    'Walls':          ['structural damage', 'interior damage', 'exterior damage'],
    'Ceiling':        ['structural damage', 'interior damage', 'exterior damage'],
    'Fittings':       ['fittings'],
    'Mirror':         ['mirror'],
    'Washbasin':      ['wash besin', 'water taps'],
    'Lights':         ['light'],
    'Shower':         ['shower'],
    'Shower Curtain': ['shower curtain'],
    'AC':             ['ac'],
    'DOORS':          ['door'],
    'ELECTRICAL':     ['electrical'],
    'WC':             ['wc', 'wc seat cover'],
    'Intrior paint':  ['interior paint'],     // sheet typo preserved
    'exterior paint': ['exterior paint']
  },

  Messhall: {
    'Flooring':       ['floor'],
    'Walls':          ['structural damage', 'interior damage', 'exterior damage'],
    'Ceiling':        ['structural damage', 'interior damage', 'exterior damage'],
    'Fittings':       ['fittings'],
    'AC':             ['ac'],
    'Window Tint':    ['window tint'],
    'Roof':           ['roof'],
    'Lights':         ['light'],
    'Door':           ['door']
  },

  Cabins: {
    'Flooring':       ['floor'],
    'Walls':          ['structural damage', 'interior damage', 'exterior damage'],
    'Ceiling':        ['structural damage', 'interior damage', 'exterior damage'],
    'Interior paint': ['interior paint'],
    'Exterior paint': ['exterior paint'],
    'AC':             ['ac'],
    'Window':         ['window'],
    'Blinds':         ['blinds'],
    'Lights':         ['light'],
    'Door':           ['door']
  },

  Flatpack: {
    'Flooring':       ['floor'],
    'Walls':          ['structural damage', 'interior damage', 'exterior damage'],
    'Ceiling':        ['structural damage', 'interior damage', 'exterior damage'],
    'AC':             ['ac'],
    'Lights':         ['light']
  },

  Flexiloo: {
    'Flooring':       ['floor'],
    'Counter tops':   ['counter tops', 'counter'],
    'Lights':         ['light'],
    'Mirror':         ['mirror'],
    'Fittings':       ['fittings'],
    'Ceilings':       ['structural damage', 'interior damage', 'exterior damage'],
    'Walls':          ['structural damage', 'interior damage', 'exterior damage'],
    'Doors':          ['door'],
    'WC / urinal':    ['wc', 'urinal'],
    'Basin':          ['wash besin', 'water taps']
  },

  Portaloo: {
    'Interior fittings': ['interior fittings', 'fittings', 'wash besin', 'water taps', 'mirror'],
    'Flush lever':       ['flush lever', 'flush', 'wc'],
    'Door lock':         ['door lock', 'door'],
    'Branding':          ['branding decal', 'branding']
  }
};

// ============================ CACHE KEYS ====================================
const CK_DRIFT  = 'driftCache';   // single JSON blob: { plantNo: {fid, rh, ts} }
const CK_RESUME = 'resume:state';
const CK_WATCH  = 'watch:channel';
/**
 * Persistent error/info log tab inside the active spreadsheet.
 * Falls back silently if the sheet can't be reached.
 */

function logError_(fnName, err) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sh = ss.getSheetByName(LOGS_TAB);
    if (!sh) {
      sh = ss.insertSheet(LOGS_TAB);
      sh.getRange(1, 1, 1, 4).setValues([['Timestamp', 'Function', 'Message', 'Stack']]);
      sh.setFrozenRows(1);
      sh.setColumnWidths(1, 1, 160);
      sh.setColumnWidths(2, 1, 180);
      sh.setColumnWidths(3, 1, 480);
      sh.setColumnWidths(4, 1, 540);
    }
    sh.appendRow([
      new Date(),
      String(fnName),
      String((err && err.message) || err || ''),
      String((err && err.stack) || '').slice(0, 800)
    ]);
  } catch (_) {
    // never let logging itself crash a sync
  }
}

function logInfo_(fnName, msg) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sh = ss.getSheetByName(LOGS_TAB);
    if (!sh) {
      sh = ss.insertSheet(LOGS_TAB);
      sh.getRange(1, 1, 1, 4).setValues([['Timestamp', 'Function', 'Message', 'Stack']]);
      sh.setFrozenRows(1);
    }
    sh.appendRow([new Date(), String(fnName), String(msg), '']);
  } catch (_) {
    // ignore
  }
}

function openLogsTab() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(LOGS_TAB);
  if (!sh) sh = ss.insertSheet(LOGS_TAB);
  ss.setActiveSheet(sh);
}
/**
 * Single source of truth for every Drive API v3 call in the project.
 * Every other file MUST go through these wrappers — no raw Drive.Files.*
 * calls elsewhere. This prevents the supportsAllDrives footgun from
 * silently breaking Shared Drive operations.
 *
 * The source folder lives on a Shared Drive, so every list/get/copy/update/
 * remove/watch call MUST pass `supportsAllDrives: true` (and listing requires
 * `corpora: 'allDrives'` + `includeItemsFromAllDrives: true`).
 */

const DRIVE_OPTS = { supportsAllDrives: true };
const LIST_OPTS  = {
  corpora: 'allDrives',
  includeItemsFromAllDrives: true,
  supportsAllDrives: true
};

function drv_get_(id, fields) {
  return Drive.Files.get(id, Object.assign({
    fields: fields || 'id,name,parents,mimeType,md5Checksum,modifiedTime,size'
  }, DRIVE_OPTS));
}

function drv_listInFolder_(folderId, extraQ) {
  const results = [];
  const q = `'${folderId}' in parents and trashed = false` + (extraQ ? ' and ' + extraQ : '');
  let pageToken = null;
  do {
    const r = Drive.Files.list(Object.assign({
      q,
      pageSize: 1000,
      pageToken,
      fields: 'nextPageToken,files(id,name,parents,mimeType,md5Checksum,modifiedTime,size)',
      orderBy: 'modifiedTime desc'
    }, LIST_OPTS));
    if (r.files) for (const f of r.files) results.push(f);
    pageToken = r.nextPageToken;
  } while (pageToken);
  return results;
}

function drv_findOrCreateFolder_(parentId, name) {
  const safe = name.replace(/'/g, "\\'");
  const existing = drv_listInFolder_(
    parentId,
    `mimeType = 'application/vnd.google-apps.folder' and name = '${safe}'`
  );
  if (existing.length) return existing[0].id;
  const created = Drive.Files.create({
    name,
    parents: [parentId],
    mimeType: 'application/vnd.google-apps.folder'
  }, null, Object.assign({ fields: 'id' }, DRIVE_OPTS));
  return created.id;
}

function drv_copy_(srcFileId, newName, destFolderId) {
  return Drive.Files.copy(
    { name: newName, parents: [destFolderId] },
    srcFileId,
    Object.assign({ fields: 'id,name,parents,modifiedTime' }, DRIVE_OPTS)
  );
}

function drv_move_(fileId, oldParentId, newParentId, newName) {
  const body = newName ? { name: newName } : {};
  return Drive.Files.update(body, fileId, null, Object.assign({
    addParents: newParentId,
    removeParents: oldParentId,
    fields: 'id,name,parents'
  }, DRIVE_OPTS));
}

function drv_trash_(fileId) {
  return Drive.Files.remove(fileId, DRIVE_OPTS);
}

/**
 * Download raw bytes of a binary file (PDF). Apps Script's Drive Advanced
 * Service does NOT expose binary download — we must call the REST endpoint
 * directly with alt=media and an OAuth bearer token.
 */
function drv_blob_(fileId) {
  const url = 'https://www.googleapis.com/drive/v3/files/' +
              encodeURIComponent(fileId) +
              '?alt=media&supportsAllDrives=true';
  const resp = UrlFetchApp.fetch(url, {
    headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() },
    muteHttpExceptions: true
  });
  const code = resp.getResponseCode();
  if (code !== 200) {
    throw new Error('drv_blob_ ' + fileId + ': HTTP ' + code + ' ' + resp.getContentText().slice(0, 200));
  }
  return resp.getBlob().setName(fileId + '.pdf');
}

/**
 * Batch-download PDF blobs using UrlFetchApp.fetchAll() for parallelism.
 * Batches in groups of FETCH_BATCH_SIZE to stay within rate limits.
 *
 * @param {string[]} fileIds  array of Drive file IDs
 * @return {Object<string, Blob>}  { fileId: Blob } — failed downloads omitted
 */
function drv_blobBatch_(fileIds) {
  if (!fileIds.length) return {};
  const token = ScriptApp.getOAuthToken();
  const results = {};

  for (let i = 0; i < fileIds.length; i += FETCH_BATCH_SIZE) {
    const batchIds = fileIds.slice(i, i + FETCH_BATCH_SIZE);
    const requests = batchIds.map(function(fid) {
      return {
        url: 'https://www.googleapis.com/drive/v3/files/' +
             encodeURIComponent(fid) + '?alt=media&supportsAllDrives=true',
        headers: { Authorization: 'Bearer ' + token },
        muteHttpExceptions: true
      };
    });
    const resps = UrlFetchApp.fetchAll(requests);
    for (let j = 0; j < resps.length; j++) {
      if (resps[j].getResponseCode() === 200) {
        results[batchIds[j]] = resps[j].getBlob().setName(batchIds[j] + '.pdf');
      } else {
        logError_('drv_blobBatch_', 'HTTP ' + resps[j].getResponseCode() + ' for ' + batchIds[j]);
      }
    }
  }
  return results;
}
/**
 * Drift cache: { plantNo: { fid, rh, ts } }
 *   fid = active mirror file ID
 *   rh  = MD5 hash of the engine-owned columns of the row
 *   ts  = last write timestamp (ms)
 *
 * Stored as ONE JSON blob under script property `driftCache` to avoid
 * the 500KB-per-property limit on large fleets. Cache is loaded once per
 * sync, mutated in-memory, and written back at the end.
 *
 * The hash uses ONLY the columns the engine owns (checkboxes + comments) —
 * manual-only columns and the plant-no column are excluded so human edits
 * to those don't trigger false drift.
 */

function readDriftCache_() {
  const raw = PropertiesService.getScriptProperties().getProperty(CK_DRIFT);
  if (!raw) return {};
  try { return JSON.parse(raw); } catch (_) { return {}; }
}

function writeDriftCache_(obj) {
  PropertiesService.getScriptProperties().setProperty(CK_DRIFT, JSON.stringify(obj));
}

function clearDriftCache_() {
  PropertiesService.getScriptProperties().deleteProperty(CK_DRIFT);
}

/**
 * Hash the engine-owned columns of a plant's row. Excludes the plant-no
 * column and any MANUAL_ONLY_HEADERS.
 */
function hashRow_(ctx, plantNo) {
  const rowIdx = ctx.plantRow[String(plantNo).trim().toUpperCase()];
  if (!rowIdx) return '';
  const row = ctx.values[rowIdx - 1];
  const parts = [];
  for (const hdr in ctx.headerIdx) {
    if (isManualOnlyHeader_(hdr)) continue;
    if (/^plant\s*(no|number|#)?\.?$/i.test(hdr)) continue;
    const c = ctx.headerIdx[hdr];
    parts.push(hdr + '=' + String(row[c - 1]));
  }
  const joined = parts.join('|');
  const digest = Utilities.computeDigest(
    Utilities.DigestAlgorithm.MD5,
    joined,
    Utilities.Charset.UTF_8
  );
  let hex = '';
  for (let i = 0; i < digest.length; i++) {
    const b = digest[i] < 0 ? digest[i] + 256 : digest[i];
    hex += b.toString(16).padStart(2, '0');
  }
  return hex;
}
/**
 * In-memory tab context for batched I/O.
 *
 * One getValues + one getBackgrounds per tab at build time. All mutation
 * happens to the in-memory 2D arrays. flushContext_() does ONE setValues +
 * ONE setBackgrounds per dirty tab. This is ~30-50x faster than per-cell
 * writes against a 200+ row tab.
 */

/**
 * Find the 1-indexed column whose row-1 header looks like a Plant No.
 * Accepts: "Plant No.", "Plant No", "Plant Number", "Plant#", case-insensitive.
 */
function plantNoColIdx_(sheet) {
  const lastCol = sheet.getLastColumn();
  if (lastCol < 1) return -1;
  const hdr = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  for (let i = 0; i < hdr.length; i++) {
    if (/^\s*plant\s*(?:no|#|number)?\.?\s*$/i.test(String(hdr[i] || ''))) return i + 1;
  }
  return -1;
}

/**
 * Map of header text -> 1-indexed column. Trims whitespace, preserves case.
 */
function buildHeaderIdx_(headersRow) {
  const idx = {};
  for (let i = 0; i < headersRow.length; i++) {
    const h = String(headersRow[i] || '').trim();
    if (h) idx[h] = i + 1;
  }
  return idx;
}

/**
 * Find the comments column for a given tab.
 *   1) Per-tab override from COMMENTS_HEADER_BY_TAB (e.g. Shower unit -> STATUS)
 *   2) First header matching /^comments?$/i
 * Returns -1 if neither matches.
 */
function commentsColForTab_(headerIdx, tabName) {
  const override = COMMENTS_HEADER_BY_TAB[tabName];
  if (override && headerIdx[override]) return headerIdx[override];
  for (const h in headerIdx) {
    if (/^comments?$/i.test(h)) return headerIdx[h];
  }
  return -1;
}

/**
 * Build the full in-memory context for one tab.
 *
 * @return {{
 *   sheet, tabName,
 *   values:       string[][],   // [row][col], 0-indexed in array but row 0 is header row
 *   bgs:          string[][],
 *   headerIdx:    Object<string, number>,   // header -> 1-indexed col
 *   plantCol:     number,                   // 1-indexed
 *   commentsCol:  number,                   // 1-indexed, -1 if none
 *   plantRow:     Object<string, number>,   // PLANTNO (uppercase, trimmed) -> 1-indexed row
 *   dirtyValues:  boolean,
 *   dirtyBgs:     boolean,
 *   mutatedRows:  Set<number>                // 1-indexed rows touched
 * }}
 */
function buildTabContext_(sheet) {
  const tabName = sheet.getName();
  const lastRow = sheet.getLastRow();
  const lastCol = sheet.getLastColumn();
  if (lastRow < 2 || lastCol < 1) return null;

  const range  = sheet.getRange(1, 1, lastRow, lastCol);
  const values = range.getValues();
  const bgs    = range.getBackgrounds();

  const headerIdx = buildHeaderIdx_(values[0]);
  const plantCol = plantNoColIdx_(sheet);
  if (plantCol < 0) return null;

  const commentsCol = commentsColForTab_(headerIdx, tabName);

  const plantRow = {};
  for (let r = 1; r < values.length; r++) {
    const p = String(values[r][plantCol - 1] || '').trim().toUpperCase();
    if (p) plantRow[p] = r + 1;
  }

  return {
    sheet, tabName, values, bgs,
    headerIdx, plantCol, commentsCol, plantRow,
    dirtyValues: false,
    dirtyBgs: false,
    mutatedRows: new Set()
  };
}

/**
 * Returns true if ANY cell on the row has a background color outside the
 * engine-owned whitelist. Engine-owned colors include the legacy #b7e1cd
 * green check from prior data — without that whitelist entry every existing
 * row gets flagged as user-managed.
 */
function isUserHighlighted_(ctx, rowIdx1Based) {
  const row = ctx.bgs[rowIdx1Based - 1];
  if (!row) return false;
  for (let c = 0; c < row.length; c++) {
    const bg = String(row[c] || '').toLowerCase();
    if (!ENGINE_OWNED_COLORS.has(bg)) return true;
  }
  return false;
}

/**
 * Returns true if the given header is in the manual-only set (case-insensitive).
 */
function isManualOnlyHeader_(headerName) {
  if (!headerName) return false;
  const lc = headerName.toString().trim().toLowerCase();
  for (const h of MANUAL_ONLY_HEADERS) {
    if (h.toLowerCase() === lc) return true;
  }
  return false;
}

/**
 * Flush in-memory mutations to the sheet. ONE setValues + ONE setBackgrounds
 * per dirty tab. Optionally apply CLIP wrap to the comments column on
 * mutated rows so wrapped text doesn't blow up row heights.
 */
function flushContext_(ctx) {
  if (!ctx) return;
  const { sheet, values, bgs, mutatedRows, commentsCol } = ctx;
  const nr = values.length;
  const nc = values[0] ? values[0].length : 0;
  if (!nr || !nc) return;

  const range = sheet.getRange(1, 1, nr, nc);
  if (ctx.dirtyValues) range.setValues(values);
  if (ctx.dirtyBgs)    range.setBackgrounds(bgs);

  if (ctx.dirtyValues && commentsCol > 0 && mutatedRows.size) {
    // Apply CLIP wrap to mutated rows in the comments column, batched.
    const sorted = Array.from(mutatedRows).sort(function (a, b) { return a - b; });
    let runStart = null, runEnd = null;
    const flushRun = function () {
      if (runStart === null) return;
      sheet.getRange(runStart, commentsCol, runEnd - runStart + 1, 1)
           .setWrapStrategy(SpreadsheetApp.WrapStrategy.CLIP);
      runStart = runEnd = null;
    };
    for (const r of sorted) {
      if (runStart === null) { runStart = runEnd = r; }
      else if (r === runEnd + 1) { runEnd = r; }
      else { flushRun(); runStart = runEnd = r; }
    }
    flushRun();
  }
}
/**
 * PDF text-layer parser — NO OCR.
 *
 * The Al Laith QC form is a fillable PDF that embeds its checklist labels
 * and ✅/❌/N/A states as plain Unicode in the content stream. We extract
 * the raw text by mining `(literal) Tj` and `<hex> Tj` operators, then walk
 * the token stream as a state machine to recover {bullet, label, state}
 * triples regardless of the form's 2-column layout.
 *
 * Verified against ABL.F.40.01-260404 POST PDI.pdf with these items:
 *   1 GENERAL    : a Structural Damage ✅, b Plumbing ✅, c AC ✅, d Cleaning ✅
 *   2 EXTERNAL   : a Exterior Damage ✅, b Exterior Paint ❌, c Water Pump Motor ✅
 *   3 INTERNAL   : a Interior Damage ✅, b Interior Paint ✅, c Light ✅, d Floor ✅,
 *                  e Electrical ✅, f Exhaust Fan ✅, g Door ✅, h Window ✅,
 *                  i Fire Extinguisher N/A
 *   4 RESTROOM   : a Wash Besin ✅, b Water Taps ✅, c Hand Soap Dispenser ✅,
 *                  d Urinal N/A, e WC ✅, f WC Seat Cover ✅, g Tissue Holder ✅,
 *                  h Mirror ✅
 */

/**
 * Extract every text literal from a PDF blob, preserving Unicode (so emoji
 * tokens survive).
 *
 * @param {Blob} blob
 * @return {string} concatenated text, items separated by single spaces
 */
function extractPdfText_(blob) {
  const bytes = blob.getBytes();
  // Decode bytes as Latin-1 so every byte is a 1-char string with the same
  // numeric value (preserves binary integrity for the regex pass).
  let raw = '';
  const CHUNK = 32768;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    let s = '';
    const end = Math.min(i + CHUNK, bytes.length);
    for (let j = i; j < end; j++) s += String.fromCharCode(bytes[j] & 0xFF);
    raw += s;
  }

  const out = [];

  // (literal) text strings — used for ASCII labels and ✅❌ tokens
  const litRx = /\(((?:\\.|[^)\\])*)\)\s*(?:Tj|TJ|'|")/g;
  let lm;
  while ((lm = litRx.exec(raw)) !== null) {
    out.push(unescapePdfString_(lm[1]));
  }

  // <hex> strings — used for UTF-16BE encoded text in some PDFs
  const hexRx = /<([0-9A-Fa-f\s]+)>\s*(?:Tj|TJ|'|")/g;
  let hm;
  while ((hm = hexRx.exec(raw)) !== null) {
    const decoded = hexToUtf16BE_(hm[1].replace(/\s/g, ''));
    if (decoded) out.push(decoded);
  }

  return out.join(' ');
}

function unescapePdfString_(s) {
  return s
    .replace(/\\n/g, '\n')
    .replace(/\\r/g, '\r')
    .replace(/\\t/g, '\t')
    .replace(/\\\\/g, '\\')
    .replace(/\\\(/g, '(')
    .replace(/\\\)/g, ')')
    .replace(/\\([0-7]{1,3})/g, function (_, o) { return String.fromCharCode(parseInt(o, 8)); });
}

function hexToUtf16BE_(hex) {
  if (hex.length < 4) return '';
  if (hex.slice(0, 4).toUpperCase() === 'FEFF') hex = hex.slice(4);
  let out = '';
  for (let i = 0; i + 3 < hex.length; i += 4) {
    const cp = parseInt(hex.substr(i, 4), 16);
    if (!isNaN(cp)) out += String.fromCharCode(cp);
  }
  return out;
}

// ============================================================================
// Structured parse — text -> { plantNo, checkDate, inspector, items, note }
// ============================================================================

const STATE_PASS_RX = /^(?:✅|☑|✔|OK|PASS|YES|CHECKED)$/i;
const STATE_FAIL_RX = /^(?:❌|✗|✘|×|FAIL|NO|DEFECT(?:IVE)?)$/i;
const STATE_NA_RX   = /^(?:N\/?A|NOTAPPLICABLE)$/i;

/**
 * @param {string} text   raw text from extractPdfText_
 * @param {string} fallbackPlant  used if the header field is missing
 * @return {{plantNo, checkDate, checkType, inspector, items, note}}
 */
function parseQcText_(text, fallbackPlant) {
  const rec = {
    plantNo: fallbackPlant ? String(fallbackPlant).trim().toUpperCase() : null,
    checkDate: null,
    checkType: null,
    inspector: null,
    items: [],
    note: ''
  };

  // ---- header fields ------------------------------------------------------
  // Plant Number: ABL.F.40.01
  let m = text.match(/Plant\s*Number\s*[:\-]\s*([A-Z0-9._/\\-]+)/i);
  if (m) rec.plantNo = m[1].trim().toUpperCase();

  // Inspection Date: 04/04/2026 14:19:40   (DD/MM/YYYY HH:MM:SS)
  m = text.match(/Inspection\s*Date\s*[:\-]\s*(\d{1,2})\/(\d{1,2})\/(\d{2,4})/i);
  if (m) {
    let y = m[3];
    if (y.length === 2) y = '20' + y;
    rec.checkDate = y + '-' + String(m[2]).padStart(2, '0') + '-' + String(m[1]).padStart(2, '0');
  }

  // Inspector Name: calo.lategan@allaith.com   (or plain name)
  m = text.match(/Inspector\s*Name\s*[:\-]\s*([^\s].*?)(?:\s+(?:Type|Plant|Description|Inspection|1\s+GENERAL)|$)/i);
  if (m) rec.inspector = m[1].trim();

  // Also check comments text for "inspection by <name>" or "by <name>" —
  // this takes PRIORITY over the header Inspector Name field.
  const byMatch = text.match(/(?:inspection\s+by|by)\s+([A-Za-z][A-Za-z\s.'-]{1,40}?)(?:\s*[-,.|]|\s+(?:unit|needs|condition|ok|good|bad|all|the|check|date|type|plant|1\s+GENERAL)|\s*$)/i);
  if (byMatch) {
    const nameFromComment = byMatch[1].trim();
    if (nameFromComment.length >= 2) rec.inspector = nameFromComment;
  }

  // Type: FEMALE ABLUTION   -> use as checkType fallback
  m = text.match(/Type\s*[:\-]\s*([A-Z][A-Z\s]+?)(?:\s+(?:Plant|Description|Inspector))/i);
  if (m) rec.checkType = m[1].trim();

  // Comments (State Machine Condition): <text>  ... before "All the Inspections"
  m = text.match(/Comments[^:]*:\s*([\s\S]*?)(?:All\s+the\s+Inspections|Engineer\s*Signature|$)/i);
  if (m) rec.note = m[1].replace(/\s+/g, ' ').trim();

  // ---- checklist items ----------------------------------------------------
  // Walk tokens looking for patterns: <bullet-letter> <Capitalized words...> <state>
  // Section headers like "1 GENERAL" or "4 RESTROOM" start with a digit and are
  // skipped because the bullet detector requires a single lowercase letter.
  const tokens = text.split(/\s+/).filter(Boolean);

  let curBullet = null;
  let curLabel  = [];
  const items = [];

  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];

    if (STATE_PASS_RX.test(t) || STATE_FAIL_RX.test(t) || STATE_NA_RX.test(t)) {
      // close current item
      if (curBullet && curLabel.length) {
        const label = curLabel.join(' ').trim();
        const state = STATE_PASS_RX.test(t) ? true
                    : STATE_NA_RX.test(t)   ? 'NA'
                    : false;
        items.push({ bullet: curBullet, label: label.toLowerCase(), state });
      }
      curBullet = null;
      curLabel = [];
      continue;
    }

    // Bullet candidate: single lowercase a-z, AND next token starts with uppercase
    if (/^[a-z]$/.test(t)) {
      const next = tokens[i + 1] || '';
      if (/^[A-Z]/.test(next)) {
        // close any pending item that lost its state somehow
        if (curBullet && curLabel.length) {
          items.push({
            bullet: curBullet,
            label: curLabel.join(' ').trim().toLowerCase(),
            state: null
          });
        }
        curBullet = t;
        curLabel = [];
        continue;
      }
    }

    // Inside a label
    if (curBullet) curLabel.push(t);
  }

  // Filter out null-state and obvious noise (headers).
  rec.items = items.filter(function (it) {
    if (it.state === null) return false;
    if (!it.label || it.label.length < 2 || it.label.length > 60) return false;
    return true;
  });

  return rec;
}
/**
 * Plant -> tab routing and auto-add for unknown plants.
 *
 * Two-pass resolver:
 *   1. Exact lookup: scan every in-scope tab's column D for a trimmed,
 *      uppercased match against the plant ID. This handles 99% of cases
 *      because plants are pre-existing in the sheet.
 *   2. Prefix routing (PREFIX_RULES from Config.gs): only used for brand-new
 *      plants that don't yet exist in any tab.
 */

/**
 * O(1) lookup using a pre-built plant->tab index (from tab contexts).
 * Falls back to PREFIX_RULES for brand-new plants not yet in any tab.
 *
 * @param {string} plantNo
 * @param {Object<string, string>} plantToTab  { PLANT_NO: tabName } built at sync start
 * @return {string|null}
 */
function resolveTab_(plantNo, plantToTab) {
  const norm = String(plantNo || '').trim().toUpperCase();
  if (!norm) return null;
  if (plantToTab[norm]) return plantToTab[norm];
  for (const rule of PREFIX_RULES) {
    if (rule.rx.test(norm)) return rule.tab;
  }
  return null;
}

/**
 * Slow path — scans every tab via Sheet API. Only used for single-plant
 * operations (syncSelected, diagnostics). For bulk sync use resolveTab_().
 *
 * @return {string|null} the tab name that contains this plant, or null if no
 *   prefix rule matches and no tab already has it.
 */
function detectTabForPlant_(plantNo) {
  const norm = String(plantNo || '').trim().toUpperCase();
  if (!norm) return null;

  // Pass 1: exact lookup against every in-scope tab
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  for (const name of IN_SCOPE_TABS) {
    const sh = ss.getSheetByName(name);
    if (!sh) continue;
    const col = plantNoColIdx_(sh);
    if (col < 0) continue;
    const lastRow = sh.getLastRow();
    if (lastRow < 2) continue;
    const vals = sh.getRange(2, col, lastRow - 1, 1).getValues();
    for (const row of vals) {
      const v = String(row[0] || '').trim().toUpperCase();
      if (v === norm) return name;
    }
  }

  // Pass 2: prefix routing
  for (const rule of PREFIX_RULES) {
    if (rule.rx.test(norm)) return rule.tab;
  }

  return null;
}

/**
 * Insert a new row in the context for a plant that doesn't exist yet.
 * Mutates ctx in-place AND grows the underlying sheet by one row so flush
 * can range-write into it.
 */
function addPlantRow_(ctx, plantNo) {
  const nc = ctx.values[0] ? ctx.values[0].length : 0;
  if (!nc) return;
  const newRow = new Array(nc).fill('');
  newRow[ctx.plantCol - 1] = String(plantNo).trim().toUpperCase();
  ctx.values.push(newRow);
  ctx.bgs.push(new Array(nc).fill('#ffffff'));
  const newRowIdx = ctx.values.length;
  ctx.plantRow[String(plantNo).trim().toUpperCase()] = newRowIdx;
  ctx.dirtyValues = true;
  ctx.dirtyBgs = true;
  // Grow the sheet so flush's getRange call doesn't out-of-bounds.
  ctx.sheet.insertRowsAfter(ctx.sheet.getLastRow(), 1);
}
/**
 * Self-healing workspace mirror.
 *
 * SAFETY INVARIANT: the user's source folder (SOURCE_FOLDER_ID) is read-only.
 * The engine NEVER renames, moves, deletes, or modifies files inside it.
 * Everything happens on a mirrored copy in `_QC_Workspace/Active/` (latest)
 * and `_QC_Workspace/Archive/<plant>/` (history).
 *
 * Self-heal: if the user (or another script) deletes a mirror file,
 * mirrorSourceIntoWorkspace_() re-copies it from source on the next run AND
 * clears that plant's drift cache so the row gets fresh data.
 */

/**
 * Ensures _QC_Workspace, Active, Archive folders all exist as siblings of
 * the bound spreadsheet. Idempotent.
 *
 * @return {{workspaceId, activeId, archiveId}}
 */
function ensureWorkspace_() {
  const sheetFile = drv_get_(SHEET_ID, 'id,parents');
  if (!sheetFile.parents || !sheetFile.parents.length) {
    throw new Error('Bound spreadsheet has no parent folder');
  }
  const parent = sheetFile.parents[0];
  const workspaceId = drv_findOrCreateFolder_(parent, WORKSPACE_NAME);
  const activeId    = drv_findOrCreateFolder_(workspaceId, ACTIVE_FOLDER_NAME);
  const archiveId   = drv_findOrCreateFolder_(workspaceId, ARCHIVE_FOLDER_NAME);
  return { workspaceId, activeId, archiveId };
}

function ensurePlantArchive_(archiveId, plantNo) {
  const safe = String(plantNo).replace(/[\\/]/g, '_'); // file-system safe
  return drv_findOrCreateFolder_(archiveId, safe);
}

/**
 * Walk the source folder, mirror missing PDFs into Active/, archive any
 * outdated mirrors when the source has a newer version, and self-heal any
 * mirror that has been deleted.
 *
 * @return {Object<string, {activeFileId, sourceFileId, date, checkType, wasNew, wasUpdate}>}
 *         keyed by plant number (uppercase, trimmed)
 */
function mirrorSourceIntoWorkspace_() {
  const ws = ensureWorkspace_();

  // Pull every PDF from source.
  const srcFiles = drv_listInFolder_(SOURCE_FOLDER_ID, "mimeType = 'application/pdf'");

  // Pick the newest PDF per plant from source (source may have multiple revisions).
  const latestByPlant = {}; // plantNo -> { srcFile, date, checkType }
  for (const f of srcFiles) {
    const m = f.name.match(FILENAME_RX);
    if (!m) continue;
    const plant = m[1].trim().toUpperCase();
    const date = m[2]; // YYMMDD lex-sortable
    if (!latestByPlant[plant] || date > latestByPlant[plant].date) {
      latestByPlant[plant] = { srcFile: f, date, checkType: m[3] };
    }
  }

  // Index existing Active/ mirrors by plant.
  const activeFiles = drv_listInFolder_(ws.activeId, "mimeType = 'application/pdf'");
  const activeByPlant = {};
  for (const f of activeFiles) {
    const mm = f.name.match(/^(.+?)__LATEST\.pdf$/i);
    if (mm) activeByPlant[mm[1].toUpperCase()] = f;
  }

  // Reconcile.
  const outcome = {};
  const cache = readDriftCache_();

  for (const plant in latestByPlant) {
    const { srcFile, date, checkType } = latestByPlant[plant];
    const activeFile = activeByPlant[plant];

    if (!activeFile) {
      // Self-heal: missing mirror -> copy from source AND clear drift cache.
      const copied = drv_copy_(srcFile.id, plant.replace(/[\\/]/g, '_') + '__LATEST.pdf', ws.activeId);
      delete cache[plant];
      outcome[plant] = {
        activeFileId: copied.id,
        sourceFileId: srcFile.id,
        date, checkType,
        wasNew: true
      };
    } else {
      // If source is newer, archive the current mirror and recopy.
      if (new Date(srcFile.modifiedTime) > new Date(activeFile.modifiedTime)) {
        const plantArchive = ensurePlantArchive_(ws.archiveId, plant);
        const ts = Utilities.formatDate(new Date(activeFile.modifiedTime), 'GMT+4', 'yyyyMMdd-HHmmss');
        drv_move_(activeFile.id, ws.activeId, plantArchive, plant.replace(/[\\/]/g, '_') + '__' + ts + '.pdf');
        const recopied = drv_copy_(srcFile.id, plant.replace(/[\\/]/g, '_') + '__LATEST.pdf', ws.activeId);
        delete cache[plant];
        outcome[plant] = {
          activeFileId: recopied.id,
          sourceFileId: srcFile.id,
          date, checkType,
          wasUpdate: true
        };
      } else {
        outcome[plant] = {
          activeFileId: activeFile.id,
          sourceFileId: srcFile.id,
          date, checkType,
          wasUpdate: false
        };
      }
    }
  }

  writeDriftCache_(cache);
  return outcome;
}
/**
 * Sync engine core.
 *
 * Apply a parsed PDF record to an in-memory tab context using SHEET_TO_PDF
 * mapping. All checkboxes mutate the values 2D array; all paints mutate the
 * bgs 2D array. Flush is one setValues + one setBackgrounds per dirty tab.
 *
 * Invariants:
 *   - User-highlighted rows (anything outside ENGINE_OWNED_COLORS) are skipped
 *     atomically — no value writes, no paint changes, no comments rewrite,
 *     no cache update.
 *   - Manual-only headers (Door keys, Keys, Notes) are NEVER written by the
 *     engine.
 *   - PDF items not mapped in SHEET_TO_PDF[tab] are silently ignored. They
 *     are extra inspection items the form tracks but the sheet doesn't.
 *   - For a sheet checkbox to become TRUE, EVERY mapped PDF item must be ✅
 *     or N/A. If ANY is ❌, the sheet cell becomes FALSE + painted red.
 */

// ============================ ENTRY POINTS ==================================

function syncAll() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(LOCK_TIMEOUT_MS)) {
    SpreadsheetApp.getActiveSpreadsheet().toast('Another sync in progress', 'QC Sync', 4);
    return;
  }
  try {
    _syncCore_({ force: false, plantFilter: null });
  } catch (err) {
    logError_('syncAll', err);
    throw err;
  } finally {
    lock.releaseLock();
  }
}

function forceFullResync() {
  clearDriftCache_();
  clearResumeState_();
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(LOCK_TIMEOUT_MS)) {
    SpreadsheetApp.getActiveSpreadsheet().toast('Another sync in progress', 'QC Sync', 4);
    return;
  }
  try {
    _syncCore_({ force: true, plantFilter: null });
  } catch (err) {
    logError_('forceFullResync', err);
    throw err;
  } finally {
    lock.releaseLock();
  }
}

function syncSelected() {
  const sel = SpreadsheetApp.getActive().getActiveRangeList();
  if (!sel) {
    SpreadsheetApp.getActive().toast('Nothing selected', 'QC Sync', 3);
    return;
  }
  const plants = new Set();
  for (const r of sel.getRanges()) {
    const vals = r.getValues();
    for (const row of vals) {
      for (const cell of row) {
        const s = String(cell || '').trim().toUpperCase();
        // Anything that looks plant-id-shaped: at least 2 chars, only [A-Z0-9._/-]
        if (s.length >= 2 && /^[A-Z0-9._/-]+$/.test(s)) plants.add(s);
      }
    }
  }
  if (!plants.size) {
    SpreadsheetApp.getActive().toast('No plant numbers found in selection', 'QC Sync', 4);
    return;
  }
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(LOCK_TIMEOUT_MS)) return;
  try {
    _syncCore_({ force: true, plantFilter: plants });
  } catch (err) {
    logError_('syncSelected', err);
    throw err;
  } finally {
    lock.releaseLock();
  }
}

// ============================ CORE LOOP =====================================

function _syncCore_(opts) {
  const t0 = Date.now();
  const force = !!(opts && opts.force);
  const plantFilter = opts && opts.plantFilter;
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  // ---- Phase 1: Scan source folder (or reuse cached outcome on resume) ----
  let outcome;
  const resumeState = loadResumeState_();
  if (resumeState && !force && !plantFilter && resumeState.outcome) {
    outcome = resumeState.outcome;
    ss.toast('Resuming: ' + resumeState.queue.length + ' plants remaining', 'QC Sync', 4);
  } else {
    ss.toast('Scanning source folder...', 'QC Sync', 3);
    outcome = mirrorSourceIntoWorkspace_();
  }

  let plants = (resumeState && !force && !plantFilter && resumeState.queue)
    ? resumeState.queue
    : Object.keys(outcome);
  if (plantFilter) plants = plants.filter(function (p) { return plantFilter.has(p); });

  // Pre-queue insurance trigger BEFORE heavy work starts.
  queueInsuranceTrigger_();

  // ---- Phase 2: Eagerly build ALL tab contexts + plant->tab index --------
  ss.toast('Building tab contexts (' + IN_SCOPE_TABS.length + ' tabs)...', 'QC Sync', 2);
  const contextsByTab = {};
  const plantToTab = {};
  for (const tabName of IN_SCOPE_TABS) {
    const sh = ss.getSheetByName(tabName);
    contextsByTab[tabName] = sh ? buildTabContext_(sh) : null;
    if (contextsByTab[tabName]) {
      for (const p in contextsByTab[tabName].plantRow) {
        plantToTab[p] = tabName;
      }
    }
  }

  const cache = readDriftCache_();

  // ---- Phase 3: Filter through drift cache (file ID + date) ---------------
  const toDownload = [];   // { plantNo, fileId, date }
  const skipped = { highlighted: 0, idempotent: 0, noTab: 0, parseFailed: 0, dlFailed: 0 };

  for (const plantNo of plants) {
    const info = outcome[plantNo];
    if (!info) continue;
    const prior = cache[plantNo];
    // Skip only when BOTH file ID AND inspection date match (unchanged PDF).
    if (!force && prior && prior.fid === info.activeFileId && prior.date === info.date) {
      skipped.idempotent++;
      continue;
    }
    toDownload.push({ plantNo: plantNo, fileId: info.activeFileId, date: info.date || '' });
  }

  ss.toast(plants.length + ' plants | ' + skipped.idempotent + ' cached | ' +
           toDownload.length + ' to process', 'QC Sync', 3);

  // ---- Phase 4: Batch-download changed PDFs via fetchAll() ---------------
  const fileIds = toDownload.map(function (d) { return d.fileId; });
  const blobs = drv_blobBatch_(fileIds);

  // ---- Phase 5: Parse + apply -------------------------------------------
  const processed = [];
  let idx = 0;

  for (const dl of toDownload) {
    idx++;
    if (Date.now() - t0 > EXEC_SOFT_CAP_MS) {
      const remaining = toDownload.slice(idx - 1).map(function (d) { return d.plantNo; });
      saveResumeState_(remaining, outcome);
      ss.toast('Paused at ' + (idx - 1) + '/' + toDownload.length + '. Resuming in 60s.', 'QC Sync', 6);
      flushAllContexts_(contextsByTab);
      writeDriftCache_(cache);
      return;
    }

    const plantNo = dl.plantNo;
    const tabName = resolveTab_(plantNo, plantToTab);
    if (!tabName) { skipped.noTab++; continue; }
    const ctx = contextsByTab[tabName];
    if (!ctx) { skipped.noTab++; continue; }

    // Auto-add row if plant not yet present.
    if (!ctx.plantRow[plantNo]) {
      addPlantRow_(ctx, plantNo);
      plantToTab[plantNo] = tabName;
    }

    // Get pre-downloaded blob.
    const blob = blobs[dl.fileId];
    if (!blob) { skipped.dlFailed++; continue; }

    let rec;
    try {
      const text = extractPdfText_(blob);
      rec = parseQcText_(text, plantNo);
    } catch (e) {
      logError_('parse:' + plantNo, e);
      skipped.parseFailed++;
      continue;
    }

    const result = applyRecordToContext_(ctx, tabName, plantNo, rec);
    if (result.skippedHighlight) {
      skipped.highlighted++;
      continue;
    }

    cache[plantNo] = {
      fid: dl.fileId,
      date: rec.checkDate || dl.date || '',
      rh: hashRow_(ctx, plantNo),
      ts: Date.now()
    };
    processed.push(plantNo);

    if (idx % 20 === 0) {
      ss.toast('[' + idx + '/' + toDownload.length + '] ' + plantNo, 'QC Sync', 2);
    }
  }

  flushAllContexts_(contextsByTab);
  writeDriftCache_(cache);
  markNoInspectionPlants_(contextsByTab, Object.keys(outcome));
  clearResumeState_();

  const elapsed = ((Date.now() - t0) / 1000).toFixed(1);
  const summary = 'Done in ' + elapsed + 's | written ' + processed.length +
                  ' | idempotent ' + skipped.idempotent +
                  ' | highlighted ' + skipped.highlighted +
                  ' | no-tab ' + skipped.noTab +
                  ' | parse-fail ' + skipped.parseFailed +
                  ' | dl-fail ' + skipped.dlFailed;
  ss.toast(summary, 'QC Sync', 8);
  logInfo_('_syncCore_', summary);
}

function flushAllContexts_(contextsByTab) {
  for (const tab in contextsByTab) flushContext_(contextsByTab[tab]);
}

// ============================ APPLY RECORD ==================================

/**
 * Mutate ctx in-place with a parsed PDF record for one plant.
 *
 * @return {{written: number, skippedHighlight: boolean, unmatched: string[]}}
 */
function applyRecordToContext_(ctx, tabName, plantNo, rec) {
  const result = { written: 0, skippedHighlight: false, unmatched: [] };
  const rowIdx = ctx.plantRow[plantNo];
  if (!rowIdx) return result;

  if (isUserHighlighted_(ctx, rowIdx)) {
    result.skippedHighlight = true;
    return result;
  }

  // Index the parsed items by lowercased label for fast lookup.
  const itemByLabel = {};
  for (const it of rec.items) {
    itemByLabel[it.label] = it;
  }

  const sheetMap = SHEET_TO_PDF[tabName] || {};
  const defectLabels = [];

  for (const sheetHeader in sheetMap) {
    const col = ctx.headerIdx[sheetHeader];
    if (!col) continue;
    if (isManualOnlyHeader_(sheetHeader)) continue;

    const requiredLabels = sheetMap[sheetHeader];
    let allPass = true;
    let anyFound = false;

    for (const lbl of requiredLabels) {
      const it = itemByLabel[lbl];
      if (!it) continue; // missing label is treated as "not seen" — does not block
      anyFound = true;
      if (it.state === false) { allPass = false; break; }
      // true and 'NA' both count as pass
    }

    // If we found at least one matching label and they all pass, write TRUE.
    // If we found at least one matching label and any failed, write FALSE + red.
    // If NO matching labels at all, leave the cell alone (don't clobber prior state).
    if (!anyFound) continue;

    const r = rowIdx - 1;
    const c = col - 1;
    const newVal = allPass;
    const newBg  = allPass ? '#ffffff' : COLOR_DEFECT;
    const curVal = ctx.values[r][c];
    const curBg  = String(ctx.bgs[r][c] || '').toLowerCase();

    if (curVal !== newVal) {
      ctx.values[r][c] = newVal;
      ctx.dirtyValues = true;
      result.written++;
    }
    if (curBg !== newBg) {
      ctx.bgs[r][c] = newBg;
      ctx.dirtyBgs = true;
    }
    ctx.mutatedRows.add(rowIdx);

    if (!allPass) {
      defectLabels.push(sheetHeader);
    }
  }

  // Build the comments engine line.
  if (ctx.commentsCol > 0) {
    const date = rec.checkDate || Utilities.formatDate(new Date(), 'GMT+4', 'yyyy-MM-dd');
    const note = rec.note || '';
    const who  = rec.inspector || 'Unknown';
    const def  = defectLabels.length ? ' | Defects: ' + defectLabels.join(', ') : '';
    const engineLine = '[' + date + '] ' + note + ' | By: ' + who + def;

    const r = rowIdx - 1;
    const c = ctx.commentsCol - 1;
    const existing = String(ctx.values[r][c] || '');

    // Determine what to write:
    //   - If existing is "No inspection" or empty -> replace entirely
    //   - If existing has a prior engine line from a DIFFERENT date -> replace
    //   - If existing has manual text only (no engine line) -> replace if
    //     this is a real new inspection
    //   - Preserve manual text ONLY if it's NOT a full-replacement scenario
    const isNoInspection = existing.trim() === 'No inspection';
    const priorEngineMatch = existing.match(/\[\d{4}-\d{2}-\d{2}\]/);
    const priorDate = priorEngineMatch ? priorEngineMatch[0].slice(1, 11) : null;

    let newComment;
    if (isNoInspection || !existing.trim()) {
      // Was empty or "No inspection" -> just write engine line
      newComment = engineLine;
    } else if (priorDate && priorDate !== date) {
      // New inspection date -> replace everything (new inspection overrides)
      newComment = engineLine;
    } else if (!priorDate) {
      // Manual-only text, no engine line yet -> replace with engine line
      // (new inspection data takes over)
      newComment = engineLine;
    } else {
      // Same date -> update engine line, preserve manual text above
      const human = existing.split(/\n?\[\d{4}-\d{2}-\d{2}\]/)[0].trim();
      newComment = (human ? human + '\n' : '') + engineLine;
    }

    if (newComment !== existing) {
      ctx.values[r][c] = newComment;
      ctx.dirtyValues = true;
    }
    // Clear orange "No inspection" paint if present.
    const cBg = String(ctx.bgs[r][c] || '').toLowerCase();
    if (cBg === COLOR_NO_INSPECTION) {
      ctx.bgs[r][c] = '#ffffff';
      ctx.dirtyBgs = true;
    }
    ctx.mutatedRows.add(rowIdx);
  }

  return result;
}

// ============================ NO-INSPECTION MARKER ==========================

/**
 * For every plant row in any in-scope tab whose plant number is NOT in the
 * outcome keyset:
 *   1. Write plain "No inspection" in Comments cell (no date, no "By:").
 *   2. Paint ONLY the comments cell orange — not the entire row.
 *   3. Clear all SHEET_TO_PDF-mapped checkboxes to FALSE with white background.
 *   4. Skip entirely if cell already says "No inspection" AND all boxes are
 *      already FALSE — no redundant writes.
 *   5. Respects user-highlighted rows.
 */
function markNoInspectionPlants_(contextsByTab, plantsWithPdfs) {
  const hasPdf = new Set(plantsWithPdfs);

  for (const tabName in contextsByTab) {
    const ctx = contextsByTab[tabName];
    if (!ctx) continue;
    let touched = false;

    for (const plant in ctx.plantRow) {
      if (hasPdf.has(plant)) continue;
      const r = ctx.plantRow[plant];
      if (isUserHighlighted_(ctx, r)) continue;

      const ri = r - 1;
      const boxesAlreadyClear = areCheckboxesClear_(ctx, tabName, r);
      const commentAlreadySet = ctx.commentsCol > 0 &&
        String(ctx.values[ri][ctx.commentsCol - 1] || '').trim() === 'No inspection';

      // Skip if nothing to do.
      if (boxesAlreadyClear && commentAlreadySet) {
        // Still ensure orange paint on comments cell.
        if (ctx.commentsCol > 0) {
          const curBg = String(ctx.bgs[ri][ctx.commentsCol - 1] || '').toLowerCase();
          if (curBg !== COLOR_NO_INSPECTION) {
            ctx.bgs[ri][ctx.commentsCol - 1] = COLOR_NO_INSPECTION;
            ctx.dirtyBgs = true;
            touched = true;
          }
        }
        continue;
      }

      // Clear all checkboxes to FALSE with white bg.
      if (!boxesAlreadyClear) {
        clearCheckboxes_(ctx, tabName, r);
        touched = true;
      }

      // Write "No inspection" in comments cell.
      if (ctx.commentsCol > 0 && !commentAlreadySet) {
        ctx.values[ri][ctx.commentsCol - 1] = 'No inspection';
        ctx.dirtyValues = true;
        touched = true;
      }

      // Paint only the comments cell orange.
      if (ctx.commentsCol > 0) {
        const curBg = String(ctx.bgs[ri][ctx.commentsCol - 1] || '').toLowerCase();
        if (curBg !== COLOR_NO_INSPECTION) {
          ctx.bgs[ri][ctx.commentsCol - 1] = COLOR_NO_INSPECTION;
          ctx.dirtyBgs = true;
          touched = true;
        }
      }

      ctx.mutatedRows.add(r);
    }

    if (touched) flushContext_(ctx);
  }
}

// ============================ CHECKBOX HELPERS ==============================

/**
 * Check if all SHEET_TO_PDF-mapped columns for a plant row are already FALSE.
 */
function areCheckboxesClear_(ctx, tabName, rowIdx1Based) {
  const sheetMap = SHEET_TO_PDF[tabName] || {};
  const ri = rowIdx1Based - 1;
  for (const sheetHeader in sheetMap) {
    const col = ctx.headerIdx[sheetHeader];
    if (!col) continue;
    if (isManualOnlyHeader_(sheetHeader)) continue;
    if (ctx.values[ri][col - 1] !== false && ctx.values[ri][col - 1] !== '') return false;
  }
  return true;
}

/**
 * Set all SHEET_TO_PDF-mapped columns to FALSE with white background for a
 * plant row. Mutates ctx in-place.
 */
function clearCheckboxes_(ctx, tabName, rowIdx1Based) {
  const sheetMap = SHEET_TO_PDF[tabName] || {};
  const ri = rowIdx1Based - 1;
  for (const sheetHeader in sheetMap) {
    const col = ctx.headerIdx[sheetHeader];
    if (!col) continue;
    if (isManualOnlyHeader_(sheetHeader)) continue;
    const ci = col - 1;
    if (ctx.values[ri][ci] !== false) {
      ctx.values[ri][ci] = false;
      ctx.dirtyValues = true;
    }
    const curBg = String(ctx.bgs[ri][ci] || '').toLowerCase();
    if (curBg !== '#ffffff' && curBg !== '') {
      ctx.bgs[ri][ci] = '#ffffff';
      ctx.dirtyBgs = true;
    }
  }
}
/**
 * Timeout-safe continuation.
 *
 * Apps Script kills executions at 6 minutes. The engine bails at 4:30
 * (EXEC_SOFT_CAP_MS), saves the remaining plant queue to a script property,
 * and queues a 60-second-delayed insurance trigger BEFORE the chunk even
 * starts so a mid-chunk crash still resumes. resumeSync() picks up exactly
 * where it left off.
 */

/**
 * Save resume state with the remaining plant queue AND the outcome map.
 * Outcome is compressed to { plant: fileId } to stay under the 500KB
 * PropertiesService limit (~50 bytes/plant = 35KB for 700 plants).
 *
 * @param {string[]} remainingPlants
 * @param {Object} outcome  full outcome from mirrorSourceIntoWorkspace_()
 */
function saveResumeState_(remainingPlants, outcome) {
  // Compress outcome to just { plant: activeFileId }
  const slim = {};
  if (outcome) {
    for (const p in outcome) {
      slim[p] = { activeFileId: outcome[p].activeFileId };
    }
  }
  PropertiesService.getScriptProperties().setProperty(CK_RESUME, JSON.stringify({
    queue: remainingPlants,
    outcome: slim,
    ts: Date.now()
  }));
}

function loadResumeState_() {
  const raw = PropertiesService.getScriptProperties().getProperty(CK_RESUME);
  if (!raw) return null;
  try { return JSON.parse(raw); } catch (_) { return null; }
}

function clearResumeState_() {
  PropertiesService.getScriptProperties().deleteProperty(CK_RESUME);
  cleanupTriggers_('resumeSync');
}

/**
 * Critical: queue the insurance trigger BEFORE heavy work starts.
 * If this chunk crashes, the trigger still fires and resumeSync recovers.
 */
function queueInsuranceTrigger_() {
  cleanupTriggers_('resumeSync');
  ScriptApp.newTrigger('resumeSync')
    .timeBased()
    .after(INSURANCE_TRIGGER_DELAY_MS)
    .create();
}

/**
 * Recovery entry point. Called either by the insurance trigger or manually.
 */
function resumeSync() {
  const state = loadResumeState_();
  if (!state || !state.queue || !state.queue.length) {
    clearResumeState_();
    return;
  }
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(LOCK_TIMEOUT_MS)) return;
  try {
    // Don't pass plantFilter — let _syncCore_ detect the resume state
    // and reuse the cached outcome instead of re-scanning the folder.
    _syncCore_({ force: false, plantFilter: null });
  } finally {
    lock.releaseLock();
  }
}

function cleanupTriggers_(handlerName) {
  const triggers = ScriptApp.getProjectTriggers();
  for (const t of triggers) {
    if (t.getHandlerFunction() === handlerName) ScriptApp.deleteTrigger(t);
  }
}
/**
 * Drive push notifications + polling fallback.
 *
 * doPost() is invoked anonymously by Drive when the source folder changes.
 * The push channel is registered via Drive.Files.watch() against the source
 * folder; channels expire after 7 days, so a renewal trigger fires at 6.5d.
 *
 * The polling fallback (installPollingTrigger) runs every 10 minutes and
 * catches anything the push missed (network blips, expired channels, etc.).
 */

function doPost(_e) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(0)) return HtmlService.createHtmlOutput('busy');
  try {
    _syncCore_({ force: false, plantFilter: null });
  } catch (err) {
    logError_('doPost', err);
  } finally {
    lock.releaseLock();
  }
  return HtmlService.createHtmlOutput('ok');
}

function doGet() {
  return HtmlService.createHtmlOutput('QC Sync Engine — OK');
}

/**
 * Register a push channel on the source folder.
 * Persists channel id + resourceId in script properties for later stop().
 */
function installDriveWatch() {
  const webAppUrl = PropertiesService.getScriptProperties().getProperty('webAppUrl');
  if (!webAppUrl) {
    SpreadsheetApp.getActive().toast(
      'Set Script Property "webAppUrl" first (deploy as Web App, copy /exec URL)',
      'QC Sync', 8
    );
    return;
  }

  stopDriveWatch();

  const channelId = Utilities.getUuid();
  const expiration = (Date.now() + 7 * 24 * 60 * 60 * 1000).toString();

  const resp = Drive.Files.watch(
    { id: channelId, type: 'web_hook', address: webAppUrl, expiration: expiration },
    SOURCE_FOLDER_ID,
    { supportsAllDrives: true }
  );

  PropertiesService.getScriptProperties().setProperty(CK_WATCH, JSON.stringify({
    id: resp.id,
    resourceId: resp.resourceId,
    expiration: resp.expiration
  }));

  cleanupTriggers_('renewDriveWatch');
  ScriptApp.newTrigger('renewDriveWatch')
    .timeBased()
    .after(6.5 * 24 * 60 * 60 * 1000)
    .create();

  SpreadsheetApp.getActive().toast(
    'Drive watch installed until ' + new Date(parseInt(expiration, 10)).toISOString().slice(0, 16),
    'QC Sync', 6
  );
}

function stopDriveWatch() {
  const raw = PropertiesService.getScriptProperties().getProperty(CK_WATCH);
  if (!raw) return;
  try {
    const obj = JSON.parse(raw);
    Drive.Channels.stop({ id: obj.id, resourceId: obj.resourceId });
  } catch (_) {
    // already stopped or expired
  }
  PropertiesService.getScriptProperties().deleteProperty(CK_WATCH);
}

function renewDriveWatch() {
  installDriveWatch();
}

function installPollingTrigger() {
  cleanupTriggers_('pollSync');
  ScriptApp.newTrigger('pollSync').timeBased().everyMinutes(10).create();
  SpreadsheetApp.getActive().toast('Polling fallback installed (every 10 min)', 'QC Sync', 4);
}

function pollSync() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(0)) return;
  try {
    _syncCore_({ force: false, plantFilter: null });
  } catch (err) {
    logError_('pollSync', err);
  } finally {
    lock.releaseLock();
  }
}
/**
 * Diagnostic tools — read-only operations for troubleshooting.
 *
 *   auditAll()                 — dump tab structures, color histograms, source files
 *   dumpPdfTextForPlant(plant) — write a PDF's parsed text + structured rec to _Diagnostic
 */

/**
 * Read-only audit. Logs JSON to the execution log AND writes to _Diagnostic.
 */
function auditAll() {
  const ss = SpreadsheetApp.openById(SHEET_ID);
  const out = { tabs: {}, sourceFolder: { files: [], extras: [] }, errors: [] };

  for (const name of IN_SCOPE_TABS) {
    const sh = ss.getSheetByName(name);
    if (!sh) { out.errors.push('MISSING TAB: ' + name); continue; }
    const lastRow = sh.getLastRow();
    const lastCol = sh.getLastColumn();
    const headers = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(String);
    const dataRange = sh.getRange(1, 1, Math.min(lastRow, 300), lastCol);
    const bgs = dataRange.getBackgrounds();

    const colorSet = {};
    for (let r = 1; r < bgs.length; r++) {
      for (const bg of bgs[r]) {
        const c = (bg || '').toLowerCase();
        if (c === '' || c === '#ffffff') continue;
        colorSet[c] = (colorSet[c] || 0) + 1;
      }
    }

    let plantCol = -1;
    for (let i = 0; i < headers.length; i++) {
      if (/^\s*plant\s*(?:no|#|number)?\.?\s*$/i.test(headers[i])) { plantCol = i + 1; break; }
    }

    let commentsCol = -1;
    const override = COMMENTS_HEADER_BY_TAB[name];
    if (override) {
      for (let i = 0; i < headers.length; i++) {
        if (headers[i] === override) { commentsCol = i + 1; break; }
      }
    }
    if (commentsCol < 0) {
      for (let i = 0; i < headers.length; i++) {
        if (/^comments?$/i.test(headers[i])) { commentsCol = i + 1; break; }
      }
    }

    const plantSamples = [];
    if (plantCol > 0 && lastRow > 1) {
      const vals = sh.getRange(2, plantCol, Math.min(lastRow - 1, 30), 1).getValues();
      for (const row of vals) if (row[0]) plantSamples.push(String(row[0]));
    }

    out.tabs[name] = {
      lastRow, lastCol, headers,
      plantCol, plantNoHeader: plantCol > 0 ? headers[plantCol - 1] : null,
      commentsCol, commentsHeader: commentsCol > 0 ? headers[commentsCol - 1] : null,
      colorHistogram: colorSet,
      plantSamples
    };
  }

  try {
    let pageToken = null;
    do {
      const r = Drive.Files.list({
        q: "'" + SOURCE_FOLDER_ID + "' in parents and trashed = false and mimeType='application/pdf'",
        corpora: 'allDrives',
        includeItemsFromAllDrives: true,
        supportsAllDrives: true,
        pageSize: 1000,
        pageToken: pageToken,
        fields: 'nextPageToken,files(id,name,modifiedTime)'
      });
      if (r.files) for (const f of r.files) out.sourceFolder.files.push(f.name);
      pageToken = r.nextPageToken;
    } while (pageToken);
  } catch (e) {
    out.errors.push('DRIVE LIST: ' + e.message);
  }

  console.log('===AUDIT===');
  console.log(JSON.stringify(out));
  console.log('===PDFCOUNT===' + out.sourceFolder.files.length);
  return out;
}

/**
 * Write the parsed text + structured record for one plant's active mirror PDF
 * to the _Diagnostic tab. Used to seed SHEET_TO_PDF mappings for new tabs.
 */
function dumpPdfTextForPlant(plantNo) {
  const ws = ensureWorkspace_();
  const safe = String(plantNo).trim().toUpperCase().replace(/[\\/]/g, '_');
  const files = drv_listInFolder_(ws.activeId, "name = '" + safe + "__LATEST.pdf'");
  if (!files.length) {
    SpreadsheetApp.getActive().toast('No Active/' + safe + '__LATEST.pdf', 'QC Sync', 6);
    return;
  }
  const blob = drv_blob_(files[0].id);
  const text = extractPdfText_(blob);
  const rec = parseQcText_(text, plantNo);

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(DIAGNOSTIC_TAB);
  if (!sh) sh = ss.insertSheet(DIAGNOSTIC_TAB);
  sh.clear();

  const out = [];
  out.push(['[' + plantNo + '] dumped ' + new Date()]);
  out.push(['---- HEADER FIELDS ----']);
  out.push(['plantNo',   rec.plantNo || '']);
  out.push(['checkDate', rec.checkDate || '']);
  out.push(['checkType', rec.checkType || '']);
  out.push(['inspector', rec.inspector || '']);
  out.push(['note',      rec.note || '']);
  out.push(['---- ITEMS (' + rec.items.length + ') ----']);
  out.push(['bullet', 'label', 'state']);
  for (const it of rec.items) out.push([it.bullet, it.label, String(it.state)]);
  out.push(['---- RAW TEXT ----']);
  const lines = text.split(/\s{2,}|\n/).filter(function (l) { return l.trim(); });
  for (const l of lines) out.push([l]);

  // Write each row, padded to 3 columns for the items section
  const maxCols = 3;
  const padded = out.map(function (r) {
    while (r.length < maxCols) r.push('');
    return r.slice(0, maxCols);
  });
  sh.getRange(1, 1, padded.length, maxCols).setValues(padded);

  ss.toast('Dumped ' + rec.items.length + ' items for ' + plantNo, 'QC Sync', 5);
}

function dumpPdfTextForPlant_prompt() {
  const resp = SpreadsheetApp.getUi().prompt(
    'Dump PDF Text',
    'Plant No (e.g. ABL.F.40.01):',
    SpreadsheetApp.getUi().ButtonSet.OK_CANCEL
  );
  if (resp.getSelectedButton() !== SpreadsheetApp.getUi().Button.OK) return;
  dumpPdfTextForPlant(resp.getResponseText().trim());
}
/**
 * Sheet menu — installed via the onOpen simple trigger.
 */

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('QC Sync')
    .addItem('Sync All',                  'syncAll')
    .addItem('Sync Selected Rows',        'syncSelected')
    .addSeparator()
    .addItem('Force Full Re-sync',        'forceFullResync')
    .addSeparator()
    .addItem('Audit (read-only)',         'auditAll')
    .addItem('Dump PDF Text for Plant…',  'dumpPdfTextForPlant_prompt')
    .addItem('Open Logs Tab',             'openLogsTab')
    .addSeparator()
    .addItem('🔧 Install Drive Watch',    'installDriveWatch')
    .addItem('🔧 Stop Drive Watch',       'stopDriveWatch')
    .addItem('🔧 Install Polling Fallback','installPollingTrigger')
    .addToUi();
}
