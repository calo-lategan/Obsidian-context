/**
 * Sheet menu — installed via the onOpen simple trigger.
 */

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('QC Sync')
    .addItem('Sync All',                  'syncAll')
    .addItem('Sync Selected Rows',        'syncSelected')
    .addSeparator()
    .addItem('Force Full Re-sync',        'forceFullResync')
    .addSeparator()
    .addItem('Audit (read-only)',         'auditAll')
    .addItem('Dump PDF Text for Plant…',  'dumpPdfTextForPlant_prompt')
    .addItem('Open Logs Tab',             'openLogsTab')
    .addSeparator()
    .addItem('🔧 Install Drive Watch',    'installDriveWatch')
    .addItem('🔧 Stop Drive Watch',       'stopDriveWatch')
    .addItem('🔧 Install Polling Fallback','installPollingTrigger')
    .addItem('🔧 Stop Polling Trigger',   'stopPollingTrigger')
    .addItem('🔧 Remove All Triggers',    'removeAllTriggers')
    .addToUi();
}
