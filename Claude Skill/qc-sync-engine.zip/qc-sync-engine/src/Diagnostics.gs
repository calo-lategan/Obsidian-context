/**
 * Diagnostic tools — read-only operations for troubleshooting.
 *
 *   auditAll()                 — dump tab structures, color histograms, source files
 *   dumpPdfTextForPlant(plant) — write a PDF's parsed text + structured rec to _Diagnostic
 */

/**
 * Read-only audit. Logs JSON to the execution log AND writes to _Diagnostic.
 */
function auditAll() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const out = { tabs: {}, sourceFolder: { files: [], extras: [] }, errors: [] };

  for (const name of IN_SCOPE_TABS) {
    const sh = ss.getSheetByName(name);
    if (!sh) { out.errors.push('MISSING TAB: ' + name); continue; }
    const lastRow = sh.getLastRow();
    const lastCol = sh.getLastColumn();
    const headers = sh.getRange(1, 1, 1, lastCol).getValues()[0].map(String);
    const dataRange = sh.getRange(1, 1, Math.min(lastRow, 300), lastCol);
    const bgs = dataRange.getBackgrounds();

    const colorSet = {};
    for (let r = 1; r < bgs.length; r++) {
      for (const bg of bgs[r]) {
        const c = (bg || '').toLowerCase();
        if (c === '' || c === '#ffffff') continue;
        colorSet[c] = (colorSet[c] || 0) + 1;
      }
    }

    let plantCol = -1;
    for (let i = 0; i < headers.length; i++) {
      if (/^\s*plant\s*(?:no|#|number)?\.?\s*$/i.test(headers[i])) { plantCol = i + 1; break; }
    }

    let commentsCol = -1;
    const override = COMMENTS_HEADER_BY_TAB[name];
    if (override) {
      for (let i = 0; i < headers.length; i++) {
        if (headers[i] === override) { commentsCol = i + 1; break; }
      }
    }
    if (commentsCol < 0) {
      for (let i = 0; i < headers.length; i++) {
        if (/^comments?$/i.test(headers[i])) { commentsCol = i + 1; break; }
      }
    }

    const plantSamples = [];
    if (plantCol > 0 && lastRow > 1) {
      const vals = sh.getRange(2, plantCol, Math.min(lastRow - 1, 30), 1).getValues();
      for (const row of vals) if (row[0]) plantSamples.push(String(row[0]));
    }

    out.tabs[name] = {
      lastRow, lastCol, headers,
      plantCol, plantNoHeader: plantCol > 0 ? headers[plantCol - 1] : null,
      commentsCol, commentsHeader: commentsCol > 0 ? headers[commentsCol - 1] : null,
      colorHistogram: colorSet,
      plantSamples
    };
  }

  try {
    let pageToken = null;
    do {
      const r = Drive.Files.list({
        q: "'" + SOURCE_FOLDER_ID + "' in parents and trashed = false and mimeType='application/pdf'",
        corpora: 'allDrives',
        includeItemsFromAllDrives: true,
        supportsAllDrives: true,
        pageSize: 1000,
        pageToken: pageToken,
        fields: 'nextPageToken,files(id,name,modifiedTime)'
      });
      if (r.files) for (const f of r.files) out.sourceFolder.files.push(f.name);
      pageToken = r.nextPageToken;
    } while (pageToken);
  } catch (e) {
    out.errors.push('DRIVE LIST: ' + e.message);
  }

  console.log('===AUDIT===');
  console.log(JSON.stringify(out));
  console.log('===PDFCOUNT===' + out.sourceFolder.files.length);
  return out;
}

/**
 * Write the parsed text + structured record for one plant's active mirror PDF
 * to the _Diagnostic tab. Used to seed SHEET_TO_PDF mappings for new tabs.
 */
function dumpPdfTextForPlant(plantNo) {
  var safe = String(plantNo).trim().toUpperCase();
  // Find plant subfolder in source folder
  var folders = drv_listInFolder_(SOURCE_FOLDER_ID,
    "mimeType = 'application/vnd.google-apps.folder' and name = '" + safe.replace(/'/g, "\\'") + "'");
  if (!folders.length) {
    SpreadsheetApp.getActive().toast('No subfolder "' + safe + '" in source', 'QC Sync', 6);
    return;
  }
  var pdfs = drv_listInFolder_(folders[0].id, "mimeType = 'application/pdf'");
  if (!pdfs.length) {
    SpreadsheetApp.getActive().toast('No PDFs in subfolder "' + safe + '"', 'QC Sync', 6);
    return;
  }
  // Pick the latest by filename date
  var best = pdfs[0];
  for (var i = 1; i < pdfs.length; i++) {
    var bm = best.name.match(FILENAME_RX);
    var cm = pdfs[i].name.match(FILENAME_RX);
    if (cm && (!bm || cm[2] > bm[2])) best = pdfs[i];
  }
  const blob = drv_blob_(best.id);
  const text = extractPdfText_(blob);
  const rec = parseQcText_(text, plantNo);

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(DIAGNOSTIC_TAB);
  if (!sh) sh = ss.insertSheet(DIAGNOSTIC_TAB);
  sh.clear();

  const out = [];
  out.push(['[' + plantNo + '] dumped ' + new Date()]);
  out.push(['---- HEADER FIELDS ----']);
  out.push(['plantNo',   rec.plantNo || '']);
  out.push(['checkDate', rec.checkDate || '']);
  out.push(['checkType', rec.checkType || '']);
  out.push(['inspector', rec.inspector || '']);
  out.push(['note',      rec.note || '']);
  out.push(['---- ITEMS (' + rec.items.length + ') ----']);
  out.push(['bullet', 'label', 'state']);
  for (const it of rec.items) out.push([it.bullet, it.label, String(it.state)]);
  out.push(['---- RAW TEXT ----']);
  const lines = text.split(/\s{2,}|\n/).filter(function (l) { return l.trim(); });
  for (const l of lines) out.push([l]);

  // Write each row, padded to 3 columns for the items section
  const maxCols = 3;
  const padded = out.map(function (r) {
    while (r.length < maxCols) r.push('');
    return r.slice(0, maxCols);
  });
  sh.getRange(1, 1, padded.length, maxCols).setValues(padded);

  ss.toast('Dumped ' + rec.items.length + ' items for ' + plantNo, 'QC Sync', 5);
}

function dumpPdfTextForPlant_prompt() {
  const resp = SpreadsheetApp.getUi().prompt(
    'Dump PDF Text',
    'Plant No (e.g. ABL.F.40.01):',
    SpreadsheetApp.getUi().ButtonSet.OK_CANCEL
  );
  if (resp.getSelectedButton() !== SpreadsheetApp.getUi().Button.OK) return;
  dumpPdfTextForPlant(resp.getResponseText().trim());
}
