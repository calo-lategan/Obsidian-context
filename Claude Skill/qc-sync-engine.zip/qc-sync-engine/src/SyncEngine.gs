/**
 * Sync engine core.
 *
 * Apply a parsed PDF record to an in-memory tab context using SHEET_TO_PDF
 * mapping. All checkboxes mutate the values 2D array; all paints mutate the
 * bgs 2D array. Flush is one setValues + one setBackgrounds per dirty tab.
 *
 * Invariants:
 *   - User-highlighted rows (anything outside ENGINE_OWNED_COLORS) are skipped
 *     atomically — no value writes, no paint changes, no comments rewrite,
 *     no cache update.
 *   - Manual-only headers (Door keys, Keys, Notes) are NEVER written by the
 *     engine.
 *   - PDF items not mapped in SHEET_TO_PDF[tab] are silently ignored. They
 *     are extra inspection items the form tracks but the sheet doesn't.
 *   - For a sheet checkbox to become TRUE, EVERY mapped PDF item must be ✅
 *     or N/A. If ANY is ❌, the sheet cell becomes FALSE + painted red.
 */

// ============================ ENTRY POINTS ==================================

function syncAll() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(LOCK_TIMEOUT_MS)) {
    SpreadsheetApp.getActiveSpreadsheet().toast('Another sync in progress', 'QC Sync', 4);
    return;
  }
  try {
    _syncCore_({ force: false, plantFilter: null });
  } catch (err) {
    logError_('syncAll', err);
    throw err;
  } finally {
    lock.releaseLock();
  }
}

function forceFullResync() {
  clearDriftCache_();
  clearResumeState_();
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(LOCK_TIMEOUT_MS)) {
    SpreadsheetApp.getActiveSpreadsheet().toast('Another sync in progress', 'QC Sync', 4);
    return;
  }
  try {
    _syncCore_({ force: true, plantFilter: null });
  } catch (err) {
    logError_('forceFullResync', err);
    throw err;
  } finally {
    lock.releaseLock();
  }
}

function syncSelected() {
  const sel = SpreadsheetApp.getActive().getActiveRangeList();
  if (!sel) {
    SpreadsheetApp.getActive().toast('Nothing selected', 'QC Sync', 3);
    return;
  }
  const plants = new Set();
  for (const r of sel.getRanges()) {
    const vals = r.getValues();
    for (const row of vals) {
      for (const cell of row) {
        const s = String(cell || '').trim().toUpperCase();
        // Anything that looks plant-id-shaped: at least 2 chars, only [A-Z0-9._/-]
        if (s.length >= 2 && /^[A-Z0-9._/-]+$/.test(s)) plants.add(s);
      }
    }
  }
  if (!plants.size) {
    SpreadsheetApp.getActive().toast('No plant numbers found in selection', 'QC Sync', 4);
    return;
  }
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(LOCK_TIMEOUT_MS)) return;
  try {
    _syncCore_({ force: true, plantFilter: plants });
  } catch (err) {
    logError_('syncSelected', err);
    throw err;
  } finally {
    lock.releaseLock();
  }
}

// ============================ CORE LOOP =====================================

function _syncCore_(opts) {
  const t0 = Date.now();
  const force = !!(opts && opts.force);
  const plantFilter = opts && opts.plantFilter;
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  // ---- Phase 1: Scan source folder (or reuse cached outcome on resume) ----
  let outcome;
  const resumeState = loadResumeState_();
  if (resumeState && !force && !plantFilter && resumeState.outcome) {
    outcome = resumeState.outcome;
    ss.toast('Resuming: ' + resumeState.queue.length + ' plants remaining', 'QC Sync', 4);
  } else {
    ss.toast('Scanning source folder...', 'QC Sync', 3);
    outcome = mirrorSourceIntoWorkspace_();
  }

  let plants = (resumeState && !force && !plantFilter && resumeState.queue)
    ? resumeState.queue
    : Object.keys(outcome);
  if (plantFilter) plants = plants.filter(function (p) { return plantFilter.has(p); });

  // Pre-queue insurance trigger BEFORE heavy work starts.
  queueInsuranceTrigger_();

  // ---- Phase 2: Eagerly build ALL tab contexts + plant->tab index --------
  ss.toast('Building tab contexts (' + IN_SCOPE_TABS.length + ' tabs)...', 'QC Sync', 2);
  const contextsByTab = {};
  const plantToTab = {};
  for (const tabName of IN_SCOPE_TABS) {
    const sh = ss.getSheetByName(tabName);
    contextsByTab[tabName] = sh ? buildTabContext_(sh) : null;
    if (contextsByTab[tabName]) {
      for (const p in contextsByTab[tabName].plantRow) {
        plantToTab[p] = tabName;
      }
    }
  }

  const cache = readDriftCache_();

  // ---- Phase 3: Filter through drift cache (file ID + date + checkbox hash)
  const toDownload = [];   // { plantNo, fileId, date }
  const skipped = { highlighted: 0, idempotent: 0, noTab: 0, parseFailed: 0, dlFailed: 0, manualOverride: 0 };

  for (const plantNo of plants) {
    const info = outcome[plantNo];
    if (!info) continue;
    const prior = cache[plantNo];
    if (!force && prior && prior.fid === info.activeFileId && prior.date === info.date) {
      // PDF unchanged — check if checkboxes were manually edited
      var chkTab = resolveTab_(plantNo, plantToTab);
      var chkCtx = chkTab ? contextsByTab[chkTab] : null;
      if (chkCtx && chkCtx.plantRow[plantNo]) {
        var currentHash = hashCheckboxes_(chkCtx, chkTab, plantNo);
        if (currentHash === prior.rh) {
          skipped.idempotent++;
          continue;
        }
        skipped.manualOverride++;
      } else {
        skipped.idempotent++;
        continue;
      }
    }
    toDownload.push({ plantNo: plantNo, fileId: info.activeFileId, date: info.date || '' });
  }

  ss.toast(plants.length + ' plants | ' + skipped.idempotent + ' cached | ' +
           toDownload.length + ' to process', 'QC Sync', 3);

  // ---- Phase 4: Batch-download changed PDFs via fetchAll() ---------------
  const fileIds = toDownload.map(function (d) { return d.fileId; });
  const blobs = drv_blobBatch_(fileIds);

  // ---- Phase 4.5: Batch text extraction (parallel export + delete) ------
  ss.toast('Converting ' + fileIds.length + ' PDFs...', 'QC Sync', 3);
  const texts = extractPdfTextBatch_(blobs);

  // ---- Phase 5: Parse + apply -------------------------------------------
  const processed = [];
  let idx = 0;

  for (const dl of toDownload) {
    idx++;
    if (Date.now() - t0 > EXEC_SOFT_CAP_MS) {
      const remaining = toDownload.slice(idx - 1).map(function (d) { return d.plantNo; });
      saveResumeState_(remaining, outcome);
      ss.toast('Paused at ' + (idx - 1) + '/' + toDownload.length + '. Resuming in 60s.', 'QC Sync', 6);
      flushAllContexts_(contextsByTab);
      writeDriftCache_(cache);
      return;
    }

    const plantNo = dl.plantNo;
    const tabName = resolveTab_(plantNo, plantToTab);
    if (!tabName) { skipped.noTab++; continue; }
    const ctx = contextsByTab[tabName];
    if (!ctx) { skipped.noTab++; continue; }

    // Auto-add row if plant not yet present.
    if (!ctx.plantRow[plantNo]) {
      addPlantRow_(ctx, plantNo);
      plantToTab[plantNo] = tabName;
    }

    // Get pre-extracted text.
    const text = texts[dl.fileId];
    if (!text) { skipped.dlFailed++; continue; }

    let rec;
    try {
      rec = parseQcText_(text, plantNo);
    } catch (e) {
      logError_('parse:' + plantNo, e);
      skipped.parseFailed++;
      continue;
    }

    const result = applyRecordToContext_(ctx, tabName, plantNo, rec);
    if (result.skippedHighlight) {
      skipped.highlighted++;
      continue;
    }

    cache[plantNo] = {
      fid: dl.fileId,
      date: rec.checkDate || dl.date || '',
      rh: hashCheckboxes_(ctx, tabName, plantNo),
      ts: Date.now()
    };
    processed.push(plantNo);

    if (idx % 20 === 0) {
      ss.toast('[' + idx + '/' + toDownload.length + '] ' + plantNo, 'QC Sync', 2);
    }
  }

  flushAllContexts_(contextsByTab);
  writeDriftCache_(cache);
  markNoInspectionPlants_(contextsByTab, Object.keys(outcome));
  clearResumeState_();

  const elapsed = ((Date.now() - t0) / 1000).toFixed(1);
  const summary = 'Done in ' + elapsed + 's | written ' + processed.length +
                  ' | idempotent ' + skipped.idempotent +
                  ' | highlighted ' + skipped.highlighted +
                  ' | override ' + skipped.manualOverride +
                  ' | no-tab ' + skipped.noTab +
                  ' | parse-fail ' + skipped.parseFailed +
                  ' | dl-fail ' + skipped.dlFailed;
  ss.toast(summary, 'QC Sync', 8);
  logInfo_('_syncCore_', summary);
}

function flushAllContexts_(contextsByTab) {
  for (const tab in contextsByTab) flushContext_(contextsByTab[tab]);
}

// ============================ APPLY RECORD ==================================

/**
 * Mutate ctx in-place with a parsed PDF record for one plant.
 *
 * @return {{written: number, skippedHighlight: boolean, unmatched: string[]}}
 */
function applyRecordToContext_(ctx, tabName, plantNo, rec) {
  const result = { written: 0, skippedHighlight: false, unmatched: [] };
  const rowIdx = ctx.plantRow[plantNo];
  if (!rowIdx) return result;

  if (isUserHighlighted_(ctx, rowIdx)) {
    result.skippedHighlight = true;
    return result;
  }

  // Index the parsed items by lowercased label for fast lookup.
  const itemByLabel = {};
  for (const it of rec.items) {
    itemByLabel[it.label] = it;
  }

  const sheetMap = SHEET_TO_PDF[tabName] || {};
  const defectLabels = [];

  for (const sheetHeader in sheetMap) {
    const col = ctx.headerIdx[sheetHeader];
    if (!col) continue;
    if (isManualOnlyHeader_(sheetHeader)) continue;

    const requiredLabels = sheetMap[sheetHeader];
    let allPass = true;
    let allNA = true;
    let anyFound = false;

    for (const lbl of requiredLabels) {
      const it = itemByLabel[lbl];
      if (!it) continue;
      anyFound = true;
      if (it.state === false) { allPass = false; allNA = false; break; }
      if (it.state !== 'NA') allNA = false;
    }

    if (!anyFound) continue;

    const r = rowIdx - 1;
    const c = col - 1;
    let newVal, newBg;
    if (allPass && allNA) {
      newVal = 'N/A';
      newBg  = COLOR_NA;
    } else if (allPass) {
      newVal = true;
      newBg  = COLOR_PASS;
    } else {
      newVal = false;
      newBg  = COLOR_DEFECT;
    }
    const curVal = ctx.values[r][c];
    const curBg  = String(ctx.bgs[r][c] || '').toLowerCase();

    if (curVal !== newVal) {
      ctx.values[r][c] = newVal;
      ctx.dirtyValues = true;
      result.written++;
    }
    if (curBg !== newBg) {
      ctx.bgs[r][c] = newBg;
      ctx.dirtyBgs = true;
    }
    ctx.mutatedRows.add(rowIdx);

    if (!allPass) {
      defectLabels.push(sheetHeader);
    }
  }

  // Build the comments engine line.
  if (ctx.commentsCol > 0) {
    const date = rec.checkDate || Utilities.formatDate(new Date(), 'GMT+4', 'yyyy-MM-dd');
    const note = rec.note || '';
    const who  = rec.inspector || 'Unknown';
    const def  = defectLabels.length ? ' | Defects: ' + defectLabels.join(', ') : '';
    const engineLine = '[' + date + '] ' + note + ' | By: ' + who + def;

    const r = rowIdx - 1;
    const c = ctx.commentsCol - 1;
    const existing = String(ctx.values[r][c] || '');

    // Determine what to write:
    //   - If existing is "No inspection" or empty -> replace entirely
    //   - If existing has a prior engine line from a DIFFERENT date -> replace
    //   - If existing has manual text only (no engine line) -> replace if
    //     this is a real new inspection
    //   - Preserve manual text ONLY if it's NOT a full-replacement scenario
    const isNoInspection = existing.trim() === 'No inspection';
    const priorEngineMatch = existing.match(/\[\d{4}-\d{2}-\d{2}\]/);
    const priorDate = priorEngineMatch ? priorEngineMatch[0].slice(1, 11) : null;

    let newComment;
    if (isNoInspection || !existing.trim()) {
      // Was empty or "No inspection" -> just write engine line
      newComment = engineLine;
    } else if (priorDate && priorDate !== date) {
      // New inspection date -> replace everything (new inspection overrides)
      newComment = engineLine;
    } else if (!priorDate) {
      // Manual-only text, no engine line yet -> replace with engine line
      // (new inspection data takes over)
      newComment = engineLine;
    } else {
      // Same date -> update engine line, preserve manual text above
      const human = existing.split(/\n?\[\d{4}-\d{2}-\d{2}\]/)[0].trim();
      newComment = (human ? human + '\n' : '') + engineLine;
    }

    if (newComment !== existing) {
      ctx.values[r][c] = newComment;
      ctx.dirtyValues = true;
    }
    // Clear orange "No inspection" paint if present.
    const cBg = String(ctx.bgs[r][c] || '').toLowerCase();
    if (cBg === COLOR_NO_INSPECTION) {
      ctx.bgs[r][c] = '#ffffff';
      ctx.dirtyBgs = true;
    }
    ctx.mutatedRows.add(rowIdx);
  }

  return result;
}

// ============================ NO-INSPECTION MARKER ==========================

/**
 * For every plant row in any in-scope tab whose plant number is NOT in the
 * outcome keyset:
 *   1. Write plain "No inspection" in Comments cell (no date, no "By:").
 *   2. Paint ONLY the comments cell orange — not the entire row.
 *   3. Clear all SHEET_TO_PDF-mapped checkboxes to FALSE with white background.
 *   4. Skip entirely if cell already says "No inspection" AND all boxes are
 *      already FALSE — no redundant writes.
 *   5. Respects user-highlighted rows.
 */
function markNoInspectionPlants_(contextsByTab, plantsWithPdfs) {
  const hasPdf = new Set(plantsWithPdfs);

  for (const tabName in contextsByTab) {
    const ctx = contextsByTab[tabName];
    if (!ctx) continue;
    let touched = false;

    for (const plant in ctx.plantRow) {
      if (hasPdf.has(plant)) continue;
      const r = ctx.plantRow[plant];
      if (isUserHighlighted_(ctx, r)) continue;

      const ri = r - 1;
      const boxesAlreadyClear = areCheckboxesClear_(ctx, tabName, r);
      const commentAlreadySet = ctx.commentsCol > 0 &&
        String(ctx.values[ri][ctx.commentsCol - 1] || '').trim() === 'No inspection';

      // Skip if nothing to do.
      if (boxesAlreadyClear && commentAlreadySet) {
        // Still ensure orange paint on comments cell.
        if (ctx.commentsCol > 0) {
          const curBg = String(ctx.bgs[ri][ctx.commentsCol - 1] || '').toLowerCase();
          if (curBg !== COLOR_NO_INSPECTION) {
            ctx.bgs[ri][ctx.commentsCol - 1] = COLOR_NO_INSPECTION;
            ctx.dirtyBgs = true;
            touched = true;
          }
        }
        continue;
      }

      // Clear all checkboxes to FALSE with white bg.
      if (!boxesAlreadyClear) {
        clearCheckboxes_(ctx, tabName, r);
        touched = true;
      }

      // Write "No inspection" in comments cell.
      if (ctx.commentsCol > 0 && !commentAlreadySet) {
        ctx.values[ri][ctx.commentsCol - 1] = 'No inspection';
        ctx.dirtyValues = true;
        touched = true;
      }

      // Paint only the comments cell orange.
      if (ctx.commentsCol > 0) {
        const curBg = String(ctx.bgs[ri][ctx.commentsCol - 1] || '').toLowerCase();
        if (curBg !== COLOR_NO_INSPECTION) {
          ctx.bgs[ri][ctx.commentsCol - 1] = COLOR_NO_INSPECTION;
          ctx.dirtyBgs = true;
          touched = true;
        }
      }

      ctx.mutatedRows.add(r);
    }

    if (touched) flushContext_(ctx);
  }
}

// ============================ CHECKBOX HELPERS ==============================

/**
 * Check if all SHEET_TO_PDF-mapped columns for a plant row are already FALSE.
 */
function areCheckboxesClear_(ctx, tabName, rowIdx1Based) {
  const sheetMap = SHEET_TO_PDF[tabName] || {};
  const ri = rowIdx1Based - 1;
  for (const sheetHeader in sheetMap) {
    const col = ctx.headerIdx[sheetHeader];
    if (!col) continue;
    if (isManualOnlyHeader_(sheetHeader)) continue;
    if (ctx.values[ri][col - 1] !== false && ctx.values[ri][col - 1] !== '') return false;
  }
  return true;
}

/**
 * Set all SHEET_TO_PDF-mapped columns to FALSE with white background for a
 * plant row. Mutates ctx in-place.
 */
function clearCheckboxes_(ctx, tabName, rowIdx1Based) {
  const sheetMap = SHEET_TO_PDF[tabName] || {};
  const ri = rowIdx1Based - 1;
  for (const sheetHeader in sheetMap) {
    const col = ctx.headerIdx[sheetHeader];
    if (!col) continue;
    if (isManualOnlyHeader_(sheetHeader)) continue;
    const ci = col - 1;
    if (ctx.values[ri][ci] !== false) {
      ctx.values[ri][ci] = false;
      ctx.dirtyValues = true;
    }
    const curBg = String(ctx.bgs[ri][ci] || '').toLowerCase();
    if (curBg !== '#ffffff' && curBg !== '') {
      ctx.bgs[ri][ci] = '#ffffff';
      ctx.dirtyBgs = true;
    }
  }
}
