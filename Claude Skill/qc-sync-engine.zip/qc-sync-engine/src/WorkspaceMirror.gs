/**
 * Source folder organizer.
 *
 * The source folder (SOURCE_FOLDER_ID) contains plant-number subfolders.
 * Each subfolder holds the latest inspection PDF + an Archive/ subfolder
 * for older revisions.
 *
 * When a new PDF lands at the ROOT of the source folder, the engine:
 *   1. Extracts the plant number from the filename.
 *   2. Creates a plant subfolder if one doesn't exist.
 *   3. Archives any existing PDF in the subfolder.
 *   4. MOVES the original PDF into the plant subfolder (no copies).
 *
 * Temp files (tmp-qcsync-*) are cleaned up automatically.
 */

/**
 * Scan the source folder tree, organize root PDFs into plant subfolders,
 * archive older revisions, clean temps, and build the outcome map.
 *
 * @return {Object<string, {activeFileId, sourceFileId, date, checkType}>}
 *         keyed by plant number (uppercase, trimmed)
 */
function mirrorSourceIntoWorkspace_() {

  // ---- Phase A: Discovery ------------------------------------------------
  var subfolders = drv_listInFolder_(SOURCE_FOLDER_ID,
    "mimeType = 'application/vnd.google-apps.folder'");
  var rootPdfs = drv_listInFolder_(SOURCE_FOLDER_ID,
    "mimeType = 'application/pdf'");

  // Filter out utility folders (Archive, _QC_Workspace at root level)
  subfolders = subfolders.filter(function(f) {
    var n = f.name.trim().toUpperCase();
    return n !== 'ARCHIVE' && n.indexOf('_QC_') !== 0;
  });

  // Index subfolders by plant name
  var folderByPlant = {};
  for (var i = 0; i < subfolders.length; i++) {
    folderByPlant[subfolders[i].name.trim().toUpperCase()] = subfolders[i];
  }

  // Batch-list ALL files in ALL subfolders (PDFs + temps + docs)
  var subfolderIds = subfolders.map(function(f) { return f.id; });
  var subfolderFiles = drv_listSubfolderFiles_(subfolderIds);

  // ---- Phase B: Build latestByPlant from existing subfolders ---------------
  var latestByPlant = {};
  for (var si = 0; si < subfolders.length; si++) {
    var folder = subfolders[si];
    var plantName = folder.name.trim().toUpperCase();
    var files = subfolderFiles[folder.id] || [];
    for (var fi = 0; fi < files.length; fi++) {
      var file = files[fi];
      if (file.mimeType !== 'application/pdf') continue;
      var m = file.name.match(FILENAME_RX);
      var date = m ? m[2] : '000000';
      var checkType = m ? m[3] : '';
      if (!latestByPlant[plantName] || date > latestByPlant[plantName].date) {
        latestByPlant[plantName] = { srcFile: file, date: date, checkType: checkType };
      }
    }
  }

  // ---- Phase C: Organize root PDFs into plant subfolders -------------------
  var cache = readDriftCache_();

  for (var ri = 0; ri < rootPdfs.length; ri++) {
    var f = rootPdfs[ri];
    var m = f.name.match(FILENAME_RX);
    if (!m) continue;
    var plant = m[1].trim().toUpperCase();
    var date  = m[2];
    var checkType = m[3];

    // Find or create plant subfolder
    var plantFolder = folderByPlant[plant];
    if (!plantFolder) {
      var newFolderId = drv_findOrCreateFolder_(SOURCE_FOLDER_ID, plant);
      plantFolder = { id: newFolderId, name: plant };
      folderByPlant[plant] = plantFolder;
    }

    // Root folder ALWAYS wins — any PDF at root is treated as the new latest
    var existingLatest = latestByPlant[plant];
    if (existingLatest) {
      var archId = drv_findOrCreateFolder_(plantFolder.id, 'Archive');
      drv_move_(existingLatest.srcFile.id, plantFolder.id, archId);
    }
    drv_move_(f.id, SOURCE_FOLDER_ID, plantFolder.id);
    delete cache[plant];
    latestByPlant[plant] = { srcFile: f, date: date, checkType: checkType };
  }

  writeDriftCache_(cache);

  // ---- Phase D: Clean up temp files ----------------------------------------
  for (var si2 = 0; si2 < subfolders.length; si2++) {
    var allFiles = subfolderFiles[subfolders[si2].id] || [];
    for (var fi2 = 0; fi2 < allFiles.length; fi2++) {
      if (allFiles[fi2].name && allFiles[fi2].name.indexOf('tmp-qcsync') === 0) {
        try { drv_trash_(allFiles[fi2].id); } catch (e) { /* ignore */ }
      }
    }
  }
  // Root-level temps
  var rootTemps = drv_listInFolder_(SOURCE_FOLDER_ID, "name contains 'tmp-qcsync'");
  for (var ti = 0; ti < rootTemps.length; ti++) {
    try { drv_trash_(rootTemps[ti].id); } catch (e) { /* ignore */ }
  }

  // ---- Phase E: Build outcome -----------------------------------------------
  var outcome = {};
  for (var plant in latestByPlant) {
    var info = latestByPlant[plant];
    outcome[plant] = {
      activeFileId: info.srcFile.id,
      sourceFileId: info.srcFile.id,
      date: info.date,
      checkType: info.checkType
    };
  }

  return outcome;
}
