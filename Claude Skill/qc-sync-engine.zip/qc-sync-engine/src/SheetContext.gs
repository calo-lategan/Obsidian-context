/**
 * In-memory tab context for batched I/O.
 *
 * One getValues + one getBackgrounds per tab at build time. All mutation
 * happens to the in-memory 2D arrays. flushContext_() does ONE setValues +
 * ONE setBackgrounds per dirty tab. This is ~30-50x faster than per-cell
 * writes against a 200+ row tab.
 */

/**
 * Find the 1-indexed column whose row-1 header looks like a Plant No.
 * Accepts: "Plant No.", "Plant No", "Plant Number", "Plant#", case-insensitive.
 */
function plantNoColIdx_(sheet) {
  const lastCol = sheet.getLastColumn();
  if (lastCol < 1) return -1;
  const hdr = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  for (let i = 0; i < hdr.length; i++) {
    if (/^\s*plant\s*(?:no|#|number)?\.?\s*$/i.test(String(hdr[i] || ''))) return i + 1;
  }
  return -1;
}

/**
 * Map of header text -> 1-indexed column. Trims whitespace, preserves case.
 */
function buildHeaderIdx_(headersRow) {
  const idx = {};
  for (let i = 0; i < headersRow.length; i++) {
    const h = String(headersRow[i] || '').trim();
    if (h) idx[h] = i + 1;
  }
  return idx;
}

/**
 * Find the comments column for a given tab.
 *   1) Per-tab override from COMMENTS_HEADER_BY_TAB (e.g. Shower unit -> STATUS)
 *   2) First header matching /^comments?$/i
 * Returns -1 if neither matches.
 */
function commentsColForTab_(headerIdx, tabName) {
  const override = COMMENTS_HEADER_BY_TAB[tabName];
  if (override && headerIdx[override]) return headerIdx[override];
  for (const h in headerIdx) {
    if (/^comments?$/i.test(h)) return headerIdx[h];
  }
  return -1;
}

/**
 * Build the full in-memory context for one tab.
 *
 * @return {{
 *   sheet, tabName,
 *   values:       string[][],   // [row][col], 0-indexed in array but row 0 is header row
 *   bgs:          string[][],
 *   headerIdx:    Object<string, number>,   // header -> 1-indexed col
 *   plantCol:     number,                   // 1-indexed
 *   commentsCol:  number,                   // 1-indexed, -1 if none
 *   plantRow:     Object<string, number>,   // PLANTNO (uppercase, trimmed) -> 1-indexed row
 *   dirtyValues:  boolean,
 *   dirtyBgs:     boolean,
 *   mutatedRows:  Set<number>                // 1-indexed rows touched
 * }}
 */
function buildTabContext_(sheet) {
  const tabName = sheet.getName();
  const lastRow = sheet.getLastRow();
  const lastCol = sheet.getLastColumn();
  if (lastRow < 2 || lastCol < 1) return null;

  const range  = sheet.getRange(1, 1, lastRow, lastCol);
  const values = range.getValues();
  const bgs    = range.getBackgrounds();

  const headerIdx = buildHeaderIdx_(values[0]);
  const plantCol = plantNoColIdx_(sheet);
  if (plantCol < 0) return null;

  const commentsCol = commentsColForTab_(headerIdx, tabName);

  const plantRow = {};
  for (let r = 1; r < values.length; r++) {
    const p = String(values[r][plantCol - 1] || '').trim().toUpperCase();
    if (p) plantRow[p] = r + 1;
  }

  return {
    sheet, tabName, values, bgs,
    headerIdx, plantCol, commentsCol, plantRow,
    dirtyValues: false,
    dirtyBgs: false,
    mutatedRows: new Set()
  };
}

/**
 * Returns true if ANY cell on the row has a background color outside the
 * engine-owned whitelist. Engine-owned colors include the legacy #b7e1cd
 * green check from prior data — without that whitelist entry every existing
 * row gets flagged as user-managed.
 */
function isUserHighlighted_(ctx, rowIdx1Based) {
  const row = ctx.bgs[rowIdx1Based - 1];
  if (!row) return false;
  for (let c = 0; c < row.length; c++) {
    const bg = String(row[c] || '').toLowerCase();
    if (!ENGINE_OWNED_COLORS.has(bg)) return true;
  }
  return false;
}

/**
 * Returns true if the given header is in the manual-only set (case-insensitive).
 */
function isManualOnlyHeader_(headerName) {
  if (!headerName) return false;
  const lc = headerName.toString().trim().toLowerCase();
  for (const h of MANUAL_ONLY_HEADERS) {
    if (h.toLowerCase() === lc) return true;
  }
  return false;
}

/**
 * Flush in-memory mutations to the sheet. ONE setValues + ONE setBackgrounds
 * per dirty tab. Optionally apply CLIP wrap to the comments column on
 * mutated rows so wrapped text doesn't blow up row heights.
 */
function flushContext_(ctx) {
  if (!ctx) return;
  const { sheet, values, bgs, mutatedRows, commentsCol } = ctx;
  const nr = values.length;
  const nc = values[0] ? values[0].length : 0;
  if (!nr || !nc) return;

  const range = sheet.getRange(1, 1, nr, nc);
  if (ctx.dirtyValues) range.setValues(values);
  if (ctx.dirtyBgs)    range.setBackgrounds(bgs);

  if (ctx.dirtyValues && commentsCol > 0 && mutatedRows.size) {
    // Apply CLIP wrap to mutated rows in the comments column, batched.
    const sorted = Array.from(mutatedRows).sort(function (a, b) { return a - b; });
    let runStart = null, runEnd = null;
    const flushRun = function () {
      if (runStart === null) return;
      sheet.getRange(runStart, commentsCol, runEnd - runStart + 1, 1)
           .setWrapStrategy(SpreadsheetApp.WrapStrategy.CLIP);
      runStart = runEnd = null;
    };
    for (const r of sorted) {
      if (runStart === null) { runStart = runEnd = r; }
      else if (r === runEnd + 1) { runEnd = r; }
      else { flushRun(); runStart = runEnd = r; }
    }
    flushRun();
  }
}
