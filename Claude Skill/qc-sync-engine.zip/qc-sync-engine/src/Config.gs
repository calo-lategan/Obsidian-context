/*
================================================================================
ALLOWED APIS — every call this project may make
(verified against developers.google.com/apps-script/advanced/drive — Apr 2026)
--------------------------------------------------------------------------------
Drive.Files.get(fileId, {supportsAllDrives:true, fields:'id,name,parents,mimeType,md5Checksum,modifiedTime,size'})
Drive.Files.list({q, corpora:'allDrives', includeItemsFromAllDrives:true, supportsAllDrives:true, pageSize, pageToken, fields, orderBy:'modifiedTime desc'})
Drive.Files.create({name, parents, mimeType}, blob, {supportsAllDrives:true, fields:'id,name,parents'})
Drive.Files.update(fileMeta, fileId, blob, {supportsAllDrives:true, addParents, removeParents, fields})
Drive.Files.remove(fileId, {supportsAllDrives:true})         // trashes (does NOT hard-delete)
Drive.Files.copy({name, parents}, fileId, {supportsAllDrives:true, fields:'id,name,parents'})
Drive.Files.watch({id, type:'web_hook', address, expiration}, fileId, {supportsAllDrives:true})
Drive.Channels.stop({id, resourceId})

SpreadsheetApp:
  Sheet.getRange(r,c,nr,nc).getValues()         // ONE call per tab at context-build
  Sheet.getRange(r,c,nr,nc).getBackgrounds()    // ONE call per tab at context-build
  Sheet.getRange(r,c,nr,nc).setValues(v2d)      // ONE call per dirty tab at flush
  Sheet.getRange(r,c,nr,nc).setBackgrounds(bg)  // ONE call per dirty tab at flush
  Sheet.getRange(r,c,nr,nc).setWrapStrategy(SpreadsheetApp.WrapStrategy.CLIP)
  SpreadsheetApp.getActiveSpreadsheet().toast(msg, title, secs)

PropertiesService.getScriptProperties().{get,set,delete,deleteAll}Property(...)
PropertiesService.getScriptProperties().getProperties()  // one call, cached

Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, str, Utilities.Charset.UTF_8)
Utilities.base64Decode / base64Encode
Utilities.newBlob / blob.getBytes()

UrlFetchApp.fetch(url, {method, headers, payload, muteHttpExceptions:true})  // 30s cap
UrlFetchApp.fetchAll([{url, headers, muteHttpExceptions:true}, ...])       // parallel batch

ScriptApp.newTrigger('resumeSync').timeBased().after(60_000).create()
ScriptApp.getProjectTriggers() -> filter -> deleteTrigger
ScriptApp.getScriptId()

LockService.getScriptLock().tryLock(0)  // non-blocking; abort if another sync active

ANTI-PATTERNS (WILL BREAK SHARED DRIVES OR QUOTAS):
  DriveApp.*                          - does NOT support Shared Drives reliably
  Drive.Files.create() without parents in Shared Drive
  Drive.Files.* without supportsAllDrives:true
  range.setValue / range.setBackground  - 30-50x slower than batch
  for-row getValue loops               - blows execution time budget
  OCR / Drive.Files.export(mimeType:'text/plain')  - NOT the PDF text layer
  Blocking LockService.waitLock(ms)    - use tryLock(0) and bail
  installTrigger created INSIDE long-running loop (counts against limit)
================================================================================
*/

// ============================ IDENTIFIERS ===================================
const SHEET_ID            = '1G1mP78mIpVpddiWkut-d2Br04RaXTf5PW-VnIS3ayOA';
const SOURCE_FOLDER_ID    = '1CgZ2q64X4kOgVkOxLcEbsSeH9AJbbFiU';   // 33-char canonical
const WORKSPACE_NAME      = '_QC_Workspace';
const ACTIVE_FOLDER_NAME  = 'Active';
const ARCHIVE_FOLDER_NAME = 'Archive';
const DIAGNOSTIC_TAB      = '_Diagnostic';
const LOGS_TAB            = '_Logs';

// ============================ COLORS =========================================
// The engine OWNS these two — paints them and may freely repaint over them.
const COLOR_DEFECT        = '#ff9999';   // engine red — defective checkbox cell
const COLOR_NO_INSPECTION = '#ffd966';   // engine orange — no PDF for this plant

// Whitelist of backgrounds the engine treats as "safe to overwrite".
// Anything ELSE on a row marks the row as user-managed -> SKIP entire row.
// Includes #b7e1cd because that is the legacy "passed inspection" green that
// already covers ~280 rows in the live sheet — without it, every existing
// checked row would be flagged as user-highlighted and skipped.
const ENGINE_OWNED_COLORS = new Set([
  '',
  '#ffffff',
  null,
  COLOR_DEFECT,
  COLOR_NO_INSPECTION,
  COLOR_PASS,
  COLOR_NA,
  '#b7e1cd'                              // legacy green check — must be whitelisted
]);

// Colors observed in the wild that MUST trigger user-highlight skip:
//   #ff0000  - Ablution critical (e.g. "Door cylinder needs to be replaced")
//   #4a86e8  - Ablution scrap/decommissioned
//   #ffff00  - Cabins/Shower unit user review marker (1100+ cells on Cabins)
// Anything not in ENGINE_OWNED_COLORS triggers skip - no enumeration needed.

// ============================ EXECUTION LIMITS ==============================
const EXEC_SOFT_CAP_MS           = 4 * 60 * 1000 + 30 * 1000;  // 4:30 - bail
const LOCK_TIMEOUT_MS            = 0;                           // non-blocking
const INSURANCE_TRIGGER_DELAY_MS = 60 * 1000;                   // 60s after bail
const FETCH_BATCH_SIZE           = 50;                           // fetchAll concurrency cap
const CACHE_VERSION              = 3;                            // bump to auto-clear stale cache
const COLOR_PASS                 = '#b7e1cd';                    // green for passed inspection
const COLOR_NA                   = '#d9d9d9';                    // grey for N/A items

// ============================ FILENAME PARSING ==============================
// Permissive: any combination of letters/digits/dots/underscores/hyphens for the
// plant ID, then `-YYMMDD ` then any check-type then optional ` (N)` browser
// duplicate marker then `.pdf`. Validation that the plant exists in a tab
// happens AFTER extraction, not in the regex.
//
// Verified against the 22 real PDFs in the source folder + the local test PDF:
//   ABL.F.40.01-260404 POST PDI.pdf
//   ABL.F.40.01-260404 POST PDI (1).pdf      <- tolerated
//   DR.2.T.32.9-260407 POST PDI.pdf
//   DR.2T.40.01-260407 POST PDI.pdf          <- typo: missing dot - accepted
//   DR.2.TS.32.5-260404 POST PDI.pdf
//   PB-260403 POST PDI.pdf                   <- bare 2-letter - accepted, routed by lookup
//   STC.20.6-260331 POST PDI.pdf
//   PL.107-260330 POST PDI.pdf
const FILENAME_RX = /^\s*([A-Z0-9._-]+?)-(\d{6})\s+(.+?)(?:\s*\(\d+\))?\.pdf$/i;

// ============================ PLANT -> TAB ROUTING ==========================
// Used ONLY when an unknown plant arrives via PDF and the engine needs to
// decide which tab to insert it into. The first-pass resolver scans every
// in-scope tab's column D for an exact match BEFORE falling through to this
// table — these rules only apply to brand-new plants.
//
// Order matters: longest/most-specific prefix MUST come first to prevent
// short prefixes from swallowing long ones (e.g. FLX.* must beat SHC.*
// when matching FLX.SHC.* filenames).
const PREFIX_RULES = [
  { rx: /^FLX\./i,        tab: 'Flexiloo'    },   // beats SHC fallback inside FLX.SHC.*
  { rx: /^DA\.PL\./i,     tab: 'Portaloo'    },
  { rx: /^PL\./i,         tab: 'Portaloo'    },
  { rx: /^DR\.2T?\./i,    tab: 'DRS'         },   // tolerates DR.2T.* typo
  { rx: /^4DR\.ABL\./i,   tab: 'Ablution'    },
  { rx: /^D\.ABL\./i,     tab: 'Ablution'    },
  { rx: /^VIPABL/i,       tab: 'Ablution'    },
  { rx: /^ABL\./i,        tab: 'Ablution'    },
  { rx: /^SHC\./i,        tab: 'Shower unit' },
  { rx: /^MH\./i,         tab: 'Messhall'    },
  { rx: /^TB\./i,         tab: 'Cabins'      },
  { rx: /^OPO\./i,        tab: 'Cabins'      },
  { rx: /^STC\./i,        tab: 'Cabins'      },
  { rx: /^F\.P\.O\./i,    tab: 'Flatpack'    }
];

// In-scope tabs. Anything else (EZGO, Clubcar, Polaris, Kawasaki, Summary,
// New Flatpack, NEW Flexiloos) is OUT OF SCOPE - engine never reads from
// or writes to those tabs.
const IN_SCOPE_TABS = ['DRS','Ablution','Shower unit','Messhall','Cabins','Flatpack','Flexiloo','Portaloo'];

// ============================ COMMENTS COLUMN OVERRIDE ======================
// Most tabs have a header literally named "Comments". Shower unit doesn't -
// it uses "STATUS" as the catch-all column. Engine consults this map first,
// then falls back to scanning row 1 for /^comments?$/i.
const COMMENTS_HEADER_BY_TAB = {
  'Shower unit': 'STATUS'
};

// ============================ MANUAL-ONLY COLUMNS ===========================
// Headers the engine NEVER writes to - reserved for human input only.
// Case-insensitive match.
const MANUAL_ONLY_HEADERS = new Set([
  'Door keys',
  'Keys',
  'Notes'
]);

// ============================ SHEET <- PDF MAPPING ==========================
// SHEET_TO_PDF[tab][sheetHeader] = [pdfLabel1, pdfLabel2, ...]
//
// For a sheet checkbox to become TRUE, EVERY listed pdfLabel must be ✅ (or N/A).
// If ANY listed label is ❌, the sheet cell becomes FALSE + painted red.
// Labels are matched case-insensitive against the parsed PDF item label.
//
// PDF items NOT listed for any sheet header are silently ignored - they are
// "extra" inspection items the form tracks but the sheet doesn't aggregate.
//
// ALIASES tolerate the typos and casing differences observed in real data:
//   "Wash Besin" (PDF) <-> "Washbasin" (sheet)
//   "Light"      (PDF) <-> "Lights"    (sheet)
//   "Floor"      (PDF) <-> "Flooring"  (sheet)
//
// Mappings below are seeded from the ABL.F.40.01 PDF + DRS sheet inspection.
// Other tabs reuse the same PDF item vocabulary the inspectors fill in;
// extend as more PDF samples arrive.
const SHEET_TO_PDF = {

  Ablution: {
    'Flooring':       ['floor'],
    'Walls':          ['structural damage', 'interior damage', 'exterior damage'],
    'Ceiling':        ['structural damage', 'interior damage', 'exterior damage'],
    'Window':         ['window'],
    'WC':             ['wc', 'wc seat cover'],
    'Urinal':         ['urinal'],
    'Interior paint': ['interior paint'],
    'exterior paint': ['exterior paint'],
    'Mirror':         ['mirror'],
    'Washbasin':      ['wash besin', 'water taps'],
    'Lights':         ['light'],
    'Exhaust Fan':    ['exhaust fan'],
    'Door':           ['door']
  },

  DRS: {
    'Flooring':       ['floor'],
    'Walls':          ['structural damage', 'interior damage', 'exterior damage'],
    'Ceiling':        ['structural damage', 'interior damage', 'exterior damage'],
    'Fittings':       ['fittings'],
    'Mirror':         ['mirror'],
    'Washbasin':      ['wash besin', 'water taps'],
    'Toilet':         ['wc', 'wc seat cover'],
    'Door':           ['door'],
    'Shower':         ['shower'],
    'Lights':         ['light'],
    'Windows':        ['window'],
    'Interior paint': ['interior paint'],
    'Exterior paint': ['exterior paint'],
    'ACs':            ['ac']
  },

  'Shower unit': {
    'Flooring':       ['floor'],
    'Walls':          ['structural damage', 'interior damage', 'exterior damage'],
    'Ceiling':        ['structural damage', 'interior damage', 'exterior damage'],
    'Fittings':       ['fittings'],
    'Mirror':         ['mirror'],
    'Washbasin':      ['wash besin', 'water taps'],
    'Lights':         ['light'],
    'Shower':         ['shower'],
    'Shower Curtain': ['shower curtain'],
    'AC':             ['ac'],
    'DOORS':          ['door'],
    'ELECTRICAL':     ['electrical'],
    'WC':             ['wc', 'wc seat cover'],
    'Intrior paint':  ['interior paint'],     // sheet typo preserved
    'exterior paint': ['exterior paint']
  },

  Messhall: {
    'Flooring':       ['floor'],
    'Walls':          ['structural damage', 'interior damage', 'exterior damage'],
    'Ceiling':        ['structural damage', 'interior damage', 'exterior damage'],
    'Fittings':       ['fittings'],
    'AC':             ['ac'],
    'Window Tint':    ['window tint'],
    'Roof':           ['roof'],
    'Lights':         ['light'],
    'Door':           ['door']
  },

  Cabins: {
    'Flooring':       ['floor'],
    'Walls':          ['structural damage', 'interior damage', 'exterior damage'],
    'Ceiling':        ['structural damage', 'interior damage', 'exterior damage'],
    'Interior paint': ['interior paint'],
    'Exterior paint': ['exterior paint'],
    'AC':             ['ac'],
    'Window':         ['window'],
    'Blinds':         ['blinds'],
    'Lights':         ['light'],
    'Door':           ['door']
  },

  Flatpack: {
    'Flooring':       ['floor'],
    'Walls':          ['structural damage', 'interior damage', 'exterior damage'],
    'Ceiling':        ['structural damage', 'interior damage', 'exterior damage'],
    'AC':             ['ac'],
    'Lights':         ['light']
  },

  Flexiloo: {
    'Flooring':       ['floor'],
    'Counter tops':   ['counter tops', 'counter'],
    'Lights':         ['light'],
    'Mirror':         ['mirror'],
    'Fittings':       ['fittings'],
    'Ceilings':       ['structural damage', 'interior damage', 'exterior damage'],
    'Walls':          ['structural damage', 'interior damage', 'exterior damage'],
    'Doors':          ['door'],
    'WC / urinal':    ['wc', 'urinal'],
    'Basin':          ['wash besin', 'water taps']
  },

  Portaloo: {
    'Interior fittings': ['interior fittings', 'fittings', 'wash besin', 'water taps', 'mirror'],
    'Flush lever':       ['flush lever', 'flush', 'wc'],
    'Door lock':         ['door lock', 'door'],
    'Branding':          ['branding decal', 'branding']
  }
};

// ============================ CACHE KEYS ====================================
const CK_DRIFT  = 'driftCache';   // single JSON blob: { plantNo: {fid, rh, ts} }
const CK_RESUME = 'resume:state';
const CK_WATCH  = 'watch:channel';
