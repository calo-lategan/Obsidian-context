/**
 * Drive push notifications + polling fallback.
 *
 * doPost() is invoked anonymously by Drive when the source folder changes.
 * The push channel is registered via Drive.Files.watch() against the source
 * folder; channels expire after 7 days, so a renewal trigger fires at 6.5d.
 *
 * The polling fallback (installPollingTrigger) runs every 10 minutes and
 * catches anything the push missed (network blips, expired channels, etc.).
 */

function doPost(_e) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(0)) return HtmlService.createHtmlOutput('busy');
  try {
    _syncCore_({ force: false, plantFilter: null });
  } catch (err) {
    logError_('doPost', err);
  } finally {
    lock.releaseLock();
  }
  return HtmlService.createHtmlOutput('ok');
}

function doGet() {
  return HtmlService.createHtmlOutput('QC Sync Engine — OK');
}

/**
 * Register a push channel on the source folder.
 * Persists channel id + resourceId in script properties for later stop().
 */
function installDriveWatch() {
  const webAppUrl = PropertiesService.getScriptProperties().getProperty('webAppUrl');
  if (!webAppUrl) {
    SpreadsheetApp.getActive().toast(
      'Set Script Property "webAppUrl" first (deploy as Web App, copy /exec URL)',
      'QC Sync', 8
    );
    return;
  }

  stopDriveWatch();

  const channelId = Utilities.getUuid();
  const expiration = (Date.now() + 7 * 24 * 60 * 60 * 1000).toString();

  const resp = Drive.Files.watch(
    { id: channelId, type: 'web_hook', address: webAppUrl, expiration: expiration },
    SOURCE_FOLDER_ID,
    { supportsAllDrives: true }
  );

  PropertiesService.getScriptProperties().setProperty(CK_WATCH, JSON.stringify({
    id: resp.id,
    resourceId: resp.resourceId,
    expiration: resp.expiration
  }));

  cleanupTriggers_('renewDriveWatch');
  ScriptApp.newTrigger('renewDriveWatch')
    .timeBased()
    .after(6.5 * 24 * 60 * 60 * 1000)
    .create();

  SpreadsheetApp.getActive().toast(
    'Drive watch installed until ' + new Date(parseInt(expiration, 10)).toISOString().slice(0, 16),
    'QC Sync', 6
  );
}

function stopDriveWatch() {
  const raw = PropertiesService.getScriptProperties().getProperty(CK_WATCH);
  if (!raw) return;
  try {
    const obj = JSON.parse(raw);
    Drive.Channels.stop({ id: obj.id, resourceId: obj.resourceId });
  } catch (_) {
    // already stopped or expired
  }
  PropertiesService.getScriptProperties().deleteProperty(CK_WATCH);
}

function renewDriveWatch() {
  installDriveWatch();
}

function installPollingTrigger() {
  cleanupTriggers_('pollSync');
  ScriptApp.newTrigger('pollSync').timeBased().everyMinutes(10).create();
  SpreadsheetApp.getActive().toast('Polling fallback installed (every 10 min)', 'QC Sync', 4);
}

function pollSync() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(0)) return;
  try {
    _syncCore_({ force: false, plantFilter: null });
  } catch (err) {
    logError_('pollSync', err);
  } finally {
    lock.releaseLock();
  }
}

function stopPollingTrigger() {
  cleanupTriggers_('pollSync');
  SpreadsheetApp.getActive().toast('Polling trigger removed', 'QC Sync', 4);
}

function removeAllTriggers() {
  var triggers = ScriptApp.getProjectTriggers();
  var count = 0;
  for (var i = 0; i < triggers.length; i++) {
    ScriptApp.deleteTrigger(triggers[i]);
    count++;
  }
  PropertiesService.getScriptProperties().deleteProperty(CK_WATCH);
  SpreadsheetApp.getActive().toast('Removed ' + count + ' trigger(s)', 'QC Sync', 4);
}
