/**
 * Drift cache: { plantNo: { fid, rh, ts } }
 *   fid = active mirror file ID
 *   rh  = MD5 hash of the engine-owned columns of the row
 *   ts  = last write timestamp (ms)
 *
 * Stored as ONE JSON blob under script property `driftCache` to avoid
 * the 500KB-per-property limit on large fleets. Cache is loaded once per
 * sync, mutated in-memory, and written back at the end.
 *
 * The hash uses ONLY the columns the engine owns (checkboxes + comments) —
 * manual-only columns and the plant-no column are excluded so human edits
 * to those don't trigger false drift.
 */

function readDriftCache_() {
  var raw = PropertiesService.getScriptProperties().getProperty(CK_DRIFT);
  if (!raw) return {};
  try {
    var obj = JSON.parse(raw);
    if (obj.__v !== CACHE_VERSION) return {};
    return obj;
  } catch (_) { return {}; }
}

function writeDriftCache_(obj) {
  obj.__v = CACHE_VERSION;
  PropertiesService.getScriptProperties().setProperty(CK_DRIFT, JSON.stringify(obj));
}

function clearDriftCache_() {
  PropertiesService.getScriptProperties().deleteProperty(CK_DRIFT);
}

/**
 * Hash the engine-owned columns of a plant's row. Excludes the plant-no
 * column and any MANUAL_ONLY_HEADERS.
 */
function hashRow_(ctx, plantNo) {
  const rowIdx = ctx.plantRow[String(plantNo).trim().toUpperCase()];
  if (!rowIdx) return '';
  const row = ctx.values[rowIdx - 1];
  const parts = [];
  for (const hdr in ctx.headerIdx) {
    if (isManualOnlyHeader_(hdr)) continue;
    if (/^plant\s*(no|number|#)?\.?$/i.test(hdr)) continue;
    const c = ctx.headerIdx[hdr];
    parts.push(hdr + '=' + String(row[c - 1]));
  }
  const joined = parts.join('|');
  const digest = Utilities.computeDigest(
    Utilities.DigestAlgorithm.MD5,
    joined,
    Utilities.Charset.UTF_8
  );
  let hex = '';
  for (let i = 0; i < digest.length; i++) {
    const b = digest[i] < 0 ? digest[i] + 256 : digest[i];
    hex += b.toString(16).padStart(2, '0');
  }
  return hex;
}

/**
 * Hash ONLY the SHEET_TO_PDF-mapped checkbox columns (not comments).
 * Used to detect manual checkbox edits without triggering on comment edits.
 */
function hashCheckboxes_(ctx, tabName, plantNo) {
  var rowIdx = ctx.plantRow[String(plantNo).trim().toUpperCase()];
  if (!rowIdx) return '';
  var row = ctx.values[rowIdx - 1];
  var sheetMap = SHEET_TO_PDF[tabName] || {};
  var parts = [];
  for (var hdr in sheetMap) {
    var col = ctx.headerIdx[hdr];
    if (!col) continue;
    if (isManualOnlyHeader_(hdr)) continue;
    parts.push(hdr + '=' + String(row[col - 1]));
  }
  var joined = parts.join('|');
  var digest = Utilities.computeDigest(
    Utilities.DigestAlgorithm.MD5, joined, Utilities.Charset.UTF_8
  );
  var hex = '';
  for (var i = 0; i < digest.length; i++) {
    var b = digest[i] < 0 ? digest[i] + 256 : digest[i];
    hex += b.toString(16).padStart(2, '0');
  }
  return hex;
}
