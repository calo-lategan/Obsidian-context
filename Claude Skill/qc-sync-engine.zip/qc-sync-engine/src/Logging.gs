/**
 * Persistent error/info log tab inside the active spreadsheet.
 * Falls back silently if the sheet can't be reached.
 */

function logError_(fnName, err) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sh = ss.getSheetByName(LOGS_TAB);
    if (!sh) {
      sh = ss.insertSheet(LOGS_TAB);
      sh.getRange(1, 1, 1, 4).setValues([['Timestamp', 'Function', 'Message', 'Stack']]);
      sh.setFrozenRows(1);
      sh.setColumnWidths(1, 1, 160);
      sh.setColumnWidths(2, 1, 180);
      sh.setColumnWidths(3, 1, 480);
      sh.setColumnWidths(4, 1, 540);
    }
    sh.appendRow([
      new Date(),
      String(fnName),
      String((err && err.message) || err || ''),
      String((err && err.stack) || '').slice(0, 800)
    ]);
  } catch (_) {
    // never let logging itself crash a sync
  }
}

function logInfo_(fnName, msg) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sh = ss.getSheetByName(LOGS_TAB);
    if (!sh) {
      sh = ss.insertSheet(LOGS_TAB);
      sh.getRange(1, 1, 1, 4).setValues([['Timestamp', 'Function', 'Message', 'Stack']]);
      sh.setFrozenRows(1);
    }
    sh.appendRow([new Date(), String(fnName), String(msg), '']);
  } catch (_) {
    // ignore
  }
}

function openLogsTab() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(LOGS_TAB);
  if (!sh) sh = ss.insertSheet(LOGS_TAB);
  ss.setActiveSheet(sh);
}
