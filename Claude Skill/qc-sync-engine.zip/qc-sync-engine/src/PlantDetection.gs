/**
 * Plant -> tab routing and auto-add for unknown plants.
 *
 * Two-pass resolver:
 *   1. Exact lookup: scan every in-scope tab's column D for a trimmed,
 *      uppercased match against the plant ID. This handles 99% of cases
 *      because plants are pre-existing in the sheet.
 *   2. Prefix routing (PREFIX_RULES from Config.gs): only used for brand-new
 *      plants that don't yet exist in any tab.
 */

/**
 * O(1) lookup using a pre-built plant->tab index (from tab contexts).
 * Falls back to PREFIX_RULES for brand-new plants not yet in any tab.
 *
 * @param {string} plantNo
 * @param {Object<string, string>} plantToTab  { PLANT_NO: tabName } built at sync start
 * @return {string|null}
 */
function resolveTab_(plantNo, plantToTab) {
  const norm = String(plantNo || '').trim().toUpperCase();
  if (!norm) return null;
  if (plantToTab[norm]) return plantToTab[norm];
  for (const rule of PREFIX_RULES) {
    if (rule.rx.test(norm)) return rule.tab;
  }
  return null;
}

/**
 * Slow path — scans every tab via Sheet API. Only used for single-plant
 * operations (syncSelected, diagnostics). For bulk sync use resolveTab_().
 *
 * @return {string|null} the tab name that contains this plant, or null if no
 *   prefix rule matches and no tab already has it.
 */
function detectTabForPlant_(plantNo) {
  const norm = String(plantNo || '').trim().toUpperCase();
  if (!norm) return null;

  // Pass 1: exact lookup against every in-scope tab
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  for (const name of IN_SCOPE_TABS) {
    const sh = ss.getSheetByName(name);
    if (!sh) continue;
    const col = plantNoColIdx_(sh);
    if (col < 0) continue;
    const lastRow = sh.getLastRow();
    if (lastRow < 2) continue;
    const vals = sh.getRange(2, col, lastRow - 1, 1).getValues();
    for (const row of vals) {
      const v = String(row[0] || '').trim().toUpperCase();
      if (v === norm) return name;
    }
  }

  // Pass 2: prefix routing
  for (const rule of PREFIX_RULES) {
    if (rule.rx.test(norm)) return rule.tab;
  }

  return null;
}

/**
 * Insert a new row in the context for a plant that doesn't exist yet.
 * Mutates ctx in-place AND grows the underlying sheet by one row so flush
 * can range-write into it.
 */
function addPlantRow_(ctx, plantNo) {
  const nc = ctx.values[0] ? ctx.values[0].length : 0;
  if (!nc) return;
  const newRow = new Array(nc).fill('');
  newRow[ctx.plantCol - 1] = String(plantNo).trim().toUpperCase();
  ctx.values.push(newRow);
  ctx.bgs.push(new Array(nc).fill('#ffffff'));
  const newRowIdx = ctx.values.length;
  ctx.plantRow[String(plantNo).trim().toUpperCase()] = newRowIdx;
  ctx.dirtyValues = true;
  ctx.dirtyBgs = true;
  // Grow the sheet so flush's getRange call doesn't out-of-bounds.
  ctx.sheet.insertRowsAfter(ctx.sheet.getLastRow(), 1);
}
