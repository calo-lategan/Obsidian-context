/**
 * PDF text extraction via Google Doc conversion.
 *
 * The Al Laith QC PDFs use FlateDecode compressed content streams, so
 * manual byte-level parsing returns garbage. Instead, we upload the PDF
 * to Drive as a Google Doc (which decompresses and extracts the text layer),
 * export as plain text, then delete the temp file.
 *
 * Temp files are named tmp-qcsync-* and cleaned up in mirrorSourceIntoWorkspace_
 * as a safety net if the finally-block cleanup fails.
 */

/**
 * Extract readable text from a PDF blob.
 *
 * @param {Blob} blob
 * @return {string} plain text content of the PDF
 */
/**
 * Single-PDF text extraction (used by diagnostic dump).
 */
function extractPdfText_(blob) {
  var result = extractPdfTextBatch_({ _single: blob });
  return result._single || '';
}

/**
 * Batch-extract text from multiple PDF blobs.
 * Serial upload (can't batch Drive create) + parallel export + parallel delete.
 *
 * @param {Object<string, Blob>} blobMap  { key: Blob }
 * @return {Object<string, string>}       { key: plainText }
 */
function extractPdfTextBatch_(blobMap) {
  var token = ScriptApp.getOAuthToken();
  var keys = [];
  for (var k in blobMap) { if (blobMap[k]) keys.push(k); }
  if (!keys.length) return {};

  // ---- Step 1: Serial upload as Google Docs (conversion) ----
  var tempDocIds = {};
  for (var i = 0; i < keys.length; i++) {
    try {
      var tempFile = Drive.Files.create(
        { name: 'tmp-qcsync-' + Date.now() + '-' + i,
          mimeType: 'application/vnd.google-apps.document' },
        blobMap[keys[i]], { fields: 'id' }
      );
      tempDocIds[keys[i]] = tempFile.id;
    } catch (e) {
      logError_('extractPdfTextBatch_', 'Upload ' + keys[i] + ': ' + e.message);
    }
  }

  // ---- Step 2: Parallel export as plain text via fetchAll ----
  var exportReqs = [];
  var exportOrder = [];
  for (var k in tempDocIds) {
    exportReqs.push({
      url: 'https://www.googleapis.com/drive/v3/files/' + tempDocIds[k] +
           '/export?mimeType=' + encodeURIComponent('text/plain'),
      headers: { Authorization: 'Bearer ' + token },
      muteHttpExceptions: true
    });
    exportOrder.push(k);
  }

  var texts = {};
  for (var b = 0; b < exportReqs.length; b += FETCH_BATCH_SIZE) {
    var batch = exportReqs.slice(b, b + FETCH_BATCH_SIZE);
    var order = exportOrder.slice(b, b + FETCH_BATCH_SIZE);
    var resps = UrlFetchApp.fetchAll(batch);
    for (var j = 0; j < resps.length; j++) {
      texts[order[j]] = resps[j].getResponseCode() === 200
        ? resps[j].getContentText() : '';
    }
  }

  // ---- Step 3: Parallel delete via fetchAll ----
  var delReqs = [];
  for (var k in tempDocIds) {
    delReqs.push({
      url: 'https://www.googleapis.com/drive/v3/files/' + tempDocIds[k],
      method: 'delete',
      headers: { Authorization: 'Bearer ' + token },
      muteHttpExceptions: true
    });
  }
  for (var b = 0; b < delReqs.length; b += FETCH_BATCH_SIZE) {
    UrlFetchApp.fetchAll(delReqs.slice(b, b + FETCH_BATCH_SIZE));
  }

  return texts;
}

function unescapePdfString_(s) {
  return s
    .replace(/\\n/g, '\n')
    .replace(/\\r/g, '\r')
    .replace(/\\t/g, '\t')
    .replace(/\\\\/g, '\\')
    .replace(/\\\(/g, '(')
    .replace(/\\\)/g, ')')
    .replace(/\\([0-7]{1,3})/g, function (_, o) { return String.fromCharCode(parseInt(o, 8)); });
}

function hexToUtf16BE_(hex) {
  if (hex.length < 4) return '';
  if (hex.slice(0, 4).toUpperCase() === 'FEFF') hex = hex.slice(4);
  let out = '';
  for (let i = 0; i + 3 < hex.length; i += 4) {
    const cp = parseInt(hex.substr(i, 4), 16);
    if (!isNaN(cp)) out += String.fromCharCode(cp);
  }
  return out;
}

// ============================================================================
// Structured parse — text -> { plantNo, checkDate, inspector, items, note }
// ============================================================================

const STATE_PASS_RX = /^(?:✅|☑|✔|OK|PASS|YES|CHECKED)$/i;
const STATE_FAIL_RX = /^(?:❌|✗|✘|×|FAIL|NO|DEFECT(?:IVE)?)$/i;
const STATE_NA_RX   = /^(?:N\/?A|NOTAPPLICABLE)$/i;

/**
 * @param {string} text   raw text from extractPdfText_
 * @param {string} fallbackPlant  used if the header field is missing
 * @return {{plantNo, checkDate, checkType, inspector, items, note}}
 */
function parseQcText_(text, fallbackPlant) {
  const rec = {
    plantNo: fallbackPlant ? String(fallbackPlant).trim().toUpperCase() : null,
    checkDate: null,
    checkType: null,
    inspector: null,
    items: [],
    note: ''
  };

  // ---- header fields ------------------------------------------------------
  // Plant Number: ABL.F.40.01
  let m = text.match(/Plant\s*Number\s*[:\-]\s*([A-Z0-9._/\\-]+)/i);
  if (m) rec.plantNo = m[1].trim().toUpperCase();

  // Inspection Date: 04/04/2026 14:19:40   (DD/MM/YYYY HH:MM:SS)
  m = text.match(/Inspection\s*Date\s*[:\-]\s*(\d{1,2})\/(\d{1,2})\/(\d{2,4})/i);
  if (m) {
    let y = m[3];
    if (y.length === 2) y = '20' + y;
    rec.checkDate = y + '-' + String(m[2]).padStart(2, '0') + '-' + String(m[1]).padStart(2, '0');
  }

  // Inspector Name: calo.lategan@allaith.com   (or plain name)
  m = text.match(/Inspector\s*Name\s*[:\-]\s*([^\s].*?)(?:\s+(?:Type|Plant|Description|Inspection|1\s+GENERAL)|$)/i);
  if (m) rec.inspector = m[1].trim();

  // Also check comments text for "inspection by <name>" or "by <name>" —
  // this takes PRIORITY over the header Inspector Name field.
  const byMatch = text.match(/(?:inspection\s+by|by)\s+([A-Za-z][A-Za-z\s.'-]{1,40}?)(?:\s*[-,.|]|\s+(?:unit|needs|condition|ok|good|bad|all|the|check|date|type|plant|1\s+GENERAL)|\s*$)/i);
  if (byMatch) {
    const nameFromComment = byMatch[1].trim();
    if (nameFromComment.length >= 2) rec.inspector = nameFromComment;
  }

  // Type: FEMALE ABLUTION   -> use as checkType fallback
  m = text.match(/Type\s*[:\-]\s*([A-Z][A-Z\s]+?)(?:\s+(?:Plant|Description|Inspector))/i);
  if (m) rec.checkType = m[1].trim();

  // Comments (State Machine Condition): <text>  ... before "All the Inspections"
  m = text.match(/Comments[^:]*:\s*([\s\S]*?)(?:All\s+the\s+Inspections|Engineer\s*Signature|$)/i);
  if (m) rec.note = m[1].replace(/\s+/g, ' ').trim();

  // ---- checklist items ----------------------------------------------------
  // Walk tokens looking for patterns: <bullet-letter> <Capitalized words...> <state>
  // Section headers like "1 GENERAL" or "4 RESTROOM" start with a digit and are
  // skipped because the bullet detector requires a single lowercase letter.
  const tokens = text.split(/\s+/).filter(Boolean);

  let curBullet = null;
  let curLabel  = [];
  const items = [];

  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];

    if (STATE_PASS_RX.test(t) || STATE_FAIL_RX.test(t) || STATE_NA_RX.test(t)) {
      // close current item
      if (curBullet && curLabel.length) {
        const label = curLabel.join(' ').trim();
        const state = STATE_PASS_RX.test(t) ? true
                    : STATE_NA_RX.test(t)   ? 'NA'
                    : false;
        items.push({ bullet: curBullet, label: label.toLowerCase(), state });
      }
      curBullet = null;
      curLabel = [];
      continue;
    }

    // Bullet candidate: single lowercase a-z, AND next token starts with uppercase
    if (/^[a-z]$/.test(t)) {
      const next = tokens[i + 1] || '';
      if (/^[A-Z]/.test(next)) {
        // close any pending item that lost its state somehow
        if (curBullet && curLabel.length) {
          items.push({
            bullet: curBullet,
            label: curLabel.join(' ').trim().toLowerCase(),
            state: null
          });
        }
        curBullet = t;
        curLabel = [];
        continue;
      }
    }

    // Inside a label
    if (curBullet) curLabel.push(t);
  }

  // Filter out null-state and obvious noise (headers).
  rec.items = items.filter(function (it) {
    if (it.state === null) return false;
    if (!it.label || it.label.length < 2 || it.label.length > 60) return false;
    return true;
  });

  // ---- Form field fallback: if text parsing found 0 items, try FORMCB ----
  if (rec.items.length === 0) {
    var formRx = /FORMCB:([^:]+):(CHECKED|UNCHECKED)/g;
    var fm;
    while ((fm = formRx.exec(text)) !== null) {
      var fieldName = fm[1].trim();
      var checked = fm[2] === 'CHECKED';
      // Try to extract bullet + label from field name patterns:
      //   "Check Box - a Structural Damage"  or  "a Structural Damage"
      var bulletMatch = fieldName.match(/(?:Check\s*Box\s*[-–—]?\s*)?([a-z])\s+(.+)/i);
      if (bulletMatch) {
        rec.items.push({
          bullet: bulletMatch[1].toLowerCase(),
          label: bulletMatch[2].trim().toLowerCase(),
          state: checked
        });
      } else {
        // Use full field name as label
        rec.items.push({
          bullet: '?',
          label: fieldName.toLowerCase(),
          state: checked
        });
      }
    }
  }

  // ---- Form field fallback: inspector from FORMTF ----
  if (!rec.inspector) {
    var inspRx = /FORMTF:(?:Inspector\s*(?:Name)?|Inspected\s*By)[^:]*:([^F][^O][^R].*?)(?:\s+FORM[CT][BF]:|$)/i;
    var im = text.match(inspRx);
    if (im) rec.inspector = im[1].trim();
  }

  // ---- Form field fallback: comments/note from FORMTF ----
  if (!rec.note) {
    var noteRx = /FORMTF:(?:Comments?|Remarks?|Notes?|Condition)[^:]*:([^F][^O][^R].*?)(?:\s+FORM[CT][BF]:|$)/i;
    var nm = text.match(noteRx);
    if (nm) rec.note = nm[1].trim();
  }

  return rec;
}
