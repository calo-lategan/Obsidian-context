/**
 * Timeout-safe continuation.
 *
 * Apps Script kills executions at 6 minutes. The engine bails at 4:30
 * (EXEC_SOFT_CAP_MS), saves the remaining plant queue to a script property,
 * and queues a 60-second-delayed insurance trigger BEFORE the chunk even
 * starts so a mid-chunk crash still resumes. resumeSync() picks up exactly
 * where it left off.
 */

/**
 * Save resume state with the remaining plant queue AND the outcome map.
 * Outcome is compressed to { plant: fileId } to stay under the 500KB
 * PropertiesService limit (~50 bytes/plant = 35KB for 700 plants).
 *
 * @param {string[]} remainingPlants
 * @param {Object} outcome  full outcome from mirrorSourceIntoWorkspace_()
 */
function saveResumeState_(remainingPlants, outcome) {
  // Compress outcome to just { plant: activeFileId }
  const slim = {};
  if (outcome) {
    for (const p in outcome) {
      slim[p] = { activeFileId: outcome[p].activeFileId };
    }
  }
  PropertiesService.getScriptProperties().setProperty(CK_RESUME, JSON.stringify({
    queue: remainingPlants,
    outcome: slim,
    ts: Date.now()
  }));
}

function loadResumeState_() {
  const raw = PropertiesService.getScriptProperties().getProperty(CK_RESUME);
  if (!raw) return null;
  try { return JSON.parse(raw); } catch (_) { return null; }
}

function clearResumeState_() {
  PropertiesService.getScriptProperties().deleteProperty(CK_RESUME);
  cleanupTriggers_('resumeSync');
}

/**
 * Critical: queue the insurance trigger BEFORE heavy work starts.
 * If this chunk crashes, the trigger still fires and resumeSync recovers.
 */
function queueInsuranceTrigger_() {
  cleanupTriggers_('resumeSync');
  ScriptApp.newTrigger('resumeSync')
    .timeBased()
    .after(INSURANCE_TRIGGER_DELAY_MS)
    .create();
}

/**
 * Recovery entry point. Called either by the insurance trigger or manually.
 */
function resumeSync() {
  const state = loadResumeState_();
  if (!state || !state.queue || !state.queue.length) {
    clearResumeState_();
    return;
  }
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(LOCK_TIMEOUT_MS)) return;
  try {
    // Don't pass plantFilter — let _syncCore_ detect the resume state
    // and reuse the cached outcome instead of re-scanning the folder.
    _syncCore_({ force: false, plantFilter: null });
  } finally {
    lock.releaseLock();
  }
}

function cleanupTriggers_(handlerName) {
  const triggers = ScriptApp.getProjectTriggers();
  for (const t of triggers) {
    if (t.getHandlerFunction() === handlerName) ScriptApp.deleteTrigger(t);
  }
}
