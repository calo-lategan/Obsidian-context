/**
 * Single source of truth for every Drive API v3 call in the project.
 * Every other file MUST go through these wrappers — no raw Drive.Files.*
 * calls elsewhere. This prevents the supportsAllDrives footgun from
 * silently breaking Shared Drive operations.
 *
 * The source folder lives on a Shared Drive, so every list/get/copy/update/
 * remove/watch call MUST pass `supportsAllDrives: true` (and listing requires
 * `corpora: 'allDrives'` + `includeItemsFromAllDrives: true`).
 */

const DRIVE_OPTS = { supportsAllDrives: true };
const LIST_OPTS  = {
  corpora: 'allDrives',
  includeItemsFromAllDrives: true,
  supportsAllDrives: true
};

function drv_get_(id, fields) {
  return Drive.Files.get(id, Object.assign({
    fields: fields || 'id,name,parents,mimeType,md5Checksum,modifiedTime,size'
  }, DRIVE_OPTS));
}

function drv_listInFolder_(folderId, extraQ) {
  const results = [];
  const q = `'${folderId}' in parents and trashed = false` + (extraQ ? ' and ' + extraQ : '');
  let pageToken = null;
  do {
    const r = Drive.Files.list(Object.assign({
      q,
      pageSize: 1000,
      pageToken,
      fields: 'nextPageToken,files(id,name,parents,mimeType,md5Checksum,modifiedTime,size)',
      orderBy: 'modifiedTime desc'
    }, LIST_OPTS));
    if (r.files) for (const f of r.files) results.push(f);
    pageToken = r.nextPageToken;
  } while (pageToken);
  return results;
}

function drv_findOrCreateFolder_(parentId, name) {
  const safe = name.replace(/'/g, "\\'");
  const existing = drv_listInFolder_(
    parentId,
    `mimeType = 'application/vnd.google-apps.folder' and name = '${safe}'`
  );
  if (existing.length) return existing[0].id;
  const created = Drive.Files.create({
    name,
    parents: [parentId],
    mimeType: 'application/vnd.google-apps.folder'
  }, null, Object.assign({ fields: 'id' }, DRIVE_OPTS));
  return created.id;
}

function drv_copy_(srcFileId, newName, destFolderId) {
  return Drive.Files.copy(
    { name: newName, parents: [destFolderId] },
    srcFileId,
    Object.assign({ fields: 'id,name,parents,modifiedTime' }, DRIVE_OPTS)
  );
}

function drv_move_(fileId, oldParentId, newParentId, newName) {
  const body = newName ? { name: newName } : {};
  return Drive.Files.update(body, fileId, null, Object.assign({
    addParents: newParentId,
    removeParents: oldParentId,
    fields: 'id,name,parents'
  }, DRIVE_OPTS));
}

function drv_trash_(fileId) {
  return Drive.Files.update({ trashed: true }, fileId, null,
    Object.assign({ fields: 'id' }, DRIVE_OPTS));
}

/**
 * Download raw bytes of a binary file (PDF). Apps Script's Drive Advanced
 * Service does NOT expose binary download — we must call the REST endpoint
 * directly with alt=media and an OAuth bearer token.
 */
function drv_blob_(fileId) {
  const url = 'https://www.googleapis.com/drive/v3/files/' +
              encodeURIComponent(fileId) +
              '?alt=media&supportsAllDrives=true';
  const resp = UrlFetchApp.fetch(url, {
    headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() },
    muteHttpExceptions: true
  });
  const code = resp.getResponseCode();
  if (code !== 200) {
    throw new Error('drv_blob_ ' + fileId + ': HTTP ' + code + ' ' + resp.getContentText().slice(0, 200));
  }
  return resp.getBlob().setName(fileId + '.pdf');
}

/**
 * Batch-download PDF blobs using UrlFetchApp.fetchAll() for parallelism.
 * Batches in groups of FETCH_BATCH_SIZE to stay within rate limits.
 *
 * @param {string[]} fileIds  array of Drive file IDs
 * @return {Object<string, Blob>}  { fileId: Blob } — failed downloads omitted
 */
function drv_blobBatch_(fileIds) {
  if (!fileIds.length) return {};
  const token = ScriptApp.getOAuthToken();
  const results = {};

  for (let i = 0; i < fileIds.length; i += FETCH_BATCH_SIZE) {
    const batchIds = fileIds.slice(i, i + FETCH_BATCH_SIZE);
    const requests = batchIds.map(function(fid) {
      return {
        url: 'https://www.googleapis.com/drive/v3/files/' +
             encodeURIComponent(fid) + '?alt=media&supportsAllDrives=true',
        headers: { Authorization: 'Bearer ' + token },
        muteHttpExceptions: true
      };
    });
    const resps = UrlFetchApp.fetchAll(requests);
    for (let j = 0; j < resps.length; j++) {
      if (resps[j].getResponseCode() === 200) {
        results[batchIds[j]] = resps[j].getBlob().setName(batchIds[j] + '.pdf');
      } else {
        logError_('drv_blobBatch_', 'HTTP ' + resps[j].getResponseCode() + ' for ' + batchIds[j]);
      }
    }
  }
  return results;
}

/**
 * Batch-list PDFs inside multiple folders via REST API + fetchAll().
 * Much faster than calling drv_listInFolder_() sequentially per folder.
 *
 * @param {string[]} folderIds
 * @return {Object<string, Object[]>}  { folderId: [file, ...] }
 */
function drv_listSubfolderFiles_(folderIds) {
  if (!folderIds.length) return {};
  var token = ScriptApp.getOAuthToken();
  var results = {};

  for (var i = 0; i < folderIds.length; i += FETCH_BATCH_SIZE) {
    var batchIds = folderIds.slice(i, i + FETCH_BATCH_SIZE);
    var requests = batchIds.map(function(fid) {
      var q = "'" + fid + "' in parents and trashed = false and mimeType != 'application/vnd.google-apps.folder'";
      return {
        url: 'https://www.googleapis.com/drive/v3/files' +
             '?q=' + encodeURIComponent(q) +
             '&corpora=allDrives&includeItemsFromAllDrives=true&supportsAllDrives=true' +
             '&pageSize=1000' +
             '&fields=' + encodeURIComponent('files(id,name,mimeType,modifiedTime,size)') +
             '&orderBy=' + encodeURIComponent('modifiedTime desc'),
        headers: { Authorization: 'Bearer ' + token },
        muteHttpExceptions: true
      };
    });
    var resps = UrlFetchApp.fetchAll(requests);
    for (var j = 0; j < resps.length; j++) {
      if (resps[j].getResponseCode() === 200) {
        var data = JSON.parse(resps[j].getContentText());
        results[batchIds[j]] = data.files || [];
      } else {
        logError_('drv_listSubfolderFiles_', 'HTTP ' + resps[j].getResponseCode() + ' for folder ' + batchIds[j]);
        results[batchIds[j]] = [];
      }
    }
  }
  return results;
}
