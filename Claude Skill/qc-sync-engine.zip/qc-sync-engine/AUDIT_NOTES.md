# Live Audit Findings — Al Laith QC Sync Engine

**Captured:** 2026-04-08 via auditAll() run in bound Apps Script project + manual PDF parse

## In-Scope Tabs (8)
DRS · Ablution · Shower unit · Messhall · Cabins · Flatpack · Flexiloo · Portaloo

(Out of scope: EZGO, ClubCar, Polaris, Kawasaki, Summary, New Flatpack, NEW Flexiloos)

---

## Per-Tab Inventory

### DRS
- **Rows**: 18, **Cols**: 20
- **Plant col**: D (`Plant No.`)
- **Comments col**: T (`Comments`)
- **Headers**: `Category, Description, Size, Plant No., Flooring, Walls, Ceiling, Fittings, Mirror, Washbasin, Toilet, Door, Door keys, Shower, Lights, Windows, Interior paint, Exterior paint, ACs, Comments`
- **Existing colors**: `#b7e1cd`(161) — light green check rows only. No user paints.
- **Plant ID format**: `DR.2.T.<size>.<unit>` and `DR.2.TS.<size>.<unit>` (e.g. `DR.2.T.32.3`, `DR.2.TS.32.1`, `DR.2.T.40.1`)

### Ablution
- **Rows**: 66, **Cols**: 19
- **Plant col**: D (`Plant No.`)
- **Comments col**: S (`Comments`)
- **Headers**: `Category, Description, Size, Plant No., Flooring, Walls, Ceiling, Window, WC, Urinal, Interior paint, exterior paint, Mirror, Washbasin, Lights, Exhaust Fan, Door, Door keys, Comments`
  - ⚠️ Note: `exterior paint` is lowercase-e, `Interior paint` is capital-I — INCONSISTENT
- **Existing colors**:
  - `#ff0000`(14) — 🟥 user-painted critical row (e.g. "Door cylinder needs to be replaced")
  - `#b7e1cd`(47) — 🟢 existing check rows
  - `#ffd966`(60) — 🟧 existing "No inspection" markers (matches engine orange exactly)
  - `#4a86e8`(19) — 🟦 user-painted "Scrap" row
- **Plant ID formats** (all real, observed):
  - `VIPABLM/F/32.1`, `VIPABLM/F/32.2` — VIP, slash-separated
  - `D.ABL.10.2`, `D.ABL.10.5` — Disabled prefix
  - `4DR.ABL.16.1`, `4DR.ABL.20.1` — 4-Door, leading digit
  - ` ABL.10.2` — ⚠️ has LEADING SPACE in source data (must trim)
  - `ABL.F.20.11`, `ABL.F.20.7` — standard Female
  - `ABL.M.20.10`, `ABL.M.20.6` — standard Male
  - `ABL.M/F.20.13`, `ABL.M/F.20.18` — Mixed Male/Female (slash inside)

### Shower unit
- **Rows**: 6, **Cols**: 20
- **Plant col**: D (`Plant No.`)
- **Comments col**: ❌ NONE (uses `STATUS` instead — last column index 20)
- **Headers**: `Category, Description, Size, Plant No., Flooring, Walls, Ceiling, Fittings, Mirror, Washbasin, Lights, Shower, Shower Curtain, AC, DOORS, ELECTRICAL, WC, Intrior paint, exterior paint, STATUS`
  - ⚠️ Note: `Intrior paint` (typo: missing 'e'), `DOORS` and `ELECTRICAL` ALL CAPS, `STATUS` instead of `Comments`
- **Existing colors**: `#b7e1cd`(41), `#ffff00`(40) — 🟡 yellow user highlights
- **Plant ID format**: `SHC.F.20.1`, `SHC.M.20..1` (⚠️ DOUBLE-DOT typo in source — `SHC.M.20..1`), `SHC.20.3`, `SHC.20.4`, `SHC.20.5`

### Messhall
- **Rows**: 11, **Cols**: 14
- **Plant col**: D, **Comments col**: N (`Comments`)
- **Headers**: `Category, Description, Size, Plant No., Flooring, Walls, Ceiling, Fittings, AC, Window Tint, Roof, Lights, Door, Comments`
- **Existing colors**: `#ffd966`(10) only — engine orange
- **Plant ID format**: `MH.40.1/E`, `MH.40.10/E`, `MH.40.4` — slash-suffix `/E` for some units

### Cabins
- **Rows**: 273 (LARGEST tab), **Cols**: 16
- **Plant col**: D, **Comments col**: P (`Comments`)
- **Headers**: `Category, Description, Size, Plant No., Flooring, Walls, Ceiling, Interior paint, Exterior paint, AC, Window, Blinds, Lights, Door, Door keys, Comments`
- **Existing colors**:
  - `#ffd966`(198) — engine orange
  - `#b7e1cd`(36) — green checks
  - `#ffff00`(1120) — 🟡 MASSIVE yellow paint (over 1000 cells!) — primary user highlight color on this tab
- **Plant ID formats**:
  - `TB.10.10`, `TB.10.11`, `TB.10.4` — TB prefix (Toilet Block?)
  - `OPO.16.3`, `OPO.20.1`, `OPO.20.10` — OPO prefix (Open Plan Office?)
  - `STC.20.3`, `STC.20.5`, `STC.20.6` — STC prefix
  - ⚠️ THREE different prefix families — none match my old Config's `CAB.*` assumption

### Flatpack
- **Rows**: 6, **Cols**: 10
- **Plant col**: D, **Comments col**: J (`Comments`)
- **Headers**: `Category, Description, Size, Plant No., Flooring, Walls, Ceiling, AC, Lights, Comments`
- **Existing colors**: `#ffd966`(5) only
- **Plant ID format**: `F.P.O.20.1`, `F.P.O.20.2`, `F.P.O.20.3` — `F.P.O` (each letter dotted!), NOT `FP.*`

### Flexiloo
- **Rows**: 230, **Cols**: 15
- **Plant col**: D, **Comments col**: O (`Comments`)
- **Headers**: `Category, Description, Size, Plant No., Flooring, Counter tops, Lights, Mirror, Fittings, Ceilings, Walls, Doors, WC / urinal, Basin, Comments`
  - Plurals: `Ceilings, Doors`
- **Existing colors**: `#ffd966`(228) only
- **Plant ID formats**:
  - `FLX.EAWC.001`, `FLX.EAWC.002` — Easy Access WC, 3-digit suffix
  - `FLX.SHC.001`, `FLX.SHC.002` — Shower Cubicle (⚠️ shares `SHC` with Shower unit tab)
  - `FLX.UR.004`, `FLX.UR.005` — Urinal

### Portaloo
- **Rows**: 109, **Cols**: 9
- **Plant col**: D, **Comments col**: I (`Comments`)
- **Headers**: `Category, Spec, Type, Plant No., Interior fittings, Flush lever, Door lock, Branding, Comments`
  - ⚠️ Different schema: `Spec, Type` instead of `Description, Size`
- **Existing colors**: `#ffd966`(99), `#b7e1cd`(36)
- **Plant ID formats**:
  - `DA.PL.57`, `DA.PL.58` — Disabled portaloo
  - `PL.03`, `PL.09`, `PL.100`, `PL.115` — Standard portaloo

---

## Color Whitelist (ENGINE_OWNED_COLORS)

A row should be considered user-highlighted (engine SKIPS) if it has ANY background color outside this set:

| Hex | Origin | Status |
|---|---|---|
| `''` (empty) | default | engine-owned |
| `#ffffff` | white default | engine-owned |
| `null` | default | engine-owned |
| `#ffd966` | engine orange ("No inspection") | engine-owned |
| `#ff9999` | engine red (defect, future) | engine-owned |
| `#b7e1cd` | EXISTING green checks (legacy data, every checked row uses this) | **MUST be whitelisted** or every row gets flagged as user-managed |

**User-only colors** (any of these on a row → SKIP entirely):
| Hex | Where | Meaning |
|---|---|---|
| `#ff0000` | Ablution | Critical defect (e.g. "Door cylinder needs to be replaced") |
| `#4a86e8` | Ablution | Scrap/decommissioned |
| `#ffff00` | Cabins, Shower unit | User-flagged for review |

---

## Source Folder — Resolved

**Original (broken)**: `1CgZ2q64X4kOgVkOxLcEbsSeH9AJbbFiUAl` (34 chars, trailing `Al` was actually "Al Laith" from description)
**Corrected (33 chars)**: `1CgZ2q64X4kOgVkOxLcEbsSeH9AJbbFiU`
**Path**: `Shared drives / 10. Yard & Store / QC Logs - AL - S&R`
**Bound Apps Script account**: `calo.lategan@allaith.com`
**PDF count**: 22 (as of 2026-04-08)

### Complete File List (22 PDFs)
```
DR.2T.40.01-260407 POST PDI.pdf       ⚠️ TYPO: missing dot — should be DR.2.T.40.01
DR.2.T.32.9-260407 POST PDI.pdf
ABL.F.40.01-260404 POST PDI.pdf       ← test PDF (parsed locally)
ABL.F.40.02-260404 POST PDI.pdf
DR.2.T.32.8-260404 POST PDI.pdf
DR.2.T.32.3-260404 POST PDI.pdf
DR.2.TS.32.5-260404 POST PDI.pdf
DR.2.TS.32.6-260404 POST PDI.pdf
PB-260403 POST PDI.pdf                 ⚠️ UNKNOWN PREFIX "PB" — no tab match, must skip+log
STC.20.6-260331 POST PDI.pdf           → Cabins via STC.* rule
STC.40.8-260331 POST PDI.pdf
STC.20.5-260331 POST PDI.pdf
STC.40.5-260331 POST PDI.pdf
PL.15-260330 POST PDI.pdf
PL.145-260330 POST PDI.pdf
PL.30-260330 POST PDI.pdf
PL.03-260330 POST PDI.pdf
PL.116-260330 POST PDI.pdf
PL.86-260330 POST PDI.pdf
PL.107-260330 POST PDI.pdf
PL.161-260330 POST PDI.pdf
PL.59-260330 POST PDI.pdf
```

### Filename Pattern (verified against all 22)
`<plant>-<YYMMDD> <checkType>.pdf`
- All current files use checkType `POST PDI`
- All dates are 6-digit YYMMDD (no separators inside the date)
- Plant ID can include: letters, digits, dots, underscores, hyphens
- No file in current set has the `(N)` browser duplicate suffix, but parser must tolerate it (test PDF in Downloads has it)

### Edge Cases in Real Data
- **`DR.2T.40.01`** — missing dot (typo) — must accept as plant ID
- **`PB`** — bare 2-letter plant ID, no dots — must NOT auto-create row in arbitrary tab
- **`ABL.F.40.02`** — note `40.02` (zero-padded) vs sheet's `ABL.F.20.11` (un-padded) — exact-match lookup is fragile, must do trimmed-uppercase comparison

---

## Real PDF Parse — `ABL.F.40.01-260404 POST PDI (1).pdf`

### Filename Decomposition
| Field | Value |
|---|---|
| Plant ID | `ABL.F.40.01` |
| Date (YYMMDD) | `260404` (= 2026-04-04) |
| Check Type | `POST PDI` |
| Trailing | ` (1)` (browser duplicate marker — strip before parsing) |

### Header Fields (from text layer)
| Field | Value |
|---|---|
| Inspection ID | `1de9e8ab` |
| Inspection Date | `04/04/2026 14:19:40` (DD/MM/YYYY HH:MM:SS) |
| Type | `FEMALE ABLUTION` |
| Plant Number | `ABL.F.40.01` |
| Description | `ABLUTION FEMALE (40FT X 12FT / 12M X 3.6M)` |
| Inspector Name | `calo.lategan@allaith.com` (email format) |

### Layout — 2-column form
Each text line contains items from BOTH columns (left section + right section):
```
a Structural Damage ✅ a Exterior Damage ✅
b Plumbing ✅ b Exterior Paint ❌
c AC ✅ c Water Pump Motor ✅
d Cleaning ✅ 4 RESTROOM
3 INTERNAL a Wash Besin ✅
a Interior Damage ✅ b Water Taps ✅
...
```

### Sections + Items (raw labels exactly as in PDF)
**1 GENERAL**: a Structural Damage, b Plumbing, c AC, d Cleaning  
**2 EXTERNAL**: a Exterior Damage, b Exterior Paint, c Water Pump Motor  
**3 INTERNAL**: a Interior Damage, b Interior Paint, c Light, d Floor, e Electrical, f Exhaust Fan, g Door, h Window, i Fire Extinguisher  
**4 RESTROOM**: a Wash Besin, b Water Taps, c Hand Soap Dispenser, d Urinal, e WC, f WC Seat Cover, g Tissue Holder, h Mirror

### State Tokens
| Token | State |
|---|---|
| ✅ | passed |
| ❌ | defective |
| N/A | not applicable |

Legend in PDF: `Checked: ✅ Defective: ❌ Not Applicable: N/A`

### Comments Field
```
Comments (State Machine Condition): Before loading we will finished painniting
Inspection done by yadav
```
Note: TWO lines. Second line is the signing inspector's note (different from Inspector Name email field).

### Footer
`All the Inspections Carried out on 04/04/2026 14:19:40 of PDI, ABL.F.40.01 is Found OK.`
`Engineer Signature: Calo Lategan`

---

## Sheet ⇄ PDF Mapping (NEW data structure)

The plan's `ALIAS_MAP` and `COMPOUND_MAP` were backwards. Correct shape:

```js
const SHEET_TO_PDF = {
  TabName: {
    SheetHeader: ['pdfLabel1', 'pdfLabel2', ...]  // ALL must be ✅/NA for sheet checkbox
  }
}
```

### Ablution mapping (from ABL.F.40.01 PDF)
| Sheet header | PDF item(s) — ALL must pass |
|---|---|
| Flooring | `floor` |
| Walls | `structural damage`, `interior damage`, `exterior damage` |
| Ceiling | `structural damage`, `interior damage`, `exterior damage` |
| Window | `window` |
| WC | `wc`, `wc seat cover` |
| Urinal | `urinal` |
| Interior paint | `interior paint` |
| exterior paint | `exterior paint` |
| Mirror | `mirror` |
| Washbasin | `wash besin`, `water taps` |
| Lights | `light` |
| Exhaust Fan | `exhaust fan` |
| Door | `door` |
| Door keys | _MANUAL_ONLY_ |

### PDF items with NO Ablution sheet column (silently ignored, NOT flagged as defects)
- Plumbing, AC, Cleaning, Water Pump Motor, Electrical, Hand Soap Dispenser, Tissue Holder, Fire Extinguisher

> Mappings for the other 7 tabs require sample PDFs from each. The engine MUST tolerate missing PDFs per tab and NOT panic if `SHEET_TO_PDF[tab]` is partially populated.

---

## FILENAME_RX — Rewrite Required

Old (broken): `^([A-Z]{2,4}(?:\.[A-Z0-9]{1,4}){1,4})[ \-_]+(\d{6})[ \-_]+(.+?)\.pdf$`

Must match all of:
- `ABL.F.40.01-260404 POST PDI (1).pdf`
- `ABL.F.40.01-260404 POST PDI.pdf` (no `(1)` suffix)
- `D.ABL.10.5-260315 Monthly QC.pdf`
- `4DR.ABL.16.1-260315 Monthly QC.pdf`
- `VIPABLM/F/32.1-260315 Monthly QC.pdf` (slash inside plant ID — note Drive can't have slashes in filenames, so this is likely written as `VIPABLM_F_32.1` or `VIPABLM-F-32.1` in the actual file. NEED TO CONFIRM FROM REAL DRIVE LISTING.)
- `MH.40.10_E-260315 Monthly QC.pdf` or similar (filesystem-safe encoding of `MH.40.10/E`)
- `F.P.O.20.1-260315 Monthly QC.pdf` (compound dotted prefix)
- `SHC.M.20..1-260315 Monthly QC.pdf` (double-dot typo)
- `TB.10.10-260315 Monthly QC.pdf`
- `OPO.20.1-260315 Monthly QC.pdf`
- `STC.20.3-260315 Monthly QC.pdf`

Recommended new regex:
```js
const FILENAME_RX = /^\s*(.+?)-(\d{6})[ _-](.+?)(?:\s*\(\d+\))?\.pdf$/i;
```

Where group 1 is the plant ID (anything before `-YYMMDD`), trimmed and uppercased at parse time. Validation against the sheet's plant column happens AFTER extraction, not in the regex.

---

## Plant → Tab Routing (TAB_PREFIX_MAP rewrite)

| Tab | Prefix patterns observed |
|---|---|
| DRS | `DR.2.T.*`, `DR.2.TS.*` |
| Ablution | `ABL.*`, `D.ABL.*`, `4DR.ABL.*`, `VIPABL*` (no leading dot — multi-letter prefix) |
| Shower unit | `SHC.*` (but NOT `FLX.SHC.*`) |
| Messhall | `MH.*` |
| Cabins | `TB.*`, `OPO.*`, `STC.*` |
| Flatpack | `F.P.O.*` |
| Flexiloo | `FLX.*` (including `FLX.SHC.*`, `FLX.EAWC.*`, `FLX.UR.*`) |
| Portaloo | `PL.*`, `DA.PL.*` |

### Routing Strategy
Pattern-based routing alone is fragile (Cabins has 3 prefixes; Flexiloo's `FLX.SHC.*` overlaps Shower unit's `SHC.*`). Use a TWO-PASS resolver:

1. **First pass — exact lookup**: search every in-scope tab's column D for the exact plant ID. If found, use that tab. (This handles all 99% of cases since plants are pre-existing in the sheet.)
2. **Second pass — prefix routing** (only for new plants from PDFs that don't yet exist in any tab): use a longest-match prefix table:
   ```js
   const PREFIX_RULES = [
     { rx: /^FLX\./i,                tab: 'Flexiloo'    }, // matches before SHC. catch
     { rx: /^DA\.PL\./i,             tab: 'Portaloo'    },
     { rx: /^PL\./i,                 tab: 'Portaloo'    },
     { rx: /^DR\.2\./i,              tab: 'DRS'         },
     { rx: /^4DR\.ABL\./i,           tab: 'Ablution'    },
     { rx: /^D\.ABL\./i,             tab: 'Ablution'    },
     { rx: /^VIPABL/i,               tab: 'Ablution'    },
     { rx: /^ABL\./i,                tab: 'Ablution'    },
     { rx: /^SHC\./i,                tab: 'Shower unit' },
     { rx: /^MH\./i,                 tab: 'Messhall'    },
     { rx: /^TB\./i,                 tab: 'Cabins'      },
     { rx: /^OPO\./i,                tab: 'Cabins'      },
     { rx: /^STC\./i,                tab: 'Cabins'      },
     { rx: /^F\.P\.O\./i,            tab: 'Flatpack'    },
   ];
   ```

---

## Tab → Comments Column Override

Shower unit has no `Comments` column. Use this override map:

```js
const COMMENTS_HEADER_BY_TAB = {
  'Shower unit': 'STATUS',  // STATUS is the catch-all on this tab
  // others fall through to 'Comments'
};
```

The engine's `commentsColForTab_(ctx, tabName)` helper consults this map first, then falls back to scanning headers for `Comments`.
