---
name: clap-advanced-plugin-formats
description: |
  Deep guide to CLAP plugin format (threading model, modulation, JUCE integration),
  parameter ID stability (the #1 silent bug that breaks saved sessions), plugin state
  versioning/migration, oversampling for nonlinear audio, and AU/AAX specifics.
  Use when: CLAP format, per-note expression, non-destructive modulation, param ID,
  breaking saved sessions, getStateInformation, versioning, oversampling, aliasing,
  saturation in plugins, AU validation, AAX Pro Tools, plugin UID stability.
---

# CLAP & Advanced Plugin Format Implementation SKILL

Everything in this skill prevents real, hard-to-diagnose bugs. Skipping any section
risks broken DAW sessions, crashes, aliasing artefacts, or incompatible updates.

---

## 1. Parameter ID Stability — The #1 Silent Killer

**The bug**: You rename a parameter string, reorder your layout, or add a param in the
middle of the list. Your plugin ships. Every existing user opens a saved project and
finds automation lanes pointing at the wrong knobs, or zeroed out entirely. Their work
is silently destroyed. This is permanent and irreversible.

**The rule**: Once shipped, parameter IDs must NEVER change. Not the string, not the
order if using index-based IDs, not anything.

### How JUCE Generates VST3 Parameter IDs

JUCE hashes your `paramID` string to produce a `uint32_t`. This hash is what VST3,
AU, and CLAP hosts store in session files. Changing the string changes the hash,
making the host unable to reconnect saved automation to your parameter.

```cpp
// SAFE: stable string IDs — these strings are forever
APVTS::ParameterLayout createParameters() {
    return {
        std::make_unique<AudioParameterFloat>(
            ParameterID{"reverb_size", 1},     // NEVER rename "reverb_size"
            "Room Size", 0.1f, 30.0f, 5.0f),

        std::make_unique<AudioParameterFloat>(
            ParameterID{"reverb_decay", 1},    // NEVER rename "reverb_decay"
            "Decay Time", 0.1f, 20.0f, 2.5f),

        // Adding NEW params at the END is always safe:
        std::make_unique<AudioParameterFloat>(
            ParameterID{"shimmer_amount", 1},  // New in v2 — safe, appended
            "Shimmer", 0.0f, 1.0f, 0.0f),
    };
}
```

```cpp
// DANGEROUS: index-based legacy IDs — order is fragile
// (JUCE_FORCE_USE_LEGACY_PARAM_IDS=1 mode)
// Inserting a new param at position 0 shifts EVERY param ID → all sessions broken
```

### JUCE Compatibility Flags (CMakeLists.txt)

```cmake
target_compile_definitions(MyPlugin PRIVATE
    # Use hash-based IDs (modern, safe — default in JUCE 7+):
    JUCE_FORCE_USE_LEGACY_PARAM_IDS=0
    # Don't try to auto-migrate VST2→VST3 sessions (avoids ID conflicts):
    JUCE_VST3_CAN_REPLACE_VST2=0
)
```

### Remapping Changed IDs (Advanced Recovery)

If you shipped with wrong IDs and MUST change them, use `getCompatibleParameterIds`:
```cpp
std::map<String, String> getCompatibleParameterIds() const override {
    // Maps OLD param ID string → NEW param ID string
    return {
        {"decay",  "reverb_decay"},   // old name → new name
        {"size",   "reverb_size"},
    };
}
```
This only works within JUCE's VST3 wrapper. Use sparingly — it's a last resort.

### Plugin UID Stability (Equally Critical)

Your plugin's four-character codes are its identity in every DAW. Never change them:
```cmake
juce_add_plugin(MyReverb
    PLUGIN_MANUFACTURER_CODE "MYCO"   # 4 chars — PERMANENT
    PLUGIN_CODE              "Rv01"   # 4 chars — PERMANENT
    # AU type codes, VST3 FUID are derived from these — changing = new plugin
)
```
For CLAP, your ID string `"com.mycompany.myreverb"` is equally permanent.

---

## 2. Plugin State Versioning & Migration

Every `getStateInformation` / `setStateInformation` pair must handle loading state
from older plugin versions gracefully. No version number = guaranteed future breakage.

```cpp
void getStateInformation(MemoryBlock& dest) override {
    auto state = parameters.copyState();
    // ALWAYS write a version number:
    state.setProperty("pluginVersion", 2, nullptr);
    copyXmlToBinary(*state.createXml(), dest);
}

void setStateInformation(const void* data, int sizeInBytes) override {
    auto xmlState = getXmlFromBinary(data, sizeInBytes);
    if (!xmlState) return;

    int version = xmlState->getIntAttribute("pluginVersion", 1); // default = v1

    // Migrate v1 → v2: old param name "decay" became "reverb_decay"
    if (version < 2) {
        if (xmlState->hasAttribute("decay")) {
            xmlState->setAttribute("reverb_decay",
                                   xmlState->getDoubleAttribute("decay"));
            xmlState->removeAttribute("decay");
        }
    }

    // Migrate v2 → v3 if needed in future:
    // if (version < 3) { ... }

    parameters.replaceState(ValueTree::fromXml(*xmlState));
}
```

### State Best Practices

- Always use string attribute names (not index-based) in your XML/ValueTree
- Include a `pluginVersion` integer from day one — retrofitting is painful
- Test: save state with v1, load with v2, verify nothing is lost or zeroed
- Store non-parameter state (e.g. loaded IR file path) as custom properties
  in the ValueTree alongside APVTS state, NOT as extra parameters

---

## 3. CLAP Format — Threading Model & Why It Prevents Bugs

CLAP's greatest advantage over VST3 is its **explicit threading contract**. VST3 has
ambiguities that lead to real race conditions. CLAP specifies exactly which functions
run on which thread, so you can assert correctness at compile/runtime.

### Thread Definitions

| Thread Tag | Who Calls It | What's Permitted |
|---|---|---|
| `[main-thread]` | Host UI/main thread | activate, deactivate, state, GUI, param sync |
| `[audio-thread]` | Host audio engine | process(), param_flush, transport events |
| `[audio-thread-pool]` | Host thread pool | Parallel DSP subtasks (optional extension) |

**Guarantee**: `[main-thread]` and `[audio-thread]` are **never concurrent** for the
same plugin instance. The host enforces this. You can read/write shared state safely
as long as you respect thread tags — no mutex needed for that pattern.

### Thread-Check Extension (Debug Assertion)

```c
// Add to your plugin's process() for debug builds:
#ifndef NDEBUG
const clap_host_thread_check_t *tc =
    (const clap_host_thread_check_t*)host->get_extension(host, CLAP_EXT_THREAD_CHECK);
if (tc) assert(tc->is_audio_thread(host));
#endif
```

### Parameter Synchronization in CLAP

```c
// In process() — consume incoming param events:
uint32_t ev_count = in_events->size(in_events);
for (uint32_t i = 0; i < ev_count; ++i) {
    const clap_event_header_t *hdr = in_events->get(in_events, i);
    if (hdr->type == CLAP_EVENT_PARAM_VALUE) {
        const clap_event_param_value_t *ev =
            (const clap_event_param_value_t*)hdr;
        // ev->param_id maps to your parameter
        // ev->value is the new value [0..1] normalised
        // ev->note_id, ev->key, ev->channel for per-note modulation
        audioParams[ev->param_id] = ev->value;
    }
}
```

### CLAP Thread Pool for Reverb (Parallel FDN)

For CPU-intensive reverb (large FDN, convolution), offload to host thread pool:
```c
// Request N parallel tasks:
clap_host_thread_pool_t *pool = (clap_host_thread_pool_t*)
    host->get_extension(host, CLAP_EXT_THREAD_POOL);
if (pool) pool->request_exec(host, numFDNBands);
// Host calls plugin->thread_pool->exec(plugin, task_index) for each task
// Each task_index processes one FDN band or convolution partition
```

---

## 4. CLAP + JUCE Integration (clap-juce-extensions)

The `free-audio/clap-juce-extensions` repo adds CLAP as a build target alongside
VST3, AU, AAX — minimal code changes to your existing JUCE plugin.

### CMakeLists.txt Setup

```cmake
include(FetchContent)
FetchContent_Declare(clap-juce-extensions
    GIT_REPOSITORY https://github.com/free-audio/clap-juce-extensions.git
    GIT_TAG        main
    GIT_SHALLOW    TRUE)
FetchContent_MakeAvailable(clap-juce-extensions)

# After juce_add_plugin(MyPlugin ...):
clap_juce_extensions_plugin(
    TARGET          MyPlugin
    CLAP_ID         "com.mycompany.myreverb"    # permanent — never change
    CLAP_FEATURES   audio-effect reverb stereo  # shown in host browser
)
```

### Per-Note Modulation (CLAP Exclusive)

Enables Bitwig-style: route LFO → Reverb Size per-note, non-destructively.
Your parameters are automatically modulatable when exposed via APVTS.
No extra code needed — clap-juce-extensions handles the protocol.

```cpp
// Opt in to non-destructive modulation per param:
// APVTS parameters are modulatable by default in CLAP.
// For custom behaviour, override in your AudioProcessor:
bool supportsDirectParameterMeta() const override { return true; }
```

### Sample-Accurate Automation in CLAP

```cmake
# Split audio blocks at automation event boundaries for sample accuracy:
target_compile_definitions(MyPlugin PRIVATE
    CLAP_ALWAYS_SPLIT_BLOCK=1
    CLAP_PROCESS_EVENTS_RESOLUTION_SAMPLES=1)
```

---

## 5. Oversampling — When You Need It for Reverb Quality

**Linear reverb (pure FDN, pure convolution) does NOT need oversampling.**
No aliasing is generated by linear operations.

**You DO need oversampling if your reverb includes any of:**
- Soft clipping / saturation in the feedback loop (harmonic warmth)
- Waveshaping (nonlinear drive on signal entering reverb)
- Dynamic compression in feedback (pumping/breathing effect)
- Exciter/harmonic enhancer before or inside reverb

Without oversampling, nonlinear stages fold frequencies above Nyquist back into the
audible range as inharmonic aliasing — immediately audible as a harsh, digital quality.

### JUCE dsp::Oversampling

```cpp
// In your AudioProcessor header:
juce::dsp::Oversampling<float> oversampler {
    2,      // num channels
    2,      // oversampling factor (2 = 2x = 88.2/96kHz internally)
    juce::dsp::Oversampling<float>::filterHalfBandPolyphaseIIR,
    true,   // isMaximumQuality
    false   // delay compensation
};

// In prepareToPlay():
oversampler.initProcessing(static_cast<size_t>(maxSamplesPerBlock));
oversampler.reset();

// In processBlock():
juce::dsp::AudioBlock<float> inputBlock(buffer);
// Upsample:
auto oversampledBlock = oversampler.processSamplesUp(inputBlock);
// Apply ONLY the nonlinear stage at high sample rate:
for (size_t ch = 0; ch < oversampledBlock.getNumChannels(); ++ch) {
    auto* data = oversampledBlock.getChannelPointer(ch);
    for (size_t i = 0; i < oversampledBlock.getNumSamples(); ++i)
        data[i] = std::tanh(drive * data[i]);  // nonlinear waveshaper here
}
// Downsample back:
oversampler.processSamplesDown(inputBlock);
// Continue with linear reverb on the downsampled signal — no oversampling needed
```

### Oversampling Ratios and CPU Cost

| Ratio | CPU Multiplier | Use Case |
|---|---|---|
| 2x | ~2x | Mild saturation, typical for most plugins |
| 4x | ~4x | Moderate drive; standard for quality plugins |
| 8x | ~8x | Aggressive waveshaping; FabFilter Pro-Q standard |
| 16x | ~16x | Extreme precision; mastering-grade limiters |

**Key optimisation**: wrap ONLY the nonlinear section in oversampling, not the entire
reverb. The linear FDN/convolution runs at normal sample rate. CPU stays manageable.

### Linear-Phase vs Minimum-Phase Anti-Aliasing Filter

```cpp
// Minimum-phase (default): lower latency, some group delay
juce::dsp::Oversampling<float>::filterHalfBandPolyphaseIIR

// Linear-phase: zero phase distortion, but adds latency
juce::dsp::Oversampling<float>::filterHalfBandFIREquiripple
// Must report added latency to host:
setLatencySamples(oversampler.getLatencyInSamples());
```
Use linear-phase for offline/render quality. Minimum-phase for real-time performance.

---

## 6. AU (Audio Unit) — What Actually Breaks Logic Pro

### auval Validation (Must Pass Before Submission)

```bash
# Run after installing plugin to ~/Library/Audio/Plug-Ins/Components/
auval -v aufx ABCD MYCO   # Replace ABCD=plugin subtype, MYCO=manufacturer
auval -a                   # Validate ALL installed AUs (useful in CI)
```

Common `auval` failures and fixes:

| Failure | Cause | Fix |
|---|---|---|
| Parameter count mismatch | Added params without bumping version | Use stable param layout |
| State restore failure | setStateInformation crashes on nil XML | Add nil check before parsing |
| Latency not reported | Oversampling filter not declared | setLatencySamples() |
| Channel config rejected | isBusesLayoutSupported() too strict | Return true for more layouts |

### Logic Pro Sandbox (10.7+)

Logic sandboxes AU plugins. Forbidden operations:
- Arbitrary filesystem access (hardcoded `/Users/...` paths break here)
- Network access without entitlement
- Spawning subprocesses

Safe alternatives:
- Use `juce::File::getSpecialLocation(File::userDocumentsDirectory)` not hardcoded paths
- Store IR files in plugin's resource bundle or user's Music folder
- Use JUCE `PropertiesFile` for preferences (safe in sandbox)

---

## 7. AAX (Pro Tools) — Essential Points

- Requires paid Avid developer account + PACE Eden SDK wrapping
- AAX plugins run in a separate AAX host process — plugin crashes don't take Pro Tools down
- **Offline bounce**: Pro Tools runs faster than real-time. Never use wall-clock time.
  Always use sample counts for timing. `Time::currentTimeMillis()` inside processBlock = bug.
- Test with `AAX Plugin Validator` (ships with Pro Tools developer SDK)
- All iLok activation via Eden SDK — builds take longer, budget time for PACE integration

---

## 8. Format Launch Checklist

Before shipping any new plugin format, verify:

**All formats:**
- [ ] Plugin UID (manufacturer code + plugin code) set and will never change
- [ ] All param IDs set as stable strings (not index-based)
- [ ] Version number written to state from day one
- [ ] State round-trips correctly (save → load → save → identical)
- [ ] Works at 44.1, 48, 88.2, 96, 192 kHz

**VST3:**
- [ ] Pluginval passes at strictness 5+ on macOS and Windows
- [ ] Automation records and plays back correctly in Cubase, Reaper, Ableton
- [ ] JUCE_FORCE_USE_LEGACY_PARAM_IDS=0 confirmed

**AU:**
- [ ] `auval` passes (zero failures, zero warnings)
- [ ] Works in Logic Pro with Rosetta disabled (Apple Silicon native)
- [ ] No hardcoded absolute file paths

**CLAP:**
- [ ] CLAP ID string set and permanent
- [ ] Works in Bitwig (modulation test), FL Studio (buffer size test), Reaper
- [ ] Thread check assertions pass in Debug build

**AAX:**
- [ ] AAX Plugin Validator passes
- [ ] Offline bounce tested at 2x, 4x speed
- [ ] PACE wrapping signed and activated

---

## Key References

- CLAP spec & SDK: [github.com/free-audio/clap](https://github.com/free-audio/clap)
- clap-juce-extensions: [github.com/free-audio/clap-juce-extensions](https://github.com/free-audio/clap-juce-extensions)
- CLAP thread model: `clap/include/clap/ext/thread-check.h`
- Steinberg VST3 Parameters & Automation: [steinbergmedia.github.io/vst3_dev_portal](https://steinbergmedia.github.io/vst3_dev_portal/pages/Technical+Documentation/Parameters+Automation/Index.html)
- JUCE VST3 param ID forum: [forum.juce.com](https://forum.juce.com/t/juce-vst3-parameter-ids/17392)
- JUCE dsp::Oversampling docs: [docs.juce.com](https://docs.juce.com/master/classdsp_1_1Oversampling.html)
- Apple AU Validation: `man auval` / Xcode Audio Unit documentation
- Timur Doumler "C++ in the Audio Industry" — CppCon 2015
- Moonbase.sh CI article: "Continuous Integration for Audio Plugins. Tips, tricks, gotchas."
