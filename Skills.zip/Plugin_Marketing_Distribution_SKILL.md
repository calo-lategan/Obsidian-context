# Audio Plugin Marketing & Distribution SKILL

A comprehensive reference guide for indie developers commercializing audio plugins.

## 1. E-Commerce Platforms for Plugin Sales

**Moonbase.sh** - The audio-first choice. First Merchant of Record (MoR) built specifically for plugins with JUCE licensing module (plug-and-play integration). Offers overlay checkout, personalized discounts, affiliate partnerships, and excellent developer support (developers@moonbase.sh). Best for technical teams wanting seamless integration.

**FastSpring** - Full-service MoR for digital goods with mature license-key and affiliate features. Provides custom pricing, flexible checkout branding, and direct developer support. Ideal for established developers needing enterprise features.

**Paddle** - MoR focused on SaaS/software with robust API and strong EU support (avoids USD payout issues). Best for technical teams wanting deep integration and global reach.

**Gumroad** - Creator-focused platform with simple setup and 10% fee. Minimal customization but fastest path to market. Best for getting started quickly without technical overhead.

**Plugin Boutique** - Major audio plugin marketplace with massive existing customer base (thousands daily visitors). Commission-based but provides built-in marketing reach you can't buy elsewhere. Essential for visibility in audio community.

**KVR Audio** - Community marketplace combined with free weekly developer listings and blog posts. Exceptional for search engine visibility for audio plugin keywords.

**Decision Framework:** Use Moonbase for audio-specific features and JUCE integration. FastSpring/Paddle for full MoR functionality. Gumroad for rapid prototyping. Plugin Boutique as secondary channel for reach. KVR for community credibility.

## 2. Licensing & Copy Protection

**iLok / PACE Anti-Piracy** - Industry standard with Eden 5.0 SDK. Supports iLok Cloud, machine-based, hardware, and hybrid licensing. Enables perpetual, subscription, trial, and timed licenses. 200M+ licenses issued globally. Integrates with Shopify. Best for serious commercial plugins.

**Moonbase Licensing** - JUCE module for cross-platform licensing (including iOS/Android). Integrated with their e-commerce platform. Lower overhead than PACE but less enterprise features.

**Custom Serial Key Systems** - Simple to implement but less secure. Good for low-cost plugins ($0-30) where piracy risk is acceptable.

**No Protection Strategy** - Used successfully by Valhalla DSP (focus on goodwill, low prices, community engagement). Works if margins are high or community loyalty is strong.

**Selection Criteria:** Evaluate protection level vs. customer friction vs. implementation cost. Enterprise plugins warrant PACE. Consumer plugins under $30 may not justify protection overhead.

## 3. Website & Landing Page Design

**Critical Elements:**
- Hero section with compelling audio demo (not just screenshot)
- Feature highlights (3-5 key differentiators)
- Audio/video demonstrations showing before-and-after
- Social proof (testimonials, artist logos, review quotes)
- Clear pricing and prominent CTA buttons
- Technical specifications and compatibility info

**Conversion Optimization:**
- Mobile-responsive design (11-12% conversion on mobile vs 10% desktop - unexpected but proven)
- Trust signals: user testimonials, artist endorsements, SSL certificate
- A/B test headline variations and demo length
- Fast loading speed (optimize audio assets, use CDN)

**Audio-Specific Enhancements:**
- Embedded audio player with A/B comparison slider
- Preset showcase with playable examples
- DAW compatibility matrix with screenshots
- Video walkthrough of interface and workflow

**Technical Stack:** WordPress with Elementor (easiest), Webflow (design-focused), custom HTML/CSS with hosting (most control), or Squarespace (balanced).

## 4. Marketing Channels

**YouTube** - Tier-1 channel for audio plugins. Create tutorial videos, sound demos, before-after comparisons, and producer walkthroughs. Aim for 8-12 minute educational content. Collaborate with music production channels (200K-2M subscribers).

**Social Media** - Instagram for UI showcases and beautiful interface screenshots. Twitter/X for development updates and community engagement. TikTok for 15-30 second sound demos to music production audience.

**Audio Forums** - KVR Audio (essential - post free content weekly, maintain developer listing), Gearspace, VI-Control, and Reddit (r/AudioProduction, r/WeAreTheMusicMakers) are where target customers discuss gear.

**Email Marketing** - Build list from day one. Announce launches, feature updates, promotional offers, and development roadmap. Segment by product interest and purchase history.

**Content Marketing** - Write blog posts about reverb design theory, behind-the-scenes development, plugin comparisons, and music production tips. Target long-tail keywords like "best reverb for hip-hop vocals".

**Influencer Outreach** - Identify music production YouTubers (50K-500K subscribers) in your niche. Send free licenses, offer affiliate commissions (10-20%), and request honest reviews.

**Paid Advertising** - Google Search Ads targeting "reverb plugin", "VST plugin", etc. Facebook/Instagram ads targeting music producers and audio professionals (interests: music production, mixing, etc.).

## 5. Pricing Strategy

**Competitive Analysis:**
- Research comparable plugins: Valhalla Room ($50), FabFilter Pro-R ($199), Lexicon plugins ($149-299)
- Analyze what features justify price premium
- Indie sweet spot for single effects: $29-79
- More complex tools: $79-149
- EQ and reverb typically command higher prices than modulation effects

**Launch Pricing:**
- Introductory discount: 20-40% off for first 2-4 weeks
- Early bird list: 50% off for email subscribers
- Limited time urgency increases conversions 15-30%

**Tiered Pricing:**
- Standard edition: core features, $49
- Professional edition: advanced features + presets, $99
- Bundle pricing: combine 2-3 plugins with 25-30% discount

**Promotional Calendar:**
- Black Friday: 30-50% discount (biggest sales day)
- Plugin Boutique deals: negotiate featured placement
- New Year, Summer promotions: themed sales campaigns
- Free version launch: drive trial-to-paid conversions

**Trial Strategy:** Full-featured 14-30 day trial with periodic silence/noise watermark. This drives more conversions than feature-limited trials. Offer both registered trial (email gate) and anonymous demo versions.

## 6. Preset Design & Curation

**Organize by Use Case:**
- Small Rooms, Large Halls, Plates (for reverb)
- Ambiences, Cinematic Spaces, Special FX
- Vintage, Modern, Creative categories
- Genre-specific: Hip-Hop, EDM, Rock, Orchestral

**Preset Naming Convention:**
- Descriptive + evocative: "Midnight Cathedral", "Whisper Room", "Epic Orchestral Hall"
- Include technical hint: "Small Room Bright", "Large Hall Dark"
- Avoid generic names like "Reverb 1"

**Preset Development:**
- Include 30-50 carefully designed presets at launch
- Hire professional sound designer for additional 50-pack ($3K-8K)
- Consider VAE-based preset morphing (research SPINVAE-2 for smooth latent space transitions)
- Implement searchable tagging: mood, size, instrument type, genre

**Community Features:**
- Enable user preset sharing and community voting
- Feature top user presets in updates
- Run preset design contests with free licenses as prizes
- Create preset packs from community submissions

## 7. Launch Strategy

**Pre-Launch (4-6 weeks prior):**
- Start beta testing program (100-500 users)
- Build email list with launch announcements
- Create teaser videos and content
- Establish presence on audio forums
- Prepare press release and media kit

**Launch Day Coordination:**
- Simultaneous announcements on all channels
- Email blast to entire list
- Social media blitz (Twitter, Instagram, YouTube announcement)
- KVR Audio listing update and news posting
- Contact music production YouTubers

**Negotiate Plugin Boutique:** Arrange featured placement for launch week (increases visibility 10x). Offer exclusive presets or discounts to their audience.

**Post-Launch:** Respond to feedback within 24 hours. Track bug reports closely. Create feature request voting system and respond to top requests in v1.1 update (2-4 weeks post-launch).

## 8. Demo & Trial Mechanics

**Full-Featured Time-Limited Trial** - Most effective approach. Preferred by 78% of audio plugin buyers because they can truly evaluate the plugin. 14-30 day period is standard.

**Watermarking:** Periodic silence (5 seconds every 30 seconds) or subtle noise watermark on output. Motivates purchase without ruining workflows.

**Feature-Limited Free Version:** Lighter alternative - limit presets to 5-10, disable certain algorithms, restrict parameter ranges. Funnel warm users to paid version.

**No Registration Trial:** Maximize downloads by not requiring email. Accept lower conversion rate (2-5% vs 5-8%) in exchange for volume. Upsell via post-download email.

**Trial Conversion Targets:** Aim for 5-10% trial-to-paid conversion. Benchmark with email follow-up campaigns targeting expired trial users (typically 20-30% conversion).

## 9. Installer & Delivery

**macOS Deployment:**
- Create .pkg installer with code signing certificates
- Notarize with Apple (required for Monterey+)
- Build universal binary for Apple Silicon (M1+)
- Support VST3, AU, AAX formats

**Windows Deployment:**
- Use InnoSetup for professional installer
- EV code signing certificate (eliminates SmartScreen warnings)
- Implement Azure Trusted Signing for CI/CD
- Support VST3, AAX formats

**License Delivery:**
- Send download link + license key immediately post-purchase
- Include setup instructions and system requirements
- Provide manual installer link (in case auto-download fails)

**Auto-Update System:**
- Check for updates on plugin launch (background, non-blocking)
- Notify user of new version with changelog
- Provide in-app or in-DAW update prompts
- Keep installer on CDN for fast delivery

## 10. Customer Support & Community

**Support Channels:**
- Email support (target 24-48 hour response time)
- Public forum for common issues and preset sharing
- Knowledge base with searchable FAQ
- Discord server for community discussion (optional but high engagement)

**Documentation Requirements:**
- Comprehensive user manual (PDF, 15-30 pages)
- Video tutorials for key workflows (YouTube playlist)
- Quick-start guide (1-2 page printable)
- API documentation if offering preset import/export

**Community Engagement:**
- User preset sharing platform or forum
- Feature request voting system (Nolt.io, Canny.io)
- Beta tester program for major updates
- Monthly development blog posts sharing roadmap

**Response Metrics:** Track support response time, resolution time, and customer satisfaction (NPS score target: 50+). Use feedback to improve documentation and UI.

## 11. Analytics & Growth Metrics

**Key Metrics to Track:**
- Trial downloads per day/month
- Trial-to-paid conversion rate
- Average selling price (ASP)
- Customer acquisition cost (CAC)
- Lifetime value (LTV)
- Geographic distribution of customers
- DAW usage distribution (Ableton, Logic, Pro Tools, etc.)

**A/B Testing Framework:**
- Test landing page headlines, colors, demo length
- Experiment with pricing ($49 vs $59 vs $69)
- Vary trial length (7 vs 14 vs 30 days)
- Test email subject lines and send timing

**Customer Feedback Loops:**
- Post-purchase survey (1-5 questions)
- Annual NPS survey to full customer base
- Monitor forums and social media mentions
- Track feature request frequency

**Data-Driven Iteration:**
- Use conversion data to prioritize landing page redesigns
- Plan v2 features based on most-requested features
- Allocate marketing budget to highest-ROI channels
- Adjust pricing based on elasticity testing
- Geographic expansion based on sales distribution

**Reporting:** Create weekly dashboard of trial starts, conversions, revenue. Monthly analysis of channel performance. Quarterly business review with 90-day projections.

---

*Last updated: 2026-02 | For indie audio plugin developers*
