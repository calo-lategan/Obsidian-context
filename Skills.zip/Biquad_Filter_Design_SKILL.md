---
name: biquad-filter-design
description: |
  Complete Audio EQ Cookbook (Robert Bristow-Johnson) reference for biquad IIR filters.
  Every filter type with C++ implementations, coefficient calculation, FDN damping, 
  JUCE DSP module integration, StateVariableFilter, ProcessorChain, and sample-rate-dependent
  recalculation. Essential for reverb shelving, damping, EQ, and pre/post filtering.
  Trigger on: biquad, IIR, filter, EQ, lowpass, highpass, peaking, shelving, notch, allpass,
  Audio EQ Cookbook, RBJ, coefficient, filter design, damping filter, StateVariableFilter,
  ProcessorChain, dsp module, FilterDesign.
---

# Biquad Filter Design (Audio EQ Cookbook) SKILL

The Audio EQ Cookbook by Robert Bristow-Johnson (RBJ) is the definitive reference for digital biquad
filters used in audio. Every audio DSP developer must know these formulas cold.

---

## 1. Biquad Transfer Function

All biquad filters share the same second-order transfer function:

```
H(z) = (b0 + b1*z⁻¹ + b2*z⁻²) / (a0 + a1*z⁻¹ + a2*z⁻²)
```

Normalise by dividing all coefficients by a0:
```
H(z) = (b0/a0 + b1/a0*z⁻¹ + b2/a0*z⁻²) / (1 + a1/a0*z⁻¹ + a2/a0*z⁻²)
```

**Direct Form I implementation in C++:**
```cpp
struct Biquad {
    double b0, b1, b2, a1, a2;   // normalised (a0 = 1.0)
    double x1 = 0, x2 = 0;       // input delay
    double y1 = 0, y2 = 0;       // output delay

    double processSample(double x) {
        double y = b0*x + b1*x1 + b2*x2 - a1*y1 - a2*y2;
        x2 = x1; x1 = x;
        y2 = y1; y1 = y;
        return y;
    }

    void reset() { x1 = x2 = y1 = y2 = 0.0; }
};
```

**Direct Form II Transposed (preferred — better numerical stability):**
```cpp
double processSampleDF2T(double x) {
    double y = b0*x + s1;
    s1 = b1*x - a1*y + s2;
    s2 = b2*x - a2*y;
    return y;
}
double s1 = 0, s2 = 0;
```

---

## 2. Shared Intermediate Variables

For ALL filter types, compute these first (where Fs = sample rate):

```cpp
double w0    = 2.0 * M_PI * frequency / sampleRate;
double cosW0 = std::cos(w0);
double sinW0 = std::sin(w0);

// For Q-based filters:
double alpha = sinW0 / (2.0 * Q);

// For bandwidth-based (BW in octaves):
// alpha = sinW0 * sinh(log(2)/2 * BW * w0/sinW0)

// For shelf filters:
double A     = std::pow(10.0, dBgain / 40.0);   // linear amplitude
double alphaS = sinW0 / 2.0 * std::sqrt((A + 1/A) * (1/S - 1) + 2);
// S = shelf slope (1.0 = max steepness)
```

---

## 3. All Filter Types — Coefficient Formulas

### Low Pass Filter (LPF)
```cpp
void setLPF(double freq, double Q, double Fs) {
    double w0 = 2*M_PI*freq/Fs, a = sin(w0)/(2*Q);
    double c = cos(w0);
    double a0 = 1 + a;
    b0 = (1 - c) / 2 / a0;
    b1 = (1 - c)     / a0;
    b2 = (1 - c) / 2 / a0;
    a1 = -2*c        / a0;
    a2 = (1 - a)     / a0;
}
```

### High Pass Filter (HPF)
```cpp
void setHPF(double freq, double Q, double Fs) {
    double w0 = 2*M_PI*freq/Fs, a = sin(w0)/(2*Q);
    double c = cos(w0);
    double a0 = 1 + a;
    b0 =  (1 + c) / 2 / a0;
    b1 = -(1 + c)     / a0;
    b2 =  (1 + c) / 2 / a0;
    a1 = -2*c         / a0;
    a2 = (1 - a)      / a0;
}
```

### Band Pass Filter (BPF — constant 0dB peak gain)
```cpp
void setBPF(double freq, double Q, double Fs) {
    double w0 = 2*M_PI*freq/Fs, a = sin(w0)/(2*Q);
    double c = cos(w0), s = sin(w0);
    double a0 = 1 + a;
    b0 =  Q * a         / a0;
    b1 =  0;
    b2 = -Q * a         / a0;
    a1 = -2*c           / a0;
    a2 = (1 - a)        / a0;
}
```

### Notch Filter (Band Reject)
```cpp
void setNotch(double freq, double Q, double Fs) {
    double w0 = 2*M_PI*freq/Fs, a = sin(w0)/(2*Q);
    double c = cos(w0);
    double a0 = 1 + a;
    b0 =  1              / a0;
    b1 = -2*c            / a0;
    b2 =  1              / a0;
    a1 = -2*c            / a0;
    a2 = (1 - a)         / a0;
}
```

### Allpass Filter (APF)
```cpp
void setAPF(double freq, double Q, double Fs) {
    double w0 = 2*M_PI*freq/Fs, a = sin(w0)/(2*Q);
    double c = cos(w0);
    double a0 = 1 + a;
    b0 = (1 - a)         / a0;
    b1 = -2*c            / a0;
    b2 =  1;
    a1 = -2*c            / a0;
    a2 = (1 - a)         / a0;
}
```

### Peaking EQ
```cpp
void setPeakingEQ(double freq, double Q, double dBgain, double Fs) {
    double w0 = 2*M_PI*freq/Fs, a = sin(w0)/(2*Q);
    double c = cos(w0);
    double A  = pow(10.0, dBgain/40.0);
    double a0 = 1 + a/A;
    b0 = (1 + a*A)       / a0;
    b1 = -2*c            / a0;
    b2 = (1 - a*A)       / a0;
    a1 = -2*c            / a0;
    a2 = (1 - a/A)       / a0;
}
```

### Low Shelf
```cpp
void setLowShelf(double freq, double S, double dBgain, double Fs) {
    double A  = pow(10.0, dBgain/40.0);
    double w0 = 2*M_PI*freq/Fs;
    double c  = cos(w0), s = sin(w0);
    double as = s/2 * sqrt((A + 1/A)*(1/S - 1) + 2);
    double sqA2 = 2*sqrt(A);
    double a0 = (A+1) + (A-1)*c + sqA2*as;
    b0 =  A*((A+1) - (A-1)*c + sqA2*as)  / a0;
    b1 =  2*A*((A-1) - (A+1)*c)           / a0;
    b2 =  A*((A+1) - (A-1)*c - sqA2*as)  / a0;
    a1 = -2*((A-1) + (A+1)*c)             / a0;
    a2 = ((A+1) + (A-1)*c - sqA2*as)      / a0;
}
```

### High Shelf
```cpp
void setHighShelf(double freq, double S, double dBgain, double Fs) {
    double A  = pow(10.0, dBgain/40.0);
    double w0 = 2*M_PI*freq/Fs;
    double c  = cos(w0), s = sin(w0);
    double as = s/2 * sqrt((A + 1/A)*(1/S - 1) + 2);
    double sqA2 = 2*sqrt(A);
    double a0 = (A+1) - (A-1)*c + sqA2*as;
    b0 =  A*((A+1) + (A-1)*c + sqA2*as)  / a0;
    b1 = -2*A*((A-1) + (A+1)*c)           / a0;
    b2 =  A*((A+1) + (A-1)*c - sqA2*as)  / a0;
    a1 =  2*((A-1) - (A+1)*c)             / a0;
    a2 = ((A+1) - (A-1)*c - sqA2*as)      / a0;
}
```

---

## 4. When to Use Each Filter in a Reverb Plugin

| Use Case | Filter Type | Typical Settings |
|---|---|---|
| FDN per-feedback damping | 1-pole lowpass or LPF | 4–8 kHz cutoff, Q=0.7 |
| Low shelf boost in reverb tail | Low Shelf | +2-4dB, 200Hz, S=1 |
| High frequency rolloff | High Shelf | -6dB, 8kHz, S=0.5 |
| Resonance correction | Notch | narrow Q=10-30 |
| Allpass in diffusion network | APF | 150-800Hz, Q=0.7 |
| Shimmer tone shaping | Peaking EQ | +3dB, 2kHz |
| Pre-reverb low cut | HPF | 80-150Hz, Q=0.7 |

### One-Pole Damping Filter (Most Efficient for FDN)
```cpp
// Ultra-lightweight: one multiply-add per sample
// damping in [0,1]: 0=no damping, 1=full damping (silence)
float dampState = 0.0f;
float processDamp(float x, float damping) {
    return dampState = (1 - damping) * x + damping * dampState;
}
```
This is what Schroeder (1962) and Moorer (1979) used in feedback paths. Equivalent to a
first-order IIR lowpass with fc = Fs * (1-damping) / (2*pi*damping).

---

## 5. Coefficient Recalculation at Runtime

**Never recalculate coefficients every sample** — it's expensive and can cause audio artefacts.

```cpp
// Safe pattern: recalculate only when parameter changes:
void parameterChanged(const String& id, float newValue) override {
    if (id == "damping") {
        const ScopedLock sl(coeffLock);  // or use atomic flag
        myFilter.setLPF(dampFreq, 0.707, sampleRate);
    }
}
```

**Thread safety**: Coefficient writes are not inherently atomic. Use one of:
1. Double-buffered coefficients (write to shadow set, swap atomically)
2. `std::atomic<FilterCoeffs>` if small enough
3. JUCE `CriticalSection` for coefficient swap (NOT inside processBlock — use a flag)

**Frequency warping reminder**: All RBJ formulas use the Bilinear Transform with prewarping.
The formula `w0 = 2*pi*fc/Fs` already includes this. Coefficients are correct at `fc` but
have mild frequency error at other frequencies (BLT warping). For audio, this is audible only
near Nyquist.

---

## 6. JUCE DSP Module Filters

### IIR Filter (Direct Form II Transposed)
```cpp
// In header:
juce::dsp::IIR::Filter<float> lowpassFilter;

// In prepareToPlay():
juce::dsp::ProcessSpec spec { sampleRate, (uint32)maxBlockSize, numChannels };
lowpassFilter.prepare(spec);
*lowpassFilter.coefficients = *juce::dsp::IIR::Coefficients<float>::makeLowPass(
    sampleRate, cutoffFreq, Q);

// In processBlock():
juce::dsp::AudioBlock<float> block(buffer);
juce::dsp::ProcessContextReplacing<float> ctx(block);
lowpassFilter.process(ctx);
```

### StateVariableTPT Filter (Preferred for Modulation)
```cpp
// Header:
juce::dsp::StateVariableTPTFilter<float> svf;

// prepareToPlay():
svf.prepare(spec);
svf.setType(juce::dsp::StateVariableTPTFilterType::lowpass);
svf.setCutoffFrequency(800.0f);
svf.setResonance(0.707f);  // Q

// processBlock():
svf.process(ctx);
```

**Use StateVariableTPT when you need to modulate cutoff in real-time** — it has no
coefficient transients/clicks. Use IIR when modulation isn't needed (IIR is slightly cheaper).

### ProcessorChain Pattern
```cpp
// In header — chain multiple processors:
juce::dsp::ProcessorChain<
    juce::dsp::IIR::Filter<float>,       // pre-reverb HPF
    juce::dsp::Gain<float>,              // trim
    juce::dsp::Reverb                    // reverb
> processorChain;

// In prepareToPlay():
processorChain.prepare(spec);
auto& hpf = processorChain.get<0>();
*hpf.coefficients = *juce::dsp::IIR::Coefficients<float>::makeHighPass(sampleRate, 80.0f, 0.7f);

// In processBlock():
processorChain.process(ctx);
```

### ProcessorDuplicator (Stereo IIR)
```cpp
// Per-channel stereo processing:
juce::dsp::ProcessorDuplicator<
    juce::dsp::IIR::Filter<float>,
    juce::dsp::IIR::Coefficients<float>
> stereoFilter;
// Applies same coefficients to both channels independently
```

---

## 7. FDN Per-Band Decay with Biquad (Multiband Damping)

Jot (1991) showed that frequency-dependent decay in FDN requires per-band gain control.
Use parallel biquad peaking filters to sculpt the decay rate:

```cpp
// In each FDN feedback path:
struct FDNChannel {
    CircularBuffer delayLine;
    float feedbackGain;
    
    // Frequency-dependent damping: apply before feeding back
    juce::dsp::IIR::Filter<float> dampingFilter;
    
    // Optional: separate RT60 per band using shelving EQ
    juce::dsp::IIR::Filter<float> lowShelf;   // boost low freqs (slower decay)
    juce::dsp::IIR::Filter<float> highShelf;  // cut high freqs (faster decay)
    
    float process(float x) {
        float delayed = delayLine.read();
        float damped = dampingFilter.processSample(delayed);
        float shelved = highShelf.processSample(lowShelf.processSample(damped));
        delayLine.write(x + shelved * feedbackGain);
        return delayed;
    }
};
```

**RT60 per band → per-band gain calculation:**
```cpp
// gain = 10^(-3 * delay_time_seconds / RT60_seconds) for -60dB in RT60 seconds
float gainForBand(float delayTimeSec, float RT60sec) {
    return std::pow(10.0f, -3.0f * delayTimeSec / RT60sec);
}
```

---

## 8. Numerical Stability and Denormals

**High Q + low frequency = stability risk**:
- Q > 40 near DC: pole radius approaches 1.0, potential instability
- Maximum safe Q for audio: ~40 at Nyquist/4

**Denormal prevention** (critical in feedback paths):
```cpp
// Add DC offset to prevent denormals in feedback:
static const float kDenormalOffset = 1e-25f;
x += kDenormalOffset;

// Or use JUCE's helper:
juce::FloatVectorOperations::disableDenormalisedNumberSupport();
// Call once in prepareToPlay() — sets FTZ/DAZ CPU flags (SSE only)
```

---

## References

- Robert Bristow-Johnson, [Audio EQ Cookbook](https://webaudio.github.io/Audio-EQ-Cookbook/audio-eq-cookbook.html) (canonical reference)
- [W3C Audio EQ Cookbook](https://www.w3.org/TR/audio-eq-cookbook/) (web standard adaptation)
- [Musicdsp.org RBJ reference](https://www.musicdsp.org/en/latest/Filters/197-rbj-audio-eq-cookbook.html)
- Zölzer, U. (2011) "DAFX: Digital Audio Effects" (2nd Ed.) — Chapter 2: Filters
- Julius O. Smith III, [Introduction to Digital Filters](https://ccrma.stanford.edu/~jos/filters/) — CCRMA
- Jot, J.M. & Chaigne, A. (1991) "Digital Delay Networks" — frequency-dependent decay methodology
- JUCE docs: [dsp::IIR::Filter](https://docs.juce.com/master/classdsp_1_1IIR_1_1Filter.html)
- JUCE docs: [StateVariableTPTFilter](https://docs.juce.com/master/classdsp_1_1StateVariableTPTFilter.html)
