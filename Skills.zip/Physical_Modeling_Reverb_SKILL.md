# Physical Modeling Reverb SKILL

## 1. Why Physical Modeling for Reverb?

FDN reverbs model the STATISTICAL properties of reverberation (exponential decay, frequency-dependent damping). Physical models simulate the PHYSICAL MECHANISM of sound propagation in a medium. The result is room character, resonant modes, and geometric early reflections that feel real rather than computed.

Use physical modeling for:
- Resonant plate and spring reverb simulation
- Small room/box acoustics where modes are perceptually prominent
- Unusual acoustic spaces (caves, tunnels, pipes)
- Hybrid approaches: physical model provides early reflection character, FDN handles late tail

---

## 2. Modal Synthesis for Room Reverb

### Theory
A reverberant space has characteristic resonance frequencies (modes). Each mode is an exponentially-decaying sinusoid. The complete room response = sum of all modes.

US Patent US9805704B1 (and follow-up US11049482B1) cover the core method for artificial reverberation using modal decomposition.

### Architecture
Parallel bank of resonant bandpass filters (2-pole IIR each), one per mode:

```cpp
struct Mode {
    float freq, decayRate, amplitude;
    float state1 = 0, state2 = 0; // IIR state
    float sampleRate;

    float process(float input) {
        float omega = 2.0f * M_PI * freq / sampleRate;
        float R = std::exp(-M_PI * decayRate / sampleRate);
        float cosW = std::cos(omega);

        // Two-pole complex resonator:
        // H(z) = A / (1 - 2*R*cos(ω₀)*z⁻¹ + R²*z⁻²)
        float output = input * amplitude + 2.0f * R * cosW * state1
                       - R * R * state2;
        state2 = state1;
        state1 = output;
        return output;
    }
};

class ModalReverberator {
    std::vector<Mode> modes;
    int numModes = 0;

public:
    void addMode(float freq, float decayRate, float amplitude) {
        modes.push_back({freq, decayRate, amplitude, 0, 0, sampleRate});
        numModes++;
    }

    float process(float input) {
        float output = 0.0f;
        for (int i = 0; i < numModes; ++i) {
            output += modes[i].process(input);
        }
        return output / (float)numModes; // Normalize
    }
};
```

### Room Mode Frequencies
For a rectangular room (L×W×H metres):
```
f_nml = (c/2) * sqrt((n/L)² + (m/W)² + (l/H)²)
```
where c = 343 m/s, n,m,l are non-negative integers (not all zero). This gives axial, tangential, and oblique modes.

### Practical Mode Counts
- Small room (5×4×3m): hundreds of audible modes up to 500Hz
- Full room simulation to 20kHz: millions of modes — not practical
- Hybrid strategy: modal for low frequencies (<500Hz), FDN for high frequencies

### Modal Reverberation Advantages
- Explicit per-mode control (tune individual resonances)
- Natural mode beating and interference patterns
- Source and listener position affects which modes are excited (via mode shape functions)
- Smooth transition from sparse low-frequency modes to dense high-frequency reverb

---

## 3. Digital Waveguide Models

### Theory (Julius O. Smith III, CCRMA Stanford)
A digital waveguide models bidirectional wave propagation as two delay lines (left-traveling + right-traveling waves). Scattering junctions handle boundary conditions. Originally developed for string/tube synthesis, extended to 2D/3D meshes for room simulation.

### 1D Waveguide (String/Plate Element)

```
y+(n, x) = wave traveling in +x direction
y-(n, x) = wave traveling in -x direction

At each time step:
y+(n+1, x+1) = y+(n, x)   (propagation)
y-(n+1, x-1) = y-(n, x)   (propagation)
```

At boundaries: reflection coefficient ρ determines absorption. For a lossy boundary:
```cpp
float boundary_reflect(float wave_incident, float reflection_coeff) {
    return reflection_coeff * wave_incident;
}
```

### 2D Waveguide Mesh (Room Simulation)
A rectangular mesh of bidirectional waveguides. Each junction scatters energy to all connected branches. The 2D mesh naturally simulates:
- Frequency-dependent wave propagation
- Geometry-based diffraction and reverberation
- Echo density grows naturally with time
- Diffuse field develops organically

**Efficiency**: 2D multi-plane simulation achieves ~98% computation reduction vs full 3D FDTD, enabling near-real-time performance.

```cpp
// Simplified 2D mesh junction (4-port scatterer)
struct MeshJunction {
    float north_in, south_in, east_in, west_in;
    float north_out, south_out, east_out, west_out;

    void scatter() {
        // Lossless junction: sum all inputs, distribute equally
        float sum = north_in + south_in + east_in + west_in;
        float avg = sum * 0.25f;

        north_out = avg - north_in;
        south_out = avg - south_in;
        east_out = avg - east_in;
        west_out = avg - west_in;
    }
};
```

### 3D Waveguide Mesh
Tetrahedral or rectilinear 3D mesh for full volumetric room simulation. More physically accurate but expensive. Achieves real-time on modern hardware for modest room sizes (Wayverb project demonstrates this).

### Key Projects & References
- **Wayverb** (GitHub): C++ room acoustic simulator using waveguide mesh + ray tracing hybrid
- **Planeverb** system: real-time 2D waveguide simulation, open-source C++ code
- **EVERTims**: Blender + C++ ray tracing + JUCE auralization engine
- **CCRMA Digital Waveguide Mesh**: ccrma.stanford.edu/~jos/pasp/

---

## 4. Plate Reverb Physical Model

A plate reverb (EMT 140 style) is a large thin steel plate with transducers. Physical model uses 2D waveguide mesh (rectangular or triangular lattice) or coupled bending wave equations.

### Key Parameters
- Plate dimensions (determines mode frequencies and decay)
- Plate tension (affects wave speed; stiffer = higher frequency content)
- Plate damping (determines RT60; higher damping = shorter reverb)
- Transducer positions (source input, stereo pickup points)
- Magnetic damping strength (EMT plates had electromagnetic loss)

### Simplified Digital Plate Model
For real-time plugin use, approximate with:
1. Dense modal filter bank (hundreds of modes using efficient mass-spring network)
2. Schroeder's allpass chain tuned to plate characteristics
3. Hybrid: measured plate IR for early reflections + FDN for late tail

### Reference: Dattorro Plate (1997)
Dattorro's "Effect Design Part 1" describes a specific allpass-loop architecture that achieves authentic plate-like character. All delay lengths are published (samples at 29761Hz). Scale proportionally for different sample rates:

```cpp
// Dattorro plate model: pre-delay + allpass loops
class DattorroPlate {
    DelayLine predelay;
    AllpassFilter bandwidthFilter;
    AllpassFilter apLoop[4]; // Nested allpass loops
    DelayLine decayDelays[2];

    float sampleRate;

public:
    float process(float input) {
        // Pre-delay and bandwidth filter
        float delayedInput = predelay.read();
        predelay.write(input);

        float bwFiltered = bandwidthFilter.process(delayedInput);

        // Two nested allpass loops (standard Dattorro architecture)
        float loop1 = bwFiltered;
        loop1 = apLoop[0].process(loop1);
        loop1 = apLoop[1].process(loop1);

        float loop2 = loop1;
        loop2 = apLoop[2].process(loop2);
        loop2 = apLoop[3].process(loop2);

        // Decay section with taps for stereo output
        float out_L = decayDelays[0].read(dlyL1) + decayDelays[0].read(dlyL2);
        float out_R = decayDelays[1].read(dlyR1) + decayDelays[1].read(dlyR2);

        decayDelays[0].write(loop2);
        decayDelays[1].write(loop2);

        return (out_L + out_R) * 0.5f;
    }
};
```

All delay line lengths must be carefully scaled. The architecture exhibits the dense, self-similar diffusion characteristic of plate reverb.

---

## 5. Spring Reverb Physical Model

Spring reverbs (guitar amps, vintage hardware) have distinctive "boing" character from dispersive propagation — high frequencies travel faster than low frequencies through the spring medium.

### Dispersive Delay Line
A spring can be modeled as a digital waveguide with frequency-dependent wave velocity via cascaded allpass filters:

```cpp
class SpringReverb {
    // Dispersion: chain of allpass filters creates frequency-dependent delay
    AllpassFilter dispersion[12]; // 12-stage cascade

    DelayLine feedbackDelay;
    BiquadFilter decayFilter; // First-order lowpass for RT60

    float feedbackGain = 0.7f;

public:
    float process(float input) {
        // Dispersive stage: allpass cascade shifts phase vs frequency
        float dispersed = input;
        for (int i = 0; i < 12; ++i) {
            dispersed = dispersion[i].process(dispersed);
            // Each allpass: H(z) = (a + z⁻¹) / (1 + a*z⁻¹)
            // Coefficient 'a' increases down the chain for increasing dispersion
        }

        // Feedback delay and decay filter
        float delayed = feedbackDelay.read();
        float decayed = decayFilter.process(delayed);

        float feedback = dispersed + decayed * feedbackGain;
        feedbackDelay.write(feedback);

        return delayed * 0.5f;
    }
};
```

Each allpass in the chain introduces group delay that increases with frequency, mimicking spring steel's propagation characteristics.

### Spring Model Architecture
- Multiple allpass stages (8-16) for dispersion
- Feedback with loss filter for decay
- Multiple "spring paths" with slightly different lengths for stereo imaging
- Optional biquad shaping to boost low-frequency "boing"

### Reference Implementations
- Faust spring reverb models in faustlibraries (open source)
- GuitarML spring reverb neural surrogate models

---

## 6. Hybrid Physical + Algorithmic Strategy

For a production reverb plugin competing with Valhalla Room or Lexicon:

**Recommended architecture:**
1. **Ray tracing / image source** for early reflections (0–80ms): geometrically accurate, position-dependent
2. **Modal synthesis** for room resonances (low freq, <500Hz): genuine mode character and beating
3. **FDN** for late reverb tail (80ms+): efficient, smooth, controllable decay

This is exactly what products like Wayverb and IRCAM room simulators do internally.

```cpp
class HybridReverberator {
    // Early reflections (geometric)
    ImageSourceModel earlyReflections;

    // Mid-range resonances (modal)
    ModalReverberator modalBank; // 50-200 modes

    // Late diffuse tail (statistical)
    FDNReverberator fdn; // 8×8 or larger

    float earlySplit = 0.08f; // 80ms crossover

public:
    float process(float input) {
        float early = earlyReflections.process(input);
        float mid = modalBank.process(input);
        float late = fdn.process(input);

        // Blend: early dominant in first 80ms, then transition to mid/late
        float blend = early + mid + late;
        return blend * 0.33f; // Normalize
    }
};
```

**CPU budget allocation:**
- Ray tracing: 1–5 early reflections per audio frame (amortize over multiple frames)
- Modal bank: 50–200 modes computed in parallel (vectorize with SIMD, process every Nth sample)
- FDN 8×8: bulk of CPU but well-understood, highly optimized

---

## 7. Implementation Considerations

### Frequency Warping
At very high sample rates, modal frequencies can alias. Use bilinear transform frequency warping to preserve mode spacing:
```
ω_digital = 2 * arctan(ω_analog / (2 * sampleRate))
```

### Computational Optimization
- **Modal bank**: vectorize with SSE/AVX; process modes in groups of 8
- **Waveguide mesh**: GPU acceleration for 3D meshes (OpenCL/CUDA)
- **Hybrid crossover**: use high-pass/low-pass split filters (order ≥2) to avoid audible transitions

### Early Reflection Diffraction
For accurate room simulation, include diffraction around room edges (higher order image sources). This is expensive but adds naturalness for small rooms.

---

## 8. Key Academic References & Resources

- Smith, J.O. "Physical Audio Signal Processing" — ccrma.stanford.edu/~jos/pasp/ (comprehensive, free)
- Smith, J.O. (1985-86) "Physical Modeling Using Digital Waveguides" — Computer Music Journal
- Savioja, L. et al. (1995) "Simulation of Room Acoustics using 2-D Digital Waveguide Meshes"
- Murphy, D.T. et al. "Room acoustics modelling using 3-D digital waveguide mesh structures"
- Abel, J.S. et al. (2010) "A Modal Architecture for Artificial Reverberation" — AES Preprint
- US Patent 9805704B1 — Modal decomposition reverb (Google/Stanford)
- US Patent 11049482B1 — Modal decomposition extensions
- Dattorro, J. (1997) "Effect Design Part 1: Reverberator and Other Filters" — CCRMA Stanford
- Belevitch & Fettweis "Wave Digital Filters" — foundational WDF theory
- Wayverb project: reuk.github.io/wayverb/ (C++17 open source room simulator)
- Planeverb: github.com/evanwilson2123/planeverb (2D waveguide mesh, C++)
- Nathan Ho "Exploring Modal Synthesis" — nathan.ho.name (excellent pedagogy)

---

## 9. Practical Checklist: Building a Physical Model Reverb

- [ ] Identify target acoustic space: rectangular room, plate, spring, pipe, cave?
- [ ] Calculate or measure mode frequencies and Q-values (damping)
- [ ] For small rooms: implement modal bank (50-500 modes depending on room size)
- [ ] For geometric accuracy: add early image source reflections (ray tracing)
- [ ] Implement waveguide mesh for mid-range diffuse character (optional but recommended)
- [ ] Use FDN for high-frequency tail (dense, smooth decay)
- [ ] Tune frequency-dependent absorption (air absorption filter, wall materials)
- [ ] Cross-validate with measured impulse response of real space
- [ ] Optimize for real-time: profile on target hardware, vectorize, consider GPU
- [ ] AB test against reference (hardware plate, room recording, commercial plugin)

---

This SKILL file is a reference document for engineers implementing physical modeling reverb in production audio software.
