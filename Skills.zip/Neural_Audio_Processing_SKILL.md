---
name: neural-audio-processing
description: |
  Comprehensive guide to neural network-based audio processing covering real-time inference frameworks (RTNeural, anira, Neutone), neural amp modeling (NAM with WaveNet/LSTM), generative audio models (RAVE, DDSP), perceptual loss functions (auraloss), temporal convolutional networks (micro-TCN), vocoders (HiFi-GAN, WaveNet), and deployment pipelines for audio plugins. Essential for integrating ML models into low-latency audio applications. Trigger on: neural network, machine learning, deep learning, RTNeural, NAM, Neural Amp Modeler, RAVE, DDSP, vocoder, WaveNet, LSTM, GRU, TCN, auraloss, inference, model deployment, amp modeling, guitar modeling, generative audio, neural DSP, Pedalboard, Neutone, anira, TorchScript, ONNX.
---

## Real-Time Neural Inference Frameworks

### RTNeural
Header-only C++ library for real-time-safe neural network inference. No dynamic memory allocation after initialization. Supports LSTM, GRU, dense layers, and 1D convolutions.

**Key Features**:
- Template-based architecture: model size known at compile time → zero runtime overhead for layer dispatch
- SIMD-optimized: uses Eigen or xsimd backends for vectorized matrix operations
- No dependencies on Python/TensorFlow/PyTorch at runtime
- Stateful RNN support (LSTM/GRU) critical for amp modeling

**Integration Pattern**:
```cpp
#include <RTNeural/RTNeural.h>

// Compile-time model definition
RTNeural::ModelT<float, 1, 1,
    RTNeural::LSTMLayerT<float, 1, 16>,
    RTNeural::DenseT<float, 16, 1>> model;

// Load weights from JSON (prepareToPlay)
model.load_json(modelJsonStream);
model.reset();  // Clear LSTM state

// Process sample-by-sample (processBlock)
for (int i = 0; i < numSamples; ++i) {
    float input[] = { buffer[i] };
    float output = model.forward(input);
    buffer[i] = output;
}
```

**Performance**: RTNeural achieves sub-millisecond inference for typical amp models (16-32 hidden units). Suitable for 64-sample buffer sizes at 48kHz.

**Model Export Pipeline**: Train in PyTorch → export weights to JSON → load in RTNeural C++ at plugin initialization.

### anira
Framework for cross-library real-time-safe neural network inference. Supports multiple backends (LibTorch, ONNX Runtime, TensorFlow Lite) with a unified API. Handles threading and buffer management for real-time audio.

**Key advantage**: Backend-agnostic deployment — train with any framework, deploy with optimal backend per platform.

**Architecture**: Outsources inference to a static thread pool, keeping the audio callback free of blocking operations. Handles chunked processing for networks expecting fixed input sizes.

**Backend performance**: For stateless models, ONNX Runtime exhibits lowest runtimes. For stateful models (LSTM/GRU), LibTorch demonstrates fastest performance.

**Supported versions**: TensorFlow Lite 2.16.1, ONNX Runtime 1.17.1, LibTorch 2.2.2 (as of latest release). Cross-platform: Linux, macOS, Windows.

### Neutone SDK
Plugin framework by Qosmo for deploying neural audio models as VST/AU plugins. Wraps PyTorch models with a standardized interface. Provides:
- Model packaging format with metadata
- Built-in latency compensation and sample rate conversion
- Parameter mapping from plugin knobs to model inputs
- Variable buffer size handling
- Community model sharing platform (Neutone FX / Neutone Gen)

**Key advantage**: Deploy PyTorch models to DAW in less than a day without any C++ knowledge. Models are wrapped with minimal Python code and executed by the Neutone Plugin host.

**Applications**: Audio effect emulation, timbre transfer, sample generation. Adopted by researchers, educators, companies, and artists.

### GuitarML Suite
Open-source JUCE plugins using neural networks for guitar effect emulation:
- **SmartGuitarAmp**: JUCE plugin using neural networks to emulate tube amplifiers (clean + lead channels with EQ/gain)
- **SmartGuitarPedal**: WaveNet model recreating hardware pedals (TS9 Tubescreamer, Blues Jr)
- **PedalNetRT**: Training pipeline for WaveNet guitar effect models, exports to JSON for plugin loading
- **NeuralPi**: Raspberry Pi guitar pedal using neural networks

All use RTNeural engine for competitive CPU performance. Available as VST3, AU, AAX (Windows/macOS/Linux).

---

## Neural Amp Modeling (NAM)

### Architecture
Neural Amp Modeler uses WaveNet-style dilated convolutional networks or LSTM/GRU recurrent networks to model guitar amplifiers and effects pedals.

**WaveNet variant** (preferred for quality):
- Dilated causal convolutions with exponentially increasing dilation factors (1, 2, 4, 8, 16, ...)
- Gated activation units (tanh × sigmoid)
- Residual and skip connections
- Captures long-range temporal dependencies critical for amp dynamics
- Causality enforced by asymmetric padding proportional to dilation factor
- Typical configuration: 9 layers, filter width 3, dilation pattern {1,2,4,...,512} → receptive field ~2046 samples (~46ms at 44.1kHz)
- Largest real-time model: 18 layers, 16 channels; or 24 layers with 8 channels

**LSTM variant** (lower CPU):
- Single or stacked LSTM layers (typically 16-32 hidden units)
- Lower computational cost but less accurate for complex nonlinearities
- Better suited for overdrive pedals than full amp models

### Training Pipeline
1. **Capture**: Play standardized test signal (sweep + noise + music) through real amp, record DI and amped signals
2. **Preprocessing**: Align signals, normalize, segment into training examples
3. **Training**: Minimize MSE + optional perceptual loss between model output and target
4. **Validation**: Compare on held-out audio, measure ESR (Error-to-Signal Ratio)
5. **Export**: Convert to RTNeural JSON or ONNX format

### ESR (Error-to-Signal Ratio)
Primary quality metric: `ESR = ||y_pred - y_true||² / ||y_true||²`. Good models achieve ESR < 1%. Professional quality: ESR < 0.1%.

### Deployment Considerations
- **Conditioning**: Many amps have knob settings (gain, tone, volume). Condition the network on these parameters using FiLM (Feature-wise Linear Modulation) layers, concatenation, or hypernetworks. FiLM applies learned scaling and shifting to feature maps: `output = γ(condition) * features + β(condition)`. Conditioning blocks can be placed before/after core layers. FiLM performs strongly for continuous control of modulation effects (phasers, flangers).
- **Latency**: WaveNet models process sample-by-sample with no algorithmic latency. LSTM models also have zero latency.
- **State management**: LSTM/GRU hidden states must be reset on transport stop or when DAW sends silence.
- **Oversampling**: Some models benefit from 2× oversampling to reduce aliasing from internal nonlinearities.

---

## Generative Audio Models

### RAVE (Real-time Audio Variational autoEncoder)
Developed at IRCAM by Antoine Caillon. Two-stage architecture for real-time audio synthesis and transformation.

**Architecture**:
- **Encoder**: Multi-band decomposition → 1D convolutions → latent space (typically 8-16 dimensions)
- **Decoder**: Upsampling convolutions → waveform reconstruction
- **Training Stage 1**: Reconstruction loss (spectral + waveform)
- **Training Stage 2**: Adversarial training with multi-scale discriminator for perceptual quality

**Real-time capabilities**:
- Runs at 48kHz, generating audio 20× faster than real-time on standard laptop CPU
- Latent space enables timbre transfer, interpolation, and manipulation
- Can be exported to TorchScript for C++ deployment
- nn~ external available for Max/MSP and PureData integration
- Multi-band decomposition of raw waveform enables efficient 48kHz generation

**Latent Space Manipulation**: High compression ratio means the latent representation captures high-level attributes. Techniques include: direct latent space manipulation, Adaptive Instance Normalization (inspired by StyleGAN) for style transfer defining source/target styles directly in Max/MSP.

**Use cases**: Timbre transfer (make a voice sound like a violin), audio texture generation, creative sound design, latent space exploration. Ongoing RAVE Model Challenge at IRCAM for community model creation.

### DDSP (Differentiable Digital Signal Processing)
Google Magenta's framework combining classical DSP with neural networks.

**Core Idea**: Instead of generating raw waveforms, neural networks predict parameters for traditional DSP components (oscillators, filters, reverb). This produces higher-quality audio with less training data.

**Components**:
- **Harmonic additive synthesizer**: Sums sinusoids at harmonic (integer) multiples of F0, with neural network predicting amplitudes per harmonic
- **Subtractive noise synthesizer**: Filters white noise with time-varying learned filter coefficients
- **Reverb**: Learned impulse response applied as convolution
- **Encoder**: Extracts pitch via CREPE (convolutional pitch tracker, state-of-the-art F0 estimation) and loudness from input audio

**Training**: Loss computed by comparing spectrograms at six different frame sizes between generated and source audio. All components are differentiable (including spectrograms), enabling end-to-end backpropagation.

**Advantages over raw waveform models**:
- Much smaller models (< 1M parameters vs 100M+ for WaveNet)
- Faster training (hours vs days)
- Interpretable parameters (pitch, loudness, timbre)
- Guaranteed audio-rate output quality

**Limitations**: Best suited for monophonic, harmonic sounds (instruments, voice). Struggles with drums, noise-heavy textures, polyphonic material.

---

## Perceptual Loss Functions (auraloss)

### Overview
Library by Christian Steinmetz providing differentiable audio loss functions for training neural audio models. Standard MSE loss often produces "muddy" results; perceptual losses better match human hearing.

### Key Loss Functions

**Multi-Resolution STFT Loss** (most commonly used):
- Compute STFT at multiple window sizes (e.g., 512, 1024, 2048, 4096)
- Combine spectral convergence loss + log magnitude loss at each resolution
- Captures both fine temporal detail (small windows) and frequency resolution (large windows)

**Mel-Spectral Loss**:
- Apply mel filterbank to STFT magnitudes
- Emphasizes perceptually important frequency bands
- Better correlates with human perception of timbre

**STFT Loss with Phase**:
- Includes phase information alongside magnitude
- Important for transient preservation

**Multi-Scale Spectral Energy Loss**:
- Operates on energy in frequency sub-bands
- Robust to small timing misalignments

### Usage Pattern
```python
import auraloss

# Multi-resolution STFT loss
mrstft_loss = auraloss.freq.MultiResolutionSTFTLoss(
    fft_sizes=[512, 1024, 2048],
    hop_sizes=[128, 256, 512],
    win_lengths=[512, 1024, 2048]
)

# In training loop
loss = mrstft_loss(predicted_audio, target_audio)
loss.backward()
```

### Best Practice
Combine multiple losses: `total_loss = MSE + λ₁ * MRSTFT + λ₂ * Mel`. Weight hyperparameters (λ) typically in range 0.1-10.0, tuned by listening.

---

## Temporal Convolutional Networks (TCN)

### micro-TCN (Steinmetz)
Lightweight temporal convolutional network architecture for audio effects modeling. Published at DAFx 2020.

**Architecture**:
- Stack of dilated 1D causal convolutions
- Dilation factors: 1, 2, 4, 8, 16, ... (exponential growth)
- PReLU activations
- Residual connections
- FiLM (Feature-wise Linear Modulation) conditioning for parameters

**Advantages over RNNs**:
- Parallelizable training (no sequential dependency)
- Stable gradients (no vanishing/exploding gradient problem)
- Deterministic compute cost (no variable-length hidden states)
- Receptive field grows exponentially with depth

**steerable-nafx**: Extension allowing continuous parameter control of modeled effects (e.g., smoothly adjusting drive knob of modeled pedal). Uses FiLM layers to condition the TCN on effect parameters.

**Performance**: ~10× faster than equivalent WaveNet for similar quality on simple effects (compressor, EQ). Less suitable for highly nonlinear effects (heavy distortion).

---

## Vocoders

### WaveNet
Autoregressive generative model. Generates audio sample-by-sample, conditioning each sample on all previous samples.

**In audio plugins**: Primarily used as the architecture backbone for amp modeling (see NAM section). Full autoregressive WaveNet is too slow for real-time synthesis but the dilated convolution architecture is adapted for non-autoregressive use.

### HiFi-GAN
GAN-based vocoder for high-fidelity speech/audio synthesis. Generates waveforms from mel spectrograms.

**Architecture**:
- **Generator**: Transposed convolutions for upsampling + multi-receptive field fusion
- **Discriminators**: Multi-Period Discriminator (MPD) + Multi-Scale Discriminator (MSD)
- Achieves near-transparent audio quality at 22kHz

**Relevance to plugins**: Used as the decoder stage in neural audio synthesis pipelines. Can run in real-time on GPU; CPU inference possible with optimized ONNX export.

---

## Deployment & Production

### Spotify Pedalboard
Python library for applying audio effects chains efficiently. Built on JUCE internally.

**Use for neural audio**: Fast offline processing pipeline for training data augmentation, batch inference evaluation, and A/B testing. Not for real-time plugin use but excellent for the training/evaluation pipeline.

```python
import pedalboard
board = pedalboard.Pedalboard([
    pedalboard.Compressor(threshold_db=-20),
    pedalboard.Reverb(room_size=0.5)
])
output = board(input_audio, sample_rate=48000)
```

### Model Optimization for Real-Time
1. **Quantization**: Float32 → Float16 or Int8 reduces compute by 2-4× with minimal quality loss. ONNX supports dynamic quantization (weights only, simpler) and static quantization (weights + activations, requires calibration data). Best results on x86-64 with VNNI or ARM with dot-product instructions.
2. **Pruning**: Remove near-zero weights. Unstructured pruning removes individual weights; structured pruning removes entire neurons/channels (more hardware-friendly). 30-50% sparsity typical without quality degradation. Can be applied during training (train-time) or after (post-training).
3. **Knowledge distillation**: Train small "student" model to mimic large "teacher" by minimizing loss against teacher's soft probability outputs. Effective for deploying on mobile/embedded devices.
4. **ONNX Runtime**: Cross-platform optimized inference with hardware-specific kernels. Supports CPU/GPU execution providers.
5. **TorchScript**: PyTorch's JIT compilation for C++ deployment without Python. Two conversion methods: tracing (evaluates model once with example input, captures computation graph) and scripting (parses model code with annotations). Tracing is simpler but can't handle dynamic control flow. Expect 3× or more speed gain vs Python inference. Load in C++ via `torch::jit::load()`.

### Integration Checklist
- [ ] Model inference is real-time safe (no allocations, no locks)
- [ ] Hidden states properly reset on transport changes
- [ ] Input/output normalization matches training pipeline
- [ ] Latency reported correctly to DAW
- [ ] CPU usage stays under 30% of buffer budget (leave headroom)
- [ ] Model weights loaded asynchronously (not on audio thread)
- [ ] Graceful fallback if model fails to load

---

## References
- [RTNeural](https://github.com/jatinchowdhury18/RTNeural) - Real-time neural network inference
- [Neural Amp Modeler](https://github.com/sdatkinson/NeuralAmpModelerPlugin) - Guitar amp modeling
- [RAVE](https://github.com/acids-ircam/RAVE) - Real-time Audio Variational autoEncoder
- [DDSP](https://github.com/magenta/ddsp) - Differentiable Digital Signal Processing
- [auraloss](https://github.com/csteinmetz1/auraloss) - Perceptual audio loss functions
- [micro-TCN](https://github.com/csteinmetz1/micro-tcn) - Lightweight TCN for audio effects
- [steerable-nafx](https://github.com/csteinmetz1/steerable-nafx) - Controllable neural audio effects
- [Pedalboard](https://github.com/spotify/pedalboard) - Spotify's audio effects library
- [Neutone SDK](https://github.com/QosmoInc/neutone_sdk) - Neural audio plugin framework
- [anira](https://github.com/anira-project/anira) - Cross-library real-time neural inference
- [HiFi-GAN](https://github.com/jik876/hifi-gan) - High-fidelity vocoder
- [DAFx Proceedings](https://www.dafx.de/) - Digital Audio Effects conference papers
