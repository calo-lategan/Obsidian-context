---
name: proprietary-tools-industry
description: |
  Guide to professional audio industry tools, proprietary plugin frameworks, and scripting environments covering Kontakt KSP scripting, iZotope audio analysis/processing, Native Instruments developer ecosystem, LANDR automated mastering, SoundToys effect design, FabFilter DSP techniques, and industry deployment practices. Essential for understanding commercial plugin architectures and integrating with industry-standard tools. Trigger on: Kontakt, KSP, iZotope, Native Instruments, LANDR, SoundToys, FabFilter, commercial plugin, industry tools, sampler scripting, auto-mastering, proprietary, professional audio tools.
---

## Kontakt KSP Scripting

### Overview
Kontakt Script Processor (KSP) is Native Instruments' scripting language for building custom instruments within the Kontakt sampler platform. Event-driven, C-like syntax.

### Core Callbacks
```ksp
on init
    { Initialization: declare variables, UI elements, set parameters }
    declare ui_knob $volume (0, 1000000, 1)
    set_knob_defval($volume, 500000)
    declare %note_ids[128]
end on

on note
    { Triggered for every MIDI note-on }
    %note_ids[$EVENT_NOTE] := $EVENT_ID
    change_vol($EVENT_ID, $volume, 1)
end on

on release
    { Triggered for every MIDI note-off }
end on

on ui_control ($volume)
    { Triggered when user moves the volume knob }
end on

on controller
    { Triggered for MIDI CC messages }
    if ($CC_NUM = 1)  { Mod wheel }
        set_knob_unit($volume, $CC[1] * 7874)
    end if
end on
```

### Key Concepts
- **Event manipulation**: `change_vol()`, `change_tune()`, `change_pan()` modify note events in real-time
- **Groups**: Kontakt organizes samples into groups. KSP controls group routing, volume, and articulation switching
- **Time machine**: Kontakt's time-stretching engine, controllable via KSP for tempo-synced playback
- **Zones**: Individual sample mappings. KSP can modify zone parameters (tune, volume, pan) per-voice
- **Multiscript**: Runs across all instruments in a Kontakt instance — used for keyswitching and global control

### Performance Scripting
- **Arrays**: Use `%array[]` for lookup tables. Pre-compute values in `on init`.
- **Polyphonic variables**: Declare with `declare polyphonic` for per-voice data (e.g., per-note filter settings)
- **wait()**: Pauses script execution for timed events (ms resolution). Use for arpeggiation, delays, sequences.

### UI Building
KSP supports basic UI elements: knobs, sliders, buttons, labels, menus, tables, value editors, XY pads, waveform displays, file selectors.

**Limitations**: No custom graphics in pure KSP. Advanced UIs require NKS (Native Kontrol Standard) integration or Kontakt Creator Tools.

### Creator Tools & Libraries
- **Kontakt Creator Tools**: Official toolkit with 3 components: Debugger (KSP debugging), Instrument Editor (Lua scripting for batch operations), GUI Designer (visual performance view assembly without code)
- **Kontakt 7+ Lua API**: Programmatic instrument editing — rearrange/add/remove groups and zones, edit names and properties (tune, volume, mapping). MIR functions (pitch detection, RMS) assist automated instrument creation. Limited file system access for creating instruments from samples on disk.
- **KSP + Lua complementary**: Lua handles instrument construction/editing workflow; KSP handles real-time performance scripting and UI control-to-engine parameter connections.
- **Community resources**: KSP reference, VI-Control forums, David Hilowitz tutorials

---

## iZotope Audio Technology

### Analysis Tools
iZotope's products showcase advanced audio analysis techniques relevant to plugin development:

**Spectral Analysis**:
- Multi-resolution spectrogram with adjustable FFT sizes
- Spectral repair: identify and fill gaps in frequency content
- Inter-channel phase correlation display

**Metering**:
- True peak measurement (ITU-R BS.1770)
- LUFS loudness metering (integrated, short-term, momentary)
- Dynamic range visualization
- Tonal balance analysis against target curves

### DSP Techniques from iZotope Products

**Ozone (Mastering)**:
- Multi-band dynamics with adaptive thresholds
- IRC (Intelligent Release Control) limiting: program-dependent release
- Spectral shaping: EQ that follows tonal balance targets
- Codec preview: audition lossy compression artifacts before export

**RX (Audio Repair)**:
- Spectral denoise: learn noise profile from selection, subtract from signal
- De-clip: reconstruct waveform peaks from clipped audio using prediction
- Dialogue isolate: ML-based source separation (vocal extraction)
- De-reverb: estimate and remove room reverb from recordings

**Neutron (Mixing)**:
- Automatic frequency masking detection between tracks
- AI-assisted EQ suggestions based on content analysis
- Transient shaping with independent attack/sustain control

### Machine Learning in iZotope
iZotope pioneered ML in audio processing:
- **Assistant features**: Analyze audio content, suggest processing settings. Repair Assistant uses AI noise removal with improved intelligence and speed.
- **Source separation**: State-of-the-art neural networks for Music Rebalance (stem separation) and Dialogue Isolate (real-time, low-latency)
- **Classification**: Automatic detection of audio content type (speech, music, noise)
- **Adaptive processing**: Spectral De-noise Adaptive Mode analyzes changing noise profiles in real-time

---

## Native Instruments Ecosystem

### NKS (Native Kontrol Standard)
Open-source protocol for integrating plugins with NI hardware controllers (Komplete Kontrol, Maschine). Third-party VST developers can integrate it into their software. Provides:
- Automatic parameter mapping to 8 hardware knobs — plug-in manufacturers design musically-relevant mappings
- Preview sound generation for browsing
- Tag-based preset categorization with streamlined browsing
- Light guide integration for keyboard controllers
- Smart Play features (scales, chords, arpeggios)
- No manual MIDI learn required — presets load with controls pre-mapped

### Reaktor & Reaktor Blocks
Visual DSP programming environment. Relevant concepts:
- **Core cells**: Low-level DSP building blocks — anti-aliased oscillators, ZDF filters, granular synthesis engines. Core Technology enables viewing/editing internal structure of any module.
- **Primary-level**: Higher-level signal routing and macro construction
- **Blocks**: Eurorack-style modular patching within Reaktor. Diverse modules for creating custom synths.
- **Table framework**: Wavetable oscillators with lo-fi modes authentically modeling vintage digital converters (noise + jitter)
- **ILO (Infinite Linear Oversampling)**: DSP technique for waveshapers, samplers, wavetables — greatly reduces aliasing for clean/analog sound
- **Manipulating Core Cells** requires deep knowledge of algorithmic signal generation/processing

### MIDI 2.0 & MPE
NI is a major driver of MIDI 2.0 adoption:
- **Per-note controllers**: Pitch, pressure, timbre per note. MIDI 2.0 natively supports per-note control (MPE was a workaround squeezing per-note expressivity out of MIDI 1.0)
- **High-resolution**: Velocities now 65k steps (vs 128). MIDI 2.0's Note Number Rotation uses single MIDI Channel with 128-note polyphony.
- **Bidirectional communication**: Automatic device discovery and protocol negotiation. Self-describing devices.
- **Per-note articulation**: Articulation/variation data recorded on the note itself, simplifying arrangements
- **Property exchange**: Bidirectional configuration and metadata between device and host
- **Windows 11 (Feb 2026)**: Native MIDI 2.0 support added

---

## Automated Mastering (LANDR)

### Technical Approach
LANDR and similar services use:
- **Audio analysis**: Spectral content classification, loudness measurement, dynamic range assessment
- **Rule-based processing**: EQ curves, compression settings, limiting targets derived from genre-specific templates
- **ML-assisted decisions**: Neural networks trained on professionally mastered tracks to predict processing chains
- **Adaptive processing**: Parameters adjust based on input characteristics (bright source → less HF boost)

### Relevance to Plugin Development
Understanding automated mastering informs:
- **Intelligent defaults**: Analyze input to set initial plugin parameters
- **Genre-aware processing**: Adjust behavior based on content classification
- **Loudness targeting**: Automatic gain staging to meet platform standards (Spotify -14 LUFS, YouTube -13 LUFS, Apple Music -16 LUFS)

---

## Commercial Plugin Design Patterns

### FabFilter Approach
Known for clean, efficient DSP and innovative UI:
- **Linear-phase EQ**: Zero-latency mode matches analog magnitude response without latency. Natural Phase mode matches both magnitude AND analog phase response.
- **Mathematical Nyquist correction**: Uses mathematical technique (not oversampling) to eliminate filter pre-warping at Nyquist — adjusts transfer function directly
- **Dynamic EQ**: Any band (Bell/Shelf) at any slope, with program-dependent attack/release/knee that adapt to frequency range and dynamic content. Works in linear phase mode.
- **Spectral Dynamics**: Per-frequency-bin dynamic processing (expand, compress, gate across the spectrum)
- **Visualization**: Real-time spectrum analyzer integrated with EQ curve display

### SoundToys Approach
Known for analog modeling and creative effects:
- **Circuit modeling**: Collected and analyzed vintage/modern hardware (consoles, preamps, EQs, compressors, distortion units) to create responsive models faithful to real-world counterparts
- **Saturation algorithms**: Five models in Decapitator based on iconic gear: Ampex tape machine, EMI channel, Neve 1057 (Germanium transistors), Thermionic Culture Vulture Triode and Pentode settings
- **Modulation**: Tempo-synced LFOs, envelope followers, rhythm patterns
- **Character through imperfection**: Subtle noise, drift, and nonlinearity. Dynamic responsive models, not static convolution snapshots

### Universal Audio / Plugin Alliance
DSP-focused hardware/software ecosystem:
- **DSP acceleration**: UAD-2 devices contain dedicated DSP processing chips that offload plugin processing from CPU. Enables low-latency monitoring/recording through UAD plugins. Up to 6 UAD cards/devices can be linked in a single system.
- **Plugin formats**: VST3, VST2, AU, AAX. Listed in DAW as "UAD" plugins.
- **Exact analog modeling**: Measurement-based modeling of specific hardware units
- **UAD Native vs DSP**: Native plugins run on host CPU; DSP plugins require UAD-2 hardware. Both offer same algorithms but DSP version offloads processing.

### Loudness Standards
Platform-specific targets: Spotify -14 LUFS, YouTube -13 LUFS, Apple Music -16 LUFS. ITU-R BS.1770-4 defines measurement algorithms for LUFS and true peak. EBU R128 standard for broadcast. True peak detection uses inter-sample peak measurement to find where signal exceeds 0 dBFS after sample rate conversion. Maximum permitted: -1 dBTP.

### Deployment Best Practices
- **Copy protection**: iLok (USB dongle or cloud-based licensing via PACE Anti-Piracy), eLicenser, serial-based, or machine-tied licensing. iLok supports USB-A/USB-C dongles, iLok Cloud (no hardware needed), or machine activation. Industry standard for professional plugins.
- **Preset management**: Standardized preset format with metadata (genre, character, author)
- **A/B comparison**: Built-in before/after comparison in plugin UI
- **Undo/redo**: State management for parameter changes
- **DAW compatibility testing**: Test across Logic, Ableton, FL Studio, Pro Tools, Cubase, Reaper, Studio One
- **Pluginval**: Automated validation tool (required by JUCE community, catches common bugs)

---

## References
- [KSP Reference Manual](https://www.native-instruments.com/ni-tech-manuals/ksp-manual/en/) - Official Kontakt scripting docs
- [Kontakt Creator Tools](https://www.native-instruments.com/en/products/komplete/samplers/kontakt-7/creator-tools/) - Instrument building toolkit
- [iZotope Learn](https://www.izotope.com/en/learn.html) - Audio education resources
- [NKS Developer Program](https://www.native-instruments.com/en/specials/nks/) - NI integration standard
- [LANDR Blog](https://www.landr.com/en/blog) - Mastering technology articles
- [FabFilter Technical Articles](https://www.fabfilter.com/help/) - DSP implementation details
- [DAFx Proceedings](https://www.dafx.de/) - Conference papers on commercial audio techniques
- [Pluginval](https://github.com/Tracktion/pluginval) - Plugin validation tool
