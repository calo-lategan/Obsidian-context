---
name: juce-plugin-fundamentals
description: |
  Complete guide to JUCE plugin development covering project setup, audio DSP fundamentals, real-time audio constraints, plugin architecture (VST3/AU/AAX/CLAP), common effect implementations, performance optimization, parameter automation, UI design, neural network inference, and best practices. Use this skill whenever the user is designing, implementing, or optimizing audio plugins in JUCE, whether they're asking about reverb algorithms, compression dynamics, filter design, threading models, audio quality, plugin formats, real-time safety, UI frameworks, or any audio plugin development challenge. Trigger on mentions of: JUCE, audio plugins, VST, AU, AAX, CLAP, audio effects, reverb, compressor, equalizer, filter design, real-time audio, plugin architecture, audio DSP, plugin UI, parameter automation, or audio processing in C++.
compatibility: JUCE framework, C++17+, modern plugin format SDKs (VST3 SDK, Apple AU, CLAP SDK)
---

## Overview

JUCE plugin development requires understanding audio processing fundamentals, real-time constraints, plugin architectures, and modern C++ patterns. This guide synthesizes best practices from hundreds of production audio plugins, academic research, and JUCE technical documentation.

### Key Principles

1. **Real-Time Audio is Unforgiving** - Audio callbacks cannot allocate memory, call system APIs, or block. Violating this causes dropouts, glitches, and user frustration.
2. **Sample-Accurate Automation** - Modern plugins need parameter changes to take effect at exact sample positions for clean, artifact-free automation.
3. **Cross-Platform Consistency** - Your plugin must sound identical and behave predictably on macOS (AU/VST3), Windows (VST3/AAX), and Linux (VST3/CLAP).
4. **Performance Matters** - CPU efficiency directly affects how many plugin instances users can stack. Small optimizations compound.

---

## Part 1: Project Setup and Architecture

### Choosing Your Plugin Format

| Format | macOS | Windows | Linux | Key Advantages |
|--------|-------|---------|-------|----------------|
| **VST3** | High | High | High | Broadest DAW support, 64-bit params, context menus |
| **AU** | Excellent | ✗ | ✗ | Apple-native, required for Logic/GarageBand |
| **AAX** | Good | Supported | ✗ | Pro Tools only, requires paid Avid SDK |
| **CLAP** | Growing | Growing | Excellent | Open-source (MIT), per-note modulation, MIDI 2.0, efficient threading model, no licensing fees |

**CLAP Advantages (from latest research):**
CLAP takes multi-thread management to a new level with clear role allocation between plugin and DAW. Its modular extension system supports per-note automation and modulation (like MIDI 2.0), non-destructive parameter modulation, and improved multicore CPU performance. As of 2025, ~15 DAWs support CLAP (Bitwig, Reaper, FL Studio) with ~400 plugins available.

**Recommendation**: VST3 + AU for broadest reach. Add CLAP for modern features and Linux. AAX only for Pro Tools.

### Pamplejuce: Production-Ready Template

For professional plugin projects, start with [Pamplejuce](https://github.com/sudara/pamplejuce) - a JUCE 8 template with:
- GitHub Actions CI/CD for macOS, Windows, Linux
- Catch2 unit testing framework
- Pluginval automated plugin validation
- macOS notarization + Azure Trusted Signing
- Melatonin Inspector for UI debugging
- C++20 support out of the box

```bash
# Start a new plugin from the template
gh repo create my-plugin --template sudara/pamplejuce --clone
cd my-plugin && cmake -B build -DCMAKE_BUILD_TYPE=Release
```

### CMake Configuration

```cmake
juce_add_plugin(MyPlugin
    PRODUCT_NAME "My Awesome Plugin"
    PLUGIN_MANUFACTURER_CODE Manu
    PLUGIN_CODE Plug
    FORMATS VST3 AU CLAP                # Include CLAP!
    VST_NUM_MIDI_INPUTS 16
    AU_MAIN_TYPE kAudioUnitType_Effect
    COPY_PLUGIN_AFTER_BUILD TRUE)

# Link recommended optimization flags
target_link_libraries(MyPlugin PRIVATE
    juce::juce_recommended_config_flags
    juce::juce_recommended_lto_flags      # Link-time optimization
    juce::juce_recommended_warning_flags)
```

**Build Optimization Tips:**
- Enable LTO (link-time optimization) via `juce_recommended_lto_flags` for 10-30% smaller binaries
- Strip symbols in Release builds (`-s` linker flag or `strip` post-build)
- Use `-ffunction-sections -fdata-sections` + `--gc-sections` for dead code elimination
- RelWithDebInfo builds may be larger than Release even after stripping

---

## Part 2: AudioProcessor - The Core

### Essential Methods

```cpp
class PluginProcessor : public AudioProcessor {
    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void processBlock(AudioBuffer<float>& buffer, MidiBuffer& midiMessages) override;
    void releaseResources() override;
    void getStateInformation(MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    AudioProcessorValueTreeState apvts;
};
```

### Real-Time Safety Rules for processBlock()

- ❌ No `new`/`malloc` - audio thread cannot allocate
- ❌ No locks/mutexes - they can block indefinitely
- ❌ No file I/O, network, or system calls
- ❌ No std::string operations or containers that reallocate
- ❌ No virtual dispatch in hot loops (use templates or function pointers)
- ✅ Read from `std::atomic<>` (lock-free parameter updates)
- ✅ Pre-allocated circular buffers for delay lines
- ✅ Simple math with pre-computed lookup tables

### Parameter Updates: The Safe Way

```cpp
std::atomic<float> dryWetMix{0.5f};

// Non-real-time thread (UI/DAW) writes:
dryWetMix.store(newValue, std::memory_order_relaxed);

// Real-time thread reads:
float mix = dryWetMix.load(std::memory_order_relaxed);
```

For complex updates, use `AudioProcessorValueTreeState` (APVTS) which handles thread-safe parameter management, undo support, XML serialization, and automatic UI binding.

---

## Part 3: Audio DSP Fundamentals

### Reverb: FDN (Feedback Delay Network)

FDN is mathematically elegant and CPU-efficient. Key design decisions:

**Delay Line Lengths** - Use co-prime or prime-adjacent values to avoid resonances:
```cpp
static constexpr int DELAYS[] = {
    (int)(0.0373 * SR), (int)(0.0411 * SR), (int)(0.0437 * SR), (int)(0.0557 * SR),
    (int)(0.0667 * SR), (int)(0.0829 * SR), (int)(0.1087 * SR), (int)(0.1237 * SR)
};
```

**Feedback Matrix** - Must be unitary (orthogonal) to preserve energy:
- **Hadamard**: O(N log N), minimal multiplications, crisp character
- **Householder**: O(N), maximum diffusion, smoother tails
- **Velvet**: Sparse matrices for ultra-dense reverb with less CPU

**RT60 Decay Control**: `gain = 10^(-3 * delayTime / rt60)`

**Damping** - One-pole lowpass on each feedback path models room absorption:
```cpp
filtered = (1.0f - damp) * input + damp * filtered;
```

### Convolution Reverb: Non-Uniform Partitioned Algorithm

For maximum realism using impulse responses. JUCE's `dsp::Convolution` uses non-uniform partitioned convolution internally:

```cpp
dsp::Convolution convolver;
convolver.loadImpulseResponse(irBuffer, spec.sampleRate,
    dsp::Convolution::Stereo::yes, dsp::Convolution::Trim::yes,
    dsp::Convolution::Normalise::yes);
```

**Key implementation references**: Barcelona Reverbera (JUCE 8 VST3), FFTConvolver (C++ library), RTConvolve (zero-latency).

**Partition Size**: Use requiredHeadSize of 256+ samples for IRs > 4096 samples.

### Fractional Delay Interpolation

For sub-sample delay precision (critical in reverb and chorus):

| Method | Quality | CPU | Best For |
|--------|---------|-----|----------|
| **Linear** | Good | Minimal | General use, low bandwidth |
| **Lagrange (3rd order)** | Very Good | Low | Reverb delay lines |
| **Thiran Allpass** | Excellent | Medium | Feedback loops (no gain error) |
| **Sinc (windowed)** | Best | High | Pitch shifting, resampling |

**Thiran** is preferred inside feedback loops because it has zero gain error (allpass characteristic), though it's less robust under time-varying conditions than Lagrange.

### Compression & Dynamics

**Program-Dependent Compression (LA-2A Style):**

The LA-2A uses an electroluminescent panel + cadmium-sulfide photoresistor (T4 cell) for gain reduction - entirely program-dependent. Average attack: ~10ms, release: 60ms for 50% / 0.5-5s for full release depending on prior material.

```cpp
class ProgramDependentCompressor {
    float threshold, ratio, makeupGain;
    float attackCoeff, releaseCoeff;
    float gainReduction = 1.0f;
    float programHistory = 0.0f;  // Tracks recent signal energy

    float processSample(float input) {
        float inputDb = 20.0f * std::log10(std::abs(input) + 1e-10f);
        float excessDb = std::max(0.0f, inputDb - threshold);
        float targetGainDb = -excessDb * (1.0f - 1.0f / ratio);

        // Program-dependent release: faster after sustained compression
        float adaptiveRelease = releaseCoeff * (1.0f + programHistory * 2.0f);
        programHistory = programHistory * 0.999f + std::abs(targetGainDb) * 0.001f;

        float alpha = (targetGainDb < gainReductionDb) ? attackCoeff : adaptiveRelease;
        gainReductionDb = gainReductionDb * (1.0f - alpha) + targetGainDb * alpha;

        float linearGain = std::pow(10.0f, (gainReductionDb + makeupGain) / 20.0f);
        return input * linearGain;
    }
};
```

### Filter Design: ZDF State-Variable Filter

Based on Zavalishin's "The Art of VA Filter Design" - the standard reference for virtual analog filter implementation.

**Key insight**: The TPT (Topology-Preserving Transform) version resolves the zero-delay feedback loop analytically, eliminating unit-delay artifacts that plague naive digital implementations.

```cpp
class ZDFStateVariableFilter {
    float g, R2, h;  // Precomputed coefficients
    float s1 = 0, s2 = 0;  // State variables

    void setParameters(float cutoffHz, float Q, float sampleRate) {
        g = std::tan(M_PI * cutoffHz / sampleRate);
        R2 = 1.0f / Q;
        h = 1.0f / (1.0f + R2 * g + g * g);
    }

    void processSample(float x, float& lp, float& bp, float& hp) {
        hp = (x - (R2 + g) * s1 - s2) * h;
        bp = g * hp + s1;
        lp = g * bp + s2;
        s1 = g * hp + bp;   // Update state
        s2 = g * bp + lp;   // Update state
    }
};
```

### Anti-Aliasing: ADAA (Antiderivative Anti-Aliasing)

Introduced by Parker, Zavalishin & Le Bivic (2016). Reduces aliasing from nonlinear processing without oversampling:

```cpp
class ADAATanh {
    float prevX = 0;
    float integral_tanh(float x) { return std::log(std::cosh(x)); }

    float process(float x) {
        if (std::abs(x - prevX) > 1e-6f) {
            float result = (integral_tanh(x) - integral_tanh(prevX)) / (x - prevX);
            prevX = x;
            return result;
        }
        prevX = x;
        return std::tanh(x);  // Fallback for near-identical inputs
    }
};
```

**2nd-order ADAA** uses the second antiderivative for even better suppression (~40dB vs ~20dB for 1st order). Open-source implementations available in chowdsp_utils and the FAUST aanl.lib.

---

## Part 4: Real-Time Threading

### Wait-Free Programming

The gold standard for audio thread communication (from Jatin Chowdhury's research):

- **Wait-free**: Every operation completes in bounded steps. Best guarantee.
- **Lock-free**: At least one thread makes progress. Good for queues.
- **Lock-based**: Can deadlock. Never use on audio thread.

**SPSC (Single-Producer Single-Consumer) Queue** - The most common pattern:
```cpp
// UI thread enqueues parameter changes
paramQueue.enqueue({PARAM_CUTOFF, newCutoffValue});

// Audio thread dequeues without blocking
ParameterChange change;
while (paramQueue.dequeue(change)) {
    applyParameterChange(change);
}
```

**Libraries**: `crill` (header-only real-time utilities), `cameron314/concurrentqueue`, `boost::lockfree::queue`

### Memory Ordering for Audio

- `memory_order_relaxed`: Use for independent parameter reads (fastest)
- `memory_order_acquire/release`: Use for flag synchronization (handshake)
- `memory_order_seq_cst`: Use when unsure (safe but slower)

---

## Part 5: Parameter Automation with APVTS

### SmoothedValue for Artifact-Free Changes

```cpp
SmoothedValue<float, ValueSmoothingTypes::Linear> smoothedCutoff;

void prepareToPlay(double sr, int blockSize) override {
    smoothedCutoff.reset(sr, 0.02);  // 20ms ramp time
}

void processBlock(AudioBuffer<float>& buffer, MidiBuffer& midi) override {
    smoothedCutoff.setTargetValue(apvts.getRawParameterValue("cutoff")->load());

    for (int i = 0; i < buffer.getNumSamples(); ++i) {
        float cutoff = smoothedCutoff.getNextValue();
        // Process with smoothed cutoff - no zipper noise
    }
}
```

APVTS provides: undo support, XML serialization, automatic UI binding, and thread-safe ValueTree updates on the message thread.

---

## Part 6: Performance Optimization

### SIMD Vectorization

Data must be aligned for optimal SIMD performance (32-byte for AVX):

```cpp
// Aligned allocation for SIMD
alignas(32) float buffer[1024];

// SSE: 4 floats at once
__m128 gainVec = _mm_set1_ps(gain);
for (int i = 0; i < N; i += 4) {
    __m128 s = _mm_load_ps(&buffer[i]);  // Aligned load (faster)
    _mm_store_ps(&buffer[i], _mm_mul_ps(s, gainVec));
}
```

**Cross-platform**: Use `xsimd` library for portable SIMD across SSE, AVX, AVX512, NEON, and WebAssembly.

### Fast Math Approximations

| Function | std:: | Padé | Speedup |
|----------|-------|------|---------|
| log10 | 100 cycles | 10 cycles | **10×** |
| pow(10,x) | 150 cycles | 15 cycles | **10×** |
| sin | 40 cycles | 5 cycles | **8×** |
| tanh | 30 cycles | 8 cycles | **4×** |

JUCE provides `dsp::FastMathApproximations` with Padé-based `sinh`, `cosh`, `tanh`, `sin`, `cos` (valid for limited input ranges).

Chowdhury-DSP's `math_approx` library provides additional optimized functions with SIMD support.

### Denormal Prevention

Denormalized floats (< 1.17e-38) can be 23× slower to process. Three approaches:

1. **FTZ/DAZ mode** (best): `_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON);`
2. **Manual clamping**: `if (std::abs(x) < 1e-10f) x = 0.0f;`
3. **DC offset**: Add tiny constant that decays away

---

## Part 7: UI Design

### JUCE 8 Graphics Acceleration

JUCE 8 introduced **Direct2D rendering on Windows** for hardware-accelerated 2D graphics, and uses **CoreGraphicsMetalLayerRenderer on macOS** (CPU rendering uploaded as Metal texture to GPU).

**Component paint hierarchy**: parent `paint()` → children in add order → `paintOverChildren()`. Use `setBufferedToImage(true)` to cache expensive paints.

**Melatonin Inspector**: Inspect and visually edit JUCE components like Figma/browser DevTools. Essential for UI debugging.

### OpenGL for Real-Time Visualization

For spectrum analyzers and waveform displays, OpenGL avoids the CPU bottleneck of JUCE's default Graphics engine:

```cpp
class SpectrumDisplay : public OpenGLRenderer, public Component {
    OpenGLContext glContext;

    void initialise() override { /* Setup shaders, buffers */ }
    void renderOpenGL() override {
        // GPU-accelerated rendering at screen refresh rate
        // Draw spectrum bars, waveforms, etc.
    }
    void shutdown() override { /* Cleanup */ }
};
```

**Reference implementations**: OpenGLRealtimeVisualization4JUCE module, glslEditor_AudioPlugin (GLSL in JUCE).

---

## Part 8: Neural Network Inference (Advanced)

### RTNeural: Real-Time Neural Networks

RTNeural (by Jatin Chowdhury, Stanford CCRMA) enables real-time audio-rate neural network inference. Used in production plugins like AIDA-X, BYOD, Chow Centaur, and Chow Tape Model.

**Key features:**
- Backends: Eigen, xsimd, or STL (no external deps required)
- Model import from TensorFlow/PyTorch via JSON export
- Zero allocation after construction (real-time safe)
- Supports Dense, LSTM, GRU, Conv1D layers

```cpp
#include <RTNeural/RTNeural.h>

RTNeural::ModelT<float, 1, 1,
    RTNeural::DenseT<float, 1, 8>,
    RTNeural::TanhActivationT<float, 8>,
    RTNeural::DenseT<float, 8, 1>
> model;

// In processBlock (real-time safe after loading):
float output = model.forward(&input);
```

**Also see**: Neutone SDK (open-source neural audio framework), anira (architecture for NN inference in real-time audio).

---

## Part 9: Best Practices

### Open-Source Reference Plugins

Study these production-quality open-source plugins:
- **Surge XT** - Hybrid synthesizer, JUCE, 12 oscillator types, massive modulation
- **Vital** - Spectral warping wavetable synth, custom OpenGL UI
- **Valentine** (Tote Bag Labs) - Compressor plugin, clean JUCE architecture
- **NTHN Template Plugin** - Minimal real-time safe JUCE starting point

### Testing & Validation

- **Pluginval**: Automated plugin validation (catches common crashes)
- **Audio assertions**: Check for NaN, infinity, excessive clipping in processBlock
- **Catch2**: Unit test DSP algorithms offline
- **DDMF PluginDoctor**: Analyze frequency response, distortion, latency

### Plugin Development Checklist

- [ ] CMake configured, all formats compiling
- [ ] Core DSP tested offline with audio assertions
- [ ] Zero allocations/locks in processBlock()
- [ ] APVTS with sample-accurate automation and SmoothedValue
- [ ] Profiled, SIMD optimized, <5% CPU for 16 instances
- [ ] FTZ/DAZ enabled for denormal prevention
- [ ] Custom UI with proper component hierarchy
- [ ] Preset save/load with state versioning (pluginVersion integer in state XML)
- [ ] Parameter IDs stable — strings never renamed, layout never reordered after release
- [ ] Plugin UID (PLUGIN_MANUFACTURER_CODE + PLUGIN_CODE) set permanently in CMake
- [ ] Cross-platform tested (macOS, Windows, Linux)
- [ ] CI/CD pipeline with Pluginval validation
- [ ] auval passes (AU builds)
- [ ] Oversampling added around any nonlinear DSP section

---

## References & Resources

- [Zavalishin - The Art of VA Filter Design](https://www.native-instruments.com/fileadmin/ni_media/downloads/pdf/VAFilterDesign_2.1.0.pdf)
- [CCRMA - Physical Audio Signal Processing](https://ccrma.stanford.edu/~jos/pasp/)
- [Signalsmith Audio - Let's Write a Reverb](https://signalsmith-audio.co.uk/writing/2021/lets-write-a-reverb/)
- [Chowdhury - Practical ADAA](https://jatinchowdhury18.medium.com/practical-considerations-for-antiderivative-anti-aliasing-d5847167f510)
- [Chowdhury - Wait-Free Programming](https://jatinchowdhury18.medium.com/wait-free-programming-from-scratch-5ac6a65c23c4)
- [Timur Audio - Using Locks Safely](https://timur.audio/using-locks-in-real-time-audio-processing-safely)
- [Melatonin - How JUCE Components Work](https://melatonin.dev/blog/how-juce-components-work/)
- [Melatonin - How to Use CMake with JUCE](https://melatonin.dev/blog/how-to-use-cmake-with-juce/)
- [RTNeural - Real-Time Neural Inferencing](https://github.com/jatinchowdhury18/RTNeural)
- [WolfSound - SIMD in DSP](https://thewolfsound.com/simd-in-dsp/)
- [Awesome JUCE](https://github.com/sudara/awesome-juce)
- [Awesome MusicDSP](https://github.com/olilarkin/awesome-musicdsp)
- [CLAP JUCE Extensions](https://github.com/free-audio/clap-juce-extensions)
- [Steinberg VST3 Parameters & Automation](https://steinbergmedia.github.io/vst3_dev_portal/pages/Technical+Documentation/Parameters+Automation/Index.html)
- [Ross Bencina - Real-time Audio Programming 101](http://www.rossbencina.com/code/real-time-audio-programming-101-time-waits-for-nothing)
- [Melatonin - Code Signing & Notarization](https://melatonin.dev/blog/how-to-code-sign-and-notarize-macos-audio-plugins-in-ci/)
- [DAFx Paper Archive (all open access)](https://www.dafx.de/paper-archive/)
