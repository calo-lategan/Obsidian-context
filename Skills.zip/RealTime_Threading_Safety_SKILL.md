---
name: realtime-threading-safety
description: |
  Comprehensive guide to safe multi-threaded audio programming covering lock-free and wait-free data structures, atomic operations with memory ordering, thread priorities, real-time safety patterns, DAW communication protocols, and debugging techniques. Essential for building reliable audio plugins that handle parameter automation, UI updates, and background tasks without audio glitches. Trigger on: lock-free, atomic, thread safety, audio dropout, real-time constraints, mutex, race condition, inter-thread communication, memory ordering, wait-free, SPSC queue, DAW automation, plugin state, crill library.
---

## Thread Model in DAWs

**Audio Thread** (real-time, 1-5ms deadline): processBlock() runs here. 48kHz/256 samples = 5.3ms budget.
**UI Thread** (normal priority): Slider dragging, mouse events. Can block 10-100ms safely.
**Background Thread** (low priority): File I/O, heavy computation, preset loading.

**Critical Rule**: Audio thread can NEVER block. Any operation that might wait is forbidden.

---

## Wait-Free vs Lock-Free

**Wait-free**: Every operation completes in bounded steps. Best guarantee for audio.
**Lock-free**: At least one thread always makes progress. Good for queues.
**Lock-based**: Can deadlock/priority-invert. Never use on audio thread.

From Jatin Chowdhury's research: atomic machine instructions allow operations on shared data without locking. For SPSC queues, this achieves wait-free guarantee.

---

## Atomic Operations & Memory Ordering

### Decision Tree
- **Independent parameter value?** → `memory_order_relaxed` (fastest)
- **Flag synchronization?** → `acquire`/`release` pair
- **Complex shared data?** → Lock-free queue instead
- **Unsure?** → `seq_cst` (safe, slower)

```cpp
// Simple parameter: relaxed is fine
std::atomic<float> cutoff{1000.0f};
float c = cutoff.load(std::memory_order_relaxed);

// Flag handshake: acquire/release
std::atomic<bool> resetFlag{false};
resetFlag.store(true, std::memory_order_release);   // Writer
if (resetFlag.load(std::memory_order_acquire)) {}   // Reader
```

---

## Lock-Free Queue Patterns

### SPSC Queue (UI → Audio)
Most common pattern. Libraries: `cameron314/concurrentqueue`, `boost::lockfree::queue`, `crill` (header-only real-time utilities), `atomic_queue` (benchmarked C++14 queue).

```cpp
LockFreeQueue<ParameterChange> paramQueue;

// UI thread (producer)
paramQueue.enqueue({PARAM_CUTOFF, newValue});

// Audio thread (consumer) - never blocks
ParameterChange change;
while (paramQueue.dequeue(change)) {
    applyParameterChange(change);
}
```

### Audio → UI Notifications
Fire-and-forget: OK to drop messages if queue full (UI just shows slightly stale data).

```cpp
// Audio thread: compute and enqueue
levelQueue.enqueue({rmsLevel, peakLevel});

// UI thread: poll via Timer
void timerCallback() override {
    LevelNotification n;
    while (levelQueue.dequeue(n)) updateMeter(n);
}
```

### Double Buffering (Complex Objects)
For filter coefficients or other multi-field updates:

```cpp
std::array<FilterState, 2> states;
std::atomic<int> activeIndex{0};

// UI: prepare new state, then flip
states[1 - activeIndex.load()] = computeNewState(params);
activeIndex.store(1 - activeIndex.load(), std::memory_order_release);

// Audio: always reads active buffer
auto& state = states[activeIndex.load(std::memory_order_acquire)];
```

---

## DAW-Specific Considerations

**Buffer Size Changes**: FL Studio and some DAWs change buffer sizes mid-session. Always pre-allocate for maximum expected buffer size in prepareToPlay() and handle variable block sizes gracefully.

**Transport Stop**: When DAW stops, audio thread may stop being called. Lock-free queues can fill up. Handle by either freezing UI or implementing queue overflow detection.

**Keyboard Focus**: VST3 plugins in FL Studio may not pass spacebar/keyboard events to the DAW. Handle keyboard focus carefully in your editor.

---

## Denormal Prevention

Denormalized floats cause 23× performance degradation. Three approaches:

1. **FTZ/DAZ** (best): Set MXCSR register flags at start of processBlock()
```cpp
_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON);
_MM_SET_DENORMALS_ZERO_MODE(_MM_DENORMALS_ZERO_ON);
```

2. **Manual clamping**: `if (std::abs(x) < 1e-10f) x = 0.0f;`
3. **DC offset**: `state = (state + 1e-20f) * feedback - 1e-20f;`

Recursive algorithms (IIR filters, reverb) are especially vulnerable when DAW sends zeros during transport stop.

---

## Debugging Real-Time Issues

### Timing Guard
```cpp
class TimingGuard {
    float budgetMs;
    std::chrono::high_resolution_clock::time_point start;
public:
    TimingGuard(float sr, int blockSize) : budgetMs(blockSize / sr * 1000.0f),
        start(std::chrono::high_resolution_clock::now()) {}
    ~TimingGuard() {
        float elapsed = /* compute ms */;
        if (elapsed > budgetMs * 0.8f) Logger::writeToLog("WARNING: " + String(elapsed) + "ms");
    }
};
```

### Tools
- **Sleepy** (Windows): Sampling profiler for audio threads
- **Instruments** (macOS): Time Profiler for CPU analysis
- **JUCE PerformanceCounter**: Built-in timing measurement

---

## Critical Anti-Patterns (What NEVER to Do in processBlock)

Based on Ross Bencina, Timur Doumler, and Four Common Mistakes in Audio Development:

| Anti-Pattern | Why It's Dangerous | Correct Alternative |
|---|---|---|
| `new` / `malloc` | Heap allocation has unbounded timing | Pre-allocate in prepareToPlay() |
| `std::mutex::lock()` | Priority inversion, unbounded wait | std::atomic or SPSC queue |
| `std::mutex::try_lock()` | Still interacts with OS scheduler | std::atomic with relaxed ordering |
| `std::shared_ptr` copy | Atomic refcount not lock-free on all platforms | Raw pointer + lifetime management |
| `std::function` call | May allocate on assignment | Function pointer or template |
| `std::string` operations | Allocates on heap | Pre-allocated char buffers |
| `printf` / `NSLog` / `Logger` | I/O system call, blocks | Defer to message thread via FIFO |
| `throw` exception | Stack unwinding = unbounded time | Return error codes |
| Virtual calls in tight loops | Branch prediction misses | CRTP or direct calls |
| `std::vector::push_back` | May reallocate | Pre-sized containers |

### FL Studio Extended Compatibility

**Variable Buffer Sizes**: FL Studio sends different buffer sizes between callbacks by default. Your DSP must handle ANY buffer size from 1 to maxBlockSize. Never cache buffer size from one callback to the next.

```cpp
void processBlock(AudioBuffer<float>& buffer, MidiBuffer&) {
    const int numSamples = buffer.getNumSamples(); // May vary each call!
    // WRONG: if (numSamples != lastBlockSize) return;
    // RIGHT: Process whatever numSamples we receive
    for (int i = 0; i < numSamples; ++i) { /* ... */ }
}
```

**Keyboard Focus Workaround**:
```cpp
if (juce::PluginHostType().isFruityLoops()) {
    // Don't grab keyboard focus aggressively
    setWantsKeyboardFocus(false);
}
```

---

## References
- Ross Bencina (2011) "Real-time audio programming 101: time waits for nothing" - rossbencina.com
- Timur Doumler (2015) "C++ in the Audio Industry" - CppCon
- Timur Doumler (2024) "Wait-free thread synchronisation with the SeqLock" - ADC
- Timur Doumler "Using locks in real-time audio processing, safely" - timur.audio
- "Four common mistakes in audio development" - atastypixel.com
- [Timur Audio - Using Locks Safely](https://timur.audio/using-locks-in-real-time-audio-processing-safely)
- [Chowdhury - Wait-Free Programming](https://jatinchowdhury18.medium.com/wait-free-programming-from-scratch-5ac6a65c23c4)
- [Ross Bencina - Real-Time Audio Programming 101](http://www.rossbencina.com/code/real-time-audio-programming-101-time-waits-for-nothing)
- [crill Library](https://github.com/crill-dev/crill)
- [cameron314/concurrentqueue](https://github.com/cameron314/concurrentqueue)
- [ADC 2025 - Lock-Free Queues](https://conference.audio.dev/session/2025/lock-free-queues-in-the-multiverse-of-madness)
