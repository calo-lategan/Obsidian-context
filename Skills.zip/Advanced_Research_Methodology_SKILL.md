---
name: advanced-research-methodology
description: |
  Meta-skill for finding the highest quality sources when building audio DSP skills.
  Covers: AES e-library, DAFx proceedings (open access), arXiv eess.AS, IEEE Xplore,
  ACM Digital Library, Google Scholar, Google Patents, USPTO, EPO, WIPO, Semantic Scholar,
  multi-language research (German, Finnish, French, Japanese), evaluating source quality,
  finding the best researchers in audio DSP, reverb, acoustics, neural audio, and plugin
  development. Use when creating or updating skills to find PhD-level sources, patents,
  research papers, and scholarship articles.
  Trigger on: research, sources, papers, PhD, academic, patent, scholarship, AES, DAFx,
  arXiv, IEEE, literature review, bibliography, references, best researchers, multi-language.
---

# Advanced Research Methodology SKILL

This skill exists to ensure every other skill is filled with the highest-quality, PhD-level
information from the world's best researchers in audio DSP, plugin development, acoustics,
and related fields. Always use these sources before writing any technical skill content.

---

## 1. Primary Academic Sources for Audio DSP

### AES E-Library (Gold Standard for Audio Research)
URL: https://aes2.org/publications/elibrary/
- Over 20,000 fully searchable PDFs from 1953 to present
- Covers: room acoustics, digital audio effects, psychoacoustics, plugin formats, mastering
- Search tips: use author names + year, or topic keywords
- Many papers require AES membership or per-paper purchase (~$5 each)
- Key journals: JAES (Journal of the Audio Engineering Society)

### DAFx Conference Proceedings (Free Open Access)
URL: https://www.dafx.de/paper-archive/
- Annual conference: Digital Audio Effects (since 1998)
- All papers freely downloadable as PDFs
- Best source for: reverb algorithms, FDN, convolution, spectral processing, synthesis
- Key papers (search by title): Schlecht FDN, Valimaki velvet noise, Rocchesso, Zolzer
- Also at: http://dafx.de and individual conference sites

### arXiv: Audio and Speech Processing
URL: https://arxiv.org/list/eess.AS/recent
- Preprint server — free, immediate access to submitted papers
- Category: eess.AS (Electrical Engineering, Audio and Speech Processing)
- Related categories: cs.SD (Sound), cs.LG (Machine Learning), eess.SP (Signal Processing)
- Search: https://arxiv.org/search/?searchtype=all&query=reverb+FDN
- Advantage: months ahead of conference publication, includes all major groups
- Recent highlights: differentiable reverb, neural audio effects, room acoustics ML

### IEEE Xplore
URL: https://ieeexplore.ieee.org/
- IEEE TASLP (Transactions on Audio, Speech, and Language Processing) — highest impact factor
- IEEE Signal Processing Letters
- ICASSP proceedings (annual conference, ~5000 papers)
- Many papers open access after embargo; preprints often on arXiv
- Search: Advanced Search -> select journal/conference -> add keyword

### ACM Digital Library
URL: https://dl.acm.org/
- NIME (New Interfaces for Musical Expression) proceedings
- CHI papers on audio UI/UX
- SMC (Sound and Music Computing) papers
- Many open access through ACM OpenTOC

### Semantic Scholar (AI-powered, Free)
URL: https://www.semanticscholar.org/
- Finds related papers, citation networks, and open PDFs automatically
- Better than Google Scholar for audio DSP citation mapping
- Use: search for a key paper, then explore "Highly Influential Citations" and "References"
- Recommended for: finding ALL papers that build on a foundational work

### Google Scholar
URL: https://scholar.google.com/
- Best for: finding citing papers, finding all versions of a paper
- Trick: "Cited by" link shows all subsequent work building on a paper
- PDF links appear on right — often free author versions on personal/university pages
- Search operators: author:schlecht, title:reverb, year range filters

---

## 2. Patent Databases

### Google Patents (Best Starting Point)
URL: https://patents.google.com/
- Covers USPTO (US), EPO (Europe), WIPO (PCT/international), and 100+ offices
- Full text searchable; includes drawings
- Audio DSP patent examples:
  - US9805704B1 — Modal synthesis reverb (Faust/GRAME)
  - US11049482B1 — Modal reverb (extension)
  - US5029221 — Lexicon plate reverb algorithm
  - Search: "reverb" classification:G10L OR G10H
- Patent families: find equivalent patents in all countries from one search
- Expired patents: prior art, free to implement without license

### USPTO Patent Full-Text Database
URL: https://ppubs.uspto.gov/pubwebapp/
- US patents only; more structured search than Google Patents
- Classification system: CPC G10H (musical instruments/synthesis), G10L (speech/audio)
- Use for definitive US grant text

### EPO Espacenet
URL: https://worldwide.espacenet.com/
- European Patent Office; covers EP, WO (PCT), and many national offices
- IPC classification: G10H (musical instruments), H04S (stereo), H04R (acoustics)
- Esp@cenet advanced search: find by inventor name (e.g., Griesinger, Lexicon patents)

---

## 3. Top Researchers in Audio DSP — Who to Follow

### Reverb and Room Acoustics
- **Sebastian Schlecht** (Aalto University, Finland) — FDN, allpass FDN, velvet noise, scattering
  - PhD thesis: "Allpass Feedback Delay Networks" (available free)
  - Google Scholar: search "Sebastian Schlecht audio"
- **Vesa Valimaki** (Aalto University) — velvet noise, physical modeling, synthesis
  - 50+ years reverb review paper (free PDF)
- **Julius O. Smith III** (Stanford CCRMA) — digital waveguides, physical modeling, JOS books
  - All books FREE online: https://ccrma.stanford.edu/~jos/
- **Jean-Marc Jot** (DTS/Qualcomm, ex-IRCAM) — FDN theory, spatial audio, frequency-dependent decay
  - PhD thesis: "Etude et realisation d'un spatialiseur de sons par modeles physiques" (French)
- **David Griesinger** (Lexicon, Harvard) — psychoacoustics of reverb, spaciousness, IACC
  - Papers: lexiconpro.com/techpages, AES papers
- **William Gardner** (MIT) — partitioned convolution, early reflections
  - PhD thesis: "The Virtual Acoustic Room" (MIT, 1992) — free online
- **Angelo Farina** (University of Parma) — IR measurement, ESS method, binaural
  - AES papers; free on his academic page
- **Jon Dattorro** (CCRMA Stanford) — "Effect Design" series, plate reverb, allpass loops
  - CCRMA Tech Reports (free): complete reverb circuit schematics

### DSP Algorithms and Optimization
- **Jatin Chowdhury** (Apple, ex-Stanford) — WDF, neural audio, chowdsp libraries
  - GitHub: github.com/jatinchowdhury18; PhD thesis at Stanford (2024)
- **Timur Doumler** — real-time audio programming, C++ for audio
  - CppCon talks on YouTube, ADC conference
- **Ross Bencina** — real-time audio programming 101, PortAudio
  - Essay: "Real-time audio programming 101" (free, search title)

### Neural Audio
- **Antoine Caillon** (IRCAM) — RAVE model, generative audio
  - arXiv: search "RAVE neural audio"
- **Jesse Engel** (Google Magenta) — DDSP (Differentiable Digital Signal Processing)
  - ICLR 2020 paper, open source at github.com/magenta/ddsp

### Spatial Audio
- **Jens Ahrens** (Chalmers, Sweden) — Ambisonics, HRTF, Near-Field Acoustics
  - Book "Analytic Methods of Sound Field Synthesis" (open access PDF)
- **Ville Pulkki** (Aalto) — VBAP panning, DirAC, HRTF
  - Papers free on Aalto academic pages

---

## 4. Multi-Language Research Strategy

Audio DSP research is published in multiple languages. Missing non-English sources = missing
some of the best work.

### German Sources
- **Udo Zolzer** (Helmut Schmidt University, Hamburg) — DAFX textbook, filter design
  - "DAFX: Digital Audio Effects" (2nd ed., Wiley 2011) — most comprehensive reference
  - Also: "Introduction to Digital Audio Coding and Standards"
- German universities: TU Berlin (audio comms), LMU Munich, TU Ilmenau
- Search in German: "Hallalgorithmus" (reverb algorithm), "Raumakustik" (room acoustics)
- German standards: DIN 45630 (room acoustics measurements)

### Finnish Sources
- Aalto University (Helsinki/Espoo) — top global ranking in audio DSP
  - Researchers: Valimaki, Karjalainen, Paulus, Schlecht
  - Aalto research repository: aaltodoc.aalto.fi (free access to theses)
  - Signal Processing and Acoustics department

### French Sources
- IRCAM (Institut de Recherche et Coordination Acoustique/Musique), Paris
  - World-leading audio research institute; many papers in French and English
  - IRCAM Forum: ircam.fr (paid membership for software, free publications)
  - Key researchers: Xavier Rodet, Jean-Claude Risset, Jean-Marie Adrien
- INRIA (French national computer science institute)
  - Free research reports on signal processing
- Search: "reverb algorithmique", "synthese par modeles physiques"

### Japanese Sources
- Waseda University, Tokyo University, NTT Communication Science Labs
- NTT Technical Journal (some articles in English)
- ASJ (Acoustical Society of Japan) — acoustics.jp
- Key researchers: Yoichi Ando (concert hall acoustics), Yuki Mitsufuji (Sony, neural audio)
- Search: "残響" (zankyou = reverb), "残響付加" (reverb addition), "音響" (acoustics)

### Italian Sources
- Davide Rocchesso (University of Venice) — physical modeling, FDN, auditory models
  - "Reverberation" textbook (free PDF at multiple locations)
  - SMC papers
- Lorenzo Picinali (Imperial College London, orig. Italy) — spatial audio
- Search: "riverbero artificiale", "modelli fisici audio"

---

## 5. Evaluating Source Quality

### Hierarchy (highest to lowest reliability)
1. Peer-reviewed journal articles (JAES, IEEE TASLP, JASA) — gold standard
2. Peer-reviewed conference papers (AES, DAFx, ICASSP, NIME) — very high
3. PhD theses from top universities — high (full detailed methodology)
4. Preprints on arXiv from known researchers — good (not yet peer-reviewed)
5. Technical reports from research institutions (CCRMA, IRCAM) — good
6. Patents with detailed claims — medium (may be strategic not optimal)
7. Open-source code from domain experts (ChowDSP, JUCE) — practical gold
8. Blog posts from domain experts (Valhalla DSP blog, Signalsmith) — good practical
9. Forum discussions (JUCE forum, KVR DSP) — useful but verify

### Red Flags
- No citations or references
- Author has no verifiable credentials
- Extraordinary claims without supporting mathematics
- Implementation that "sounds good" without theoretical basis

### Checking Citations
- Google Scholar "Cited by N" — more citations = more vetted by community
- For reverb: Dattorro 1997 has 1000+ citations; Schroeder 1962 has 3000+
- For neural audio: recent 2022-2025 papers may have fewer citations but are cutting edge

---

## 6. Patent Search Workflow for Audio Features

When implementing a feature, always check for active patents:

1. Search Google Patents: `reverb shimmer pitch shift` → filter by Status=Active
2. Check assignee: major companies (Lexicon, TC Electronic, Sony, Apple)
3. Read claims carefully — only claims matter legally, not description
4. Check filing date + grant date + expected expiry (20 years from filing, usually)
5. Prior art search: search for similar inventions before patent filing date
6. Implementation guidance: read the patent's detailed description — often the best
   technical explanation of the algorithm exists

**Safe harbor**: Expired patents and patents from before ~2004 for common DSP techniques
are generally safe to implement without license.

---

## 7. Finding Best Researchers by Topic

### How to Find the Top Researchers in Any Audio Subtopic

1. Start with a known key paper (e.g., Schlecht "FDN Allpass" 2020)
2. On Semantic Scholar: "Highly Influential Authors" in that paper's field
3. On Google Scholar: search topic, sort by citations, look at first 10 authors
4. Check which university/lab produces most work in that area
5. Search that lab's publication list for comprehensive coverage
6. Check PhD advisors — their students often continue the work

### Key Institutions (Global)
- **Stanford CCRMA** — JOS, Bilbao, reverb, synthesis
- **Aalto University (Finland)** — Valimaki, Schlecht, velvet noise, physical models
- **IRCAM (France)** — Caillon, RAVE, synthesis, composition
- **McGill CIRMMT (Canada)** — Traer, room acoustics, perceptual
- **University of Surrey (UK)** — spatial audio, binaural, Ambisonics
- **TU Berlin (Germany)** — Ahrens, Zotter, Ambisonics, sound field synthesis
- **Chalmers (Sweden)** — Ahrens, HRTF, near-field
- **NYU Music Technology** — Bello, Salamon, MIR, spectral
- **MIT Media Lab** — various: synthesis, HCI for audio

---

## 8. Recommended Reading Order for New Audio DSP Skills

### Foundation Layer (Read First)
- Julius O. Smith III, Physical Audio Signal Processing (free): https://ccrma.stanford.edu/~jos/pasp/
- Julius O. Smith III, Introduction to Digital Filters (free): https://ccrma.stanford.edu/~jos/filters/
- Udo Zolzer, DAFX Digital Audio Effects (2nd Ed.) — full textbook
- Rocchesso, "Reverberation" (free PDF) — comprehensive reverb theory

### Reverb-Specific (Second Layer)
- Schroeder (1962) "Natural Sounding Artificial Reverberation" — foundational
- Moorer (1979) "About This Reverberation Business" — first improvements
- Jot & Chaigne (1991) "Digital Delay Networks" — FDN theory
- Dattorro (1997) "Effect Design Part 1" — plate reverb, complete circuits
- Gardner (1995) "Efficient Convolution Without Input-Output Delay"
- Schlecht (2020) "Allpass Feedback Delay Networks" — modern FDN
- Valimaki et al. (2012) "More Than 50 Years of Artificial Reverberation"

### Neural Audio (Third Layer)
- Engel et al. (2020) "DDSP: Differentiable Digital Signal Processing" (arXiv:2001.04643)
- Caillon & Esling (2021) "RAVE: A variational autoencoder" (arXiv:2111.05011)
- Parker et al. (2022) "Efficient neural networks for real-time modeling" (DAFx)

---

## 9. Building a Research Database

When creating or updating a skill file, follow this workflow:

1. **Identify the topic** — write 5 key questions the skill must answer
2. **Find the canonical paper** — use Google Scholar sort by citations
3. **Map the citation network** — Semantic Scholar "highly cited by" and "references"
4. **Search multiple databases** — AES, DAFx, arXiv, IEEE Xplore, Google Patents
5. **Read PhD theses** — they contain the most complete literature reviews
6. **Check for patents** — Google Patents search for active claims
7. **Find code implementations** — GitHub search, open source reference plugins
8. **Multi-language sweep** — German (Zolzer), Finnish (Aalto), French (IRCAM), Japanese
9. **Expert blogs** — Valhalla DSP blog, Signalsmith, musicdsp.org
10. **Synthesize** — extract concrete equations, code patterns, best practices

---

## 10. Free Resources Quick Reference

| Resource | URL | Best For |
|---|---|---|
| DAFx Archive | dafx.de/paper-archive | Digital audio effects papers |
| arXiv eess.AS | arxiv.org/list/eess.AS/recent | New audio research preprints |
| JOS Books | ccrma.stanford.edu/~jos | Physical modeling, filters |
| Rocchesso | (search "Rocchesso reverberation PDF") | Reverb theory |
| Aalto theses | aaltodoc.aalto.fi | Finnish audio DSP PhDs |
| Musicdsp.org | musicdsp.org | Practical DSP algorithms |
| Google Patents | patents.google.com | US/EP/WO patents |
| AES Open Access | aes2.org/publications | Some free AES papers |
| Semantic Scholar | semanticscholar.org | Citation graph navigation |
| CCRMA Tech Reports | ccrma.stanford.edu/reports | Stanford audio research |
