---
name: dsp-algorithm-optimization
description: |
  Mastery of numerical methods and optimization for audio DSP covering fast Padé approximations (log/exp/sin/tanh), ADAA anti-aliasing for nonlinear processing, SIMD vectorization (SSE/AVX/NEON) with data alignment, filter coefficient computation and stability, denormal prevention, and precision tradeoffs. Essential for building high-performance, high-fidelity audio plugins. Trigger on: anti-aliasing, ADAA, fast approximation, Padé, SIMD, vectorization, denormal, numerical stability, CPU optimization, fast math, lookup table, waveshaping.
---

## Fast Mathematical Approximations

### Padé Approximants
Rational polynomial approximations that converge faster than Taylor series. JUCE provides `dsp::FastMathApproximations` with Padé-based sinh, cosh, tanh, sin, cos (valid for limited input ranges, typically -5 to +5 or -π to +π).

| Function | std:: cycles | Padé cycles | Speedup |
|----------|-------------|-------------|---------|
| log10 | ~100 | ~10 | **10×** |
| pow(10,x) | ~150 | ~15 | **10×** |
| sin | ~40 | ~5 | **8×** |
| tanh | ~30 | ~8 | **4×** |

**Key trick**: Reformulate `pow(10, x)` as `exp(log(10)*x)` for 3× speedup with no accuracy loss.

**Horner's method**: Evaluate polynomials efficiently - fewer multiplications, enables fused multiply-add instructions.

**chowdsp math_approx**: Open-source library with SIMD-optimized approximations for audio DSP.

---

## ADAA (Antiderivative Anti-Aliasing)

### The Problem
Nonlinear processing (saturation, distortion) generates harmonics beyond Nyquist that fold back as inharmonic aliasing artifacts.

### The Solution
Instead of evaluating f(x) directly, compute (∫f(x) - ∫f(x_prev)) / (x - x_prev). This approximates band-limited sampling of the nonlinearity.

**1st-order ADAA**: ~20dB alias reduction. Cost: 2 function evaluations per sample.
**2nd-order ADAA**: ~40dB alias reduction. Cost: 3 evaluations + more state. Uses second antiderivative.

### Common Antiderivatives
- tanh(x) → log(cosh(x))
- sigmoid(x) → x - log(1 + exp(-x))
- hard_clip(x) → x²/2 (for |x| < 1)

### Practical Considerations (from Chowdhury)
- Handle near-zero denominators (|x - x_prev| < 1e-6) by falling back to direct evaluation
- ADAA works best combined with modest oversampling (2× or 4×)
- For stateful systems (filters with feedback), ADAA requires special treatment - see "Antiderivative Antialiasing for Stateful Systems" (Parker et al.)
- Lookup table implementations of antiderivatives can be slightly faster than Padé for some functions
- Open-source: chowdsp_waveshapers, FAUST aanl.lib

---

## SIMD Vectorization

### Data Alignment
Aligned data enables faster load/store instructions:
- **SSE**: 16-byte alignment (`alignas(16)`)
- **AVX**: 32-byte alignment (`alignas(32)`)
- **AVX-512**: 64-byte alignment (`alignas(64)`)

```cpp
alignas(32) float buffer[1024];  // AVX-aligned

// Aligned load (faster than unaligned)
__m256 v = _mm256_load_ps(&buffer[0]);
```

### FIR Filter Vectorization
Inner loop vectorization processes 8 samples per iteration with AVX, giving ~8× speedup. Key: ensure coefficient array is also aligned.

**Reference**: WolfSound's detailed SIMD FIR implementation with alignment analysis.

### Cross-Platform SIMD
Use **xsimd** library for portable code across SSE, AVX, AVX512, NEON (ARM), SVE, WebAssembly, VSX (PowerPC), and RISC-V.

```cpp
#include <xsimd/xsimd.hpp>
using batch = xsimd::batch<float>;

void applyGain(float* buf, int n, float gain) {
    auto g = batch::broadcast(gain);
    for (int i = 0; i < n; i += batch::size) {
        auto s = batch::load_aligned(&buf[i]);
        (s * g).store_aligned(&buf[i]);
    }
}
```

### SoA Data Layout
Structure of Arrays is essential for SIMD efficiency:
```cpp
// Bad (AoS): [L,R,L,R,L,R,...] - can't vectorize channel operations
// Good (SoA): [L,L,L,L,...] + [R,R,R,R,...] - natural SIMD alignment
```

JUCE's AudioBuffer already uses SoA internally (separate channel pointers).

---

## Denormal Prevention

Denormalized floats (< 1.17e-38) cause **23× performance degradation** on x86 CPUs.

### Best Practice: FTZ + DAZ
```cpp
void processBlock(...) override {
    ScopedNoDenormals noDenormals;  // JUCE helper - sets FTZ+DAZ
    // ... all processing here is denormal-safe
}
```

Or manually:
```cpp
_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON);
_MM_SET_DENORMALS_ZERO_MODE(_MM_DENORMALS_ZERO_ON);
```

**When denormals appear**: Recursive algorithms (IIR filters, reverb feedback) when input goes silent. The filter state decays exponentially toward zero, entering denormal range.

---

## Numerical Stability

### Filter Coefficient Stability
Ensure biquad coefficients satisfy stability conditions:
- |a2| < 1
- |a1| < 1 + a2
Test at extreme sample rates (8kHz through 192kHz) and parameter values.

### Avoiding Catastrophic Cancellation
When subtracting nearly equal numbers, relative error explodes. Reformulate expressions to avoid this, especially in filter coefficient computation.

### Fixed vs Floating Point
32-bit float: ~7 decimal digits precision, adequate for most audio DSP.
64-bit double: ~15 digits, use for filter coefficient computation and accumulation in long convolutions.

---

## References
- [Chowdhury - Practical ADAA](https://jatinchowdhury18.medium.com/practical-considerations-for-antiderivative-anti-aliasing-d5847167f510)
- [JUCE FastMathApproximations](https://docs.juce.com/master/structdsp_1_1FastMathApproximations.html)
- [WolfSound - SIMD in DSP](https://thewolfsound.com/simd-in-dsp/)
- [WolfSound - Data Alignment for SIMD](https://thewolfsound.com/data-alignment-in-fir-filter-simd-implementation/)
- [OpenAudio - Faster Log10 and Pow](http://openaudio.blogspot.com/2017/02/faster-log10-and-pow.html)
- [chowdsp math_approx](https://github.com/Chowdhury-DSP/math_approx)
- [xsimd Library](https://github.com/xtensor-stack/xsimd)
- [Zavalishin - VA Filter Design](https://www.native-instruments.com/fileadmin/ni_media/downloads/pdf/VAFilterDesign_2.1.0.pdf)
