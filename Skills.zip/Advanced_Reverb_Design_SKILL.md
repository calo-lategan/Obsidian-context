---
name: advanced-reverb-design
description: |
  Deep dive into professional reverb implementation covering FDN optimization with unitary matrices (Hadamard, Householder, velvet), non-uniform partitioned convolution, impulse response measurement/deconvolution, fractional delay interpolation (Thiran, Lagrange, sinc), room acoustic modeling, and perceptual tuning. Use this skill for implementing production-quality reverb effects, optimizing reverberation algorithms, working with impulse responses, or solving reverb-specific performance challenges. Trigger on: reverb, FDN, convolution, impulse response, room acoustics, delay network, feedback matrix, allpass, diffusion, early reflections, late reverb, Schroeder, Freeverb, IR measurement.
---

## FDN Reverb: Production Implementation

### Optimal Delay Lines
Use co-prime lengths (~37-124ms range at 48kHz) to maximize echo density and prevent metallic coloration. The delay lengths should be mutually co-prime to avoid shared resonant modes.

### Unitary Feedback Matrices

**Hadamard** (8×8): O(N log N) via fast Walsh-Hadamard transform. Normalize by 1/sqrt(N). Crisp, defined character.

**Householder**: H = 2vvᵀ/||v||² - I. O(N) operations. Maximum diffusion, smoother tails. Implementation: sum all delays, multiply by 2/N, subtract from each.

**Velvet Feedback Matrices** (modern): Sparse matrices inspired by velvet noise sequences. Ultra-dense reverb with significantly less CPU than full matrices. Recent research from Aalto University.

### Velvet Noise Reverb
Velvet noise is a sparse pseudo-random ternary sequence containing only {-1, 0, +1}. Convolution reduces to multiplication-free sparse sums — 40× fewer operations than standard FIR convolution (e.g., 44,100-tap FIR: 88,199 ops/sample → ~2,200 with velvet noise).

**Filtered Velvet Noise (FVN)**: Divide IR into non-overlapping segments, approximate each with spectral coloration filter + sparse velvet-noise FIR. Sparsity increases toward tail (narrower bandwidth = sparser sequences). Post-processing through Schroeder allpass filters.

**Dark Velvet Noise (DVN)**: Spectrally darker variant, implemented with multi-tap-delay + Recursive Running-Sum blocks. Models non-exponential decay envelopes.

**Velvet-Noise Decorrelator**: Efficient FIR decorrelation using sparse noise sequences — 76% fewer operations than white noise while maintaining equivalent broadband decorrelation. Optimized version from Erlangen AudioLabs.

### Damping: Frequency-Dependent Decay
Real rooms absorb high frequencies faster. Apply one-pole lowpass to each feedback path:
```cpp
filtered = (1 - damp) * input + damp * filtered;  // damp ∈ [0, 1]
```

For professional quality, use multiband damping (Jot's methodology): separate RT60 control for low, mid, and high frequency bands.

### RT60 Control
`feedback_gain = 10^(-3 * delay_seconds / RT60_seconds / 20)`

### Time-Varying FDN (Modulation)
Slowly modulating delay line lengths (±1-3 samples at 0.5-2Hz) breaks up metallic artifacts and adds lushness without audible pitch effects.

---

## Non-Uniform Partitioned Convolution

JUCE's `dsp::Convolution` implements non-uniform partitioning internally. For custom implementations:

**Architecture**: Small partitions at the front (low latency for early reflections), larger partitions toward the tail (efficiency for late reverb).

**Reference implementations**: Barcelona Reverbera (JUCE 8 VST3, template metaprogramming for FFT stages), FFTConvolver (C++ library with TwoStageFFTConvolver), RTConvolve (zero-latency via Hurchalla's time-distributed FFT).

**IR Switching Without Clicks**: Cross-fade between old and new convolution outputs over 50-100ms. JUCE's Convolution class handles this internally.

---

## Fractional Delay Interpolation

| Method | Gain Error | CPU | Time-Varying | Best For |
|--------|-----------|-----|-------------|----------|
| Linear | Small | Minimal | Excellent | General, low-bandwidth |
| Lagrange (3rd) | Small | Low | Good | Reverb delay lines |
| Thiran Allpass | **Zero** | Medium | Poor | Inside feedback loops |
| Sinc (windowed) | Minimal | High | Good | Pitch shifting |

**Thiran** is preferred inside FDN feedback loops because its allpass characteristic means zero gain error at all frequencies - critical for stable feedback. However, Thiran filters are not robust under rapid time-varying conditions (use Lagrange for chorus/flanger).

---

## Impulse Response Measurement

### Exponential Sine Sweep (ESS)
Most reliable technique. Generate log-frequency sweep from 20Hz to 20kHz over 10-30 seconds, record room response, deconvolve using inverse filter in frequency domain.

**Deconvolution**: IR_FFT = Response_FFT / Chirp_FFT (with regularization to avoid division by near-zero values).

### IR Post-Processing
1. **Trim silence**: Find noise floor threshold, cut pre/post silence
2. **Remove pre-ringing**: Shift IR so direct sound is at sample 0
3. **Normalize**: Scale peak to 0.99 (-0.09 dB headroom)
4. **Frequency analysis**: Compute RT60 per octave band

---

## Perceptual Architecture

### Hybrid Reverb (Early + Late)
Separate early reflections (geometric, tight, 0-80ms) from late reverb (FDN, diffuse, 80ms+). Mix independently for maximum control. Early reflections define room size/shape perception; late reverb defines warmth/decay.

### Frequency-Dependent Decay
Split into 3 bands with crossover filters. Typical RT60 values: Low (~3.5s), Mid (~3.0s), High (~2.0s). This models natural room absorption where high frequencies decay fastest.

---

## Differentiable Artificial Reverberation (DAR)

Modern approach using differentiable signal processing for parameter estimation:

**Architecture**: Replace IIR filters with FIR approximations via frequency-sampling method. Three models: differentiable FVN, AFVN, and Delay Network. Train ARP estimation networks end-to-end for analysis-synthesis (RIR-to-params) and blind estimation (reverberant-speech-to-params).

**Differentiable FDN** (Schlecht et al. 2023-2024): Learnable delay lines allow simultaneous optimization of all FDN parameters via backpropagation. Renders perceptual qualities of measured room impulse responses. Published at DAFx-26.

---

## Gardner Non-Uniform Partitioned Convolution

William Gardner (1995) "Efficient Convolution Without Input-Output Delay":
- Early part: direct-form FIR (small, low latency)
- Later blocks: progressively larger FFT partitions
- Optimal block pattern: first FIR block size 2N, then FFT blocks N,N,2N,2N,4N,4N...
- Achieves zero-latency convolution with computational efficiency
- Foundation for all modern convolution reverb engines (FFTConvolver, JUCE dsp::Convolution)

---

## Schroeder-Moorer Legacy

**Schroeder 1962** "Natural Sounding Artificial Reverberation" (Bell Labs):
- First digital reverb: parallel comb filters → series allpass filters
- Major drawback: non-exponential decay
- Foundation for all subsequent digital reverb algorithms

**Moorer 1979** improvements:
- Added lowpass filters in comb feedback paths (frequency-dependent decay)
- Better approximation of natural room absorption

**Dattorro 1997** "Effect Design Part 1" (CCRMA Stanford):
- Smallest good-sounding reverb network known
- Allpass loop topology "in the style of Griesinger/Lexicon"
- All delay lengths and coefficients published
- Extensively implemented and studied

---

## Decay Rate EQ (Advanced Frequency Control)

Beyond simple low/high damping, modern reverbs implement per-band decay rate control:

**FabFilter Pro-R approach**: Up to 6 parametric EQ bands controlling decay rate independently across the spectrum. Uses Bell, High/Low Shelf, and Notch curves. Allows sculpting reverb character per frequency region — e.g., extended bass decay with faster mid-range for clarity.

**Implementation**: Apply frequency-dependent gain multipliers within FDN feedback loop:
```cpp
// Per-band decay: compute gain from RT60 target per band
for (int band = 0; band < numBands; ++band) {
    float rt60 = decayRateEQ.getRT60ForBand(band);
    float gain = std::pow(10.0f, -3.0f * delaySeconds / rt60 / 20.0f);
    bandGains[band] = gain;
}
```

---

## References
- Schroeder, M.R. (1962) "Natural Sounding Artificial Reverberation" - JAES 10(3)
- Moorer, J.A. (1979) "About This Reverberation Business" - Computer Music Journal
- Jot, J.M. & Chaigne, A. (1991) "Digital Delay Networks for Designing Artificial Reverberators" - AES Convention 90
- Dattorro, J. (1997) "Effect Design Part 1: Reverberator and Other Filters" - CCRMA Stanford
- Gardner, W. (1995) "Efficient Convolution Without Input-Output Delay" - JAES 43(3)
- Schlecht, S.J. (2020) "Allpass Feedback Delay Networks" - IEEE Trans. Signal Processing
- Välimäki, V. et al. (2012/2016) "More Than 50 Years of Artificial Reverberation"
- [Signalsmith - Let's Write a Reverb](https://signalsmith-audio.co.uk/writing/2021/lets-write-a-reverb/)
- [CCRMA - FDN Reverberation](https://www.dsprelated.com/freebooks/pasp/FDN_Reverberation.html)
- [CCRMA - Delay Line Interpolation](https://www.dsprelated.com/freebooks/pasp/Delay_Line_Signal_Interpolation.html)
- [Thiran Allpass Interpolators](https://www.dsprelated.com/freebooks/pasp/Thiran_Allpass_Interpolators.html)
- [SegfaultDSP - FDN Performance](https://segfaultdsp.com/posts/fdn_perf/)
- [Barcelona Reverbera](https://github.com/SbrkDevices/BarcelonaReverbera)
- [FFTConvolver](https://github.com/HiFi-LoFi/FFTConvolver)
- [DAFx Paper Archive](https://www.dafx.de/paper-archive/)
- [Sean Costello - 1000 Years of Reverbs (AES 2015)](https://www.aes-media.org/sections/pnw/ppt/costello/AES2015ReverbPresentation.pdf)
