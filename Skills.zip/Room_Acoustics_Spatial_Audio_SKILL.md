---
name: room-acoustics-spatial-audio
description: |
  Comprehensive guide to room acoustic modeling and spatial audio processing covering Ambisonics encoding/decoding, HRTF-based binaural rendering, spherical harmonics, scattering delay networks (Schlecht), VBAP/DBAP panning, spatial audio frameworks (SPARTA, SAF), distance/absorption modeling, and immersive audio format support (Atmos, Auro-3D). Essential for building spatializer plugins, room simulators, binaural renderers, and 3D audio tools. Trigger on: spatial audio, Ambisonics, binaural, HRTF, spherical harmonics, panning, VBAP, room simulation, scattering, distance attenuation, immersive audio, Atmos, surround, 3D audio, SPARTA, SAF, head tracking, ambisonics decoder, HOA, FOA, binaural room impulse response, BRIR.
---

## Ambisonics

### Fundamentals
Ambisonics represents a 3D sound field using spherical harmonics. The sound field is encoded independent of speaker layout, then decoded to any target configuration.

**Orders**:
- **FOA (First Order)**: 4 channels (W, X, Y, Z). Captures basic directionality. Equivalent to figure-8 patterns along 3 axes + omnidirectional.
- **HOA (Higher Order)**: (N+1)² channels for order N. 3rd order = 16 channels. Higher order = sharper spatial resolution.
- **Practical limit**: 3rd-5th order for most applications (16-36 channels). Beyond 5th order, diminishing perceptual returns.

### Encoding
Convert a mono source at direction (azimuth θ, elevation φ) to Ambisonic signals using spherical harmonic coefficients:

**ACN channel ordering** (standard):
- Channel 0: W = 1 (omnidirectional)
- Channel 1: Y = sin(θ)cos(φ)
- Channel 2: Z = sin(φ)
- Channel 3: X = cos(θ)cos(φ)

**SN3D normalization** (standard): Ensures equal energy distribution across harmonics.

**AmbiX format**: ACN + SN3D. Industry standard used by YouTube 360, Facebook 360, Google Resonance.

### Decoding
Convert Ambisonic signals to speaker feeds. Methods:

**Basic/Sampling decoder**: Direct projection onto speaker positions. Simple but uneven energy distribution for irregular layouts.

**AllRAD (All-Round Ambisonic Decoding)**: Projects onto virtual t-design loudspeaker layout, then uses VBAP to map to real speakers. Robust for irregular speaker arrays. Used in SPARTA.

**Binaural decoding**: Convolve each Ambisonic channel with corresponding HRTF spherical harmonic component. Enables headphone playback of Ambisonic content. **MagLS (Magnitude Least Squares)** preserves magnitude spectrum while allowing phase to vary — best perceptual quality for Ambisonic binaural decoding.

**Max-rE decoding**: Applies weighting to maximize energy vector concentration. Improves spatial precision for off-center listeners.

### JUCE Ambisonics Integration
JUCE provides `AudioChannelSet::ambisonic(order)` for bus configuration up to 7th order. VST 3.7.8+ supports 4th through 7th order arrangements. Use ACN ordering + SN3D normalization (AmbiX format).

```cpp
// JUCE AudioProcessor bus layout for FOA encoder
BusesProperties()
    .withInput("Input", AudioChannelSet::mono())
    .withOutput("Output", AudioChannelSet::ambisonic(1))  // FOA = 4 channels
```

### IEM Plugin Suite
Free open-source Ambisonic plugins from Graz University, built on JUCE. Supports up to 7th order. Includes: StereoEncoder, AmbiDecoder, RoomEncoder, BinauralDecoder, EnergyVisualizer, DirectivityShaper, and more.

---

## HRTF & Binaural Rendering

### Head-Related Transfer Functions
HRTFs describe how sound is filtered by the head, pinnae (outer ears), and torso before reaching the eardrums. Each direction has a unique pair of impulse responses (left/right ear).

**HRTF Databases**:
- **CIPIC**: 45 subjects, 1250 directions each. UC Davis. Free for research.
- **LISTEN** (IRCAM): 51 subjects, 187 directions. SOFA format.
- **HUTUBS** (TU Berlin): 96 subjects, high spatial resolution.
- **SADIE II**: KU100 dummy head + human subjects. Popular for Ambisonics.
- **SOFA format**: Standard for storing HRTFs (Spatially Oriented Format for Acoustics). AES69 standard. Libraries: libmysofa (C), SOFAlern.

### Binaural Rendering Pipeline
1. Determine source direction relative to listener (accounting for head tracking)
2. Select nearest HRTF pair (or interpolate between neighbors)
3. Convolve source audio with left/right HRTFs
4. Sum contributions from all sources
5. Apply headphone equalization (compensate for headphone frequency response)

### HRTF Interpolation
Avoid audible switching artifacts when source moves:
- **Nearest-neighbor**: Simplest, causes spatial jumps
- **Barycentric interpolation**: Used by 3DTI Toolkit — interpolates between 3 closest HRIRs. Left/right HRIRs selected independently based on relative angle to each ear (acoustic parallax). ITDs managed separately to reduce comb filtering.
- **Bilinear**: Interpolate between 4 nearest HRTFs. Smooth but can cause comb filtering
- **Spherical harmonic interpolation**: Decompose HRTF set into SH coefficients, interpolate in SH domain. Smoothest result.
- **MagLS (Magnitude Least Squares)**: Preserves magnitude spectrum while allowing phase to vary. Best perceptual quality for Ambisonic binaural decoding.

### 3D Tune-In Toolkit
Open-source C++ library for binaural 3D audio with HRTF rendering, hearing aid emulation, and hearing loss simulation. Features: HRIR convolution via overlap-save, barycentric interpolation, SOFA file support, head-size customization for ITD. Suitable for embedded devices.

### Head Tracking Integration
Real-time head orientation updates (yaw, pitch, roll) from IMU sensors in headphones. Rotate the Ambisonic sound field (or update HRTF lookup directions) to maintain stable spatial image as listener moves head.

**Hardware options**: Hedrot (open-source, Teensy 3 + ADXL345 accelerometer + HMC5883L magnetometer), Supperware Head Tracker (commercial, integrates directly with binaural plugin), nvsonic (Arduino Pro Micro + MPU-9250).

**Implementation**: Fuse accelerometer + magnetometer data using complementary or Madgwick filter → extract quaternion or Euler angles → apply rotation matrix to Ambisonic channels or update HRTF direction lookup.

```cpp
// Rotate FOA sound field by head orientation
void rotateAmbisonics(float* wxyz, float yaw, float pitch, float roll) {
    // Apply 3×3 rotation matrix to XYZ channels (W unchanged)
    float cosY = cos(yaw), sinY = sin(yaw);
    float x = wxyz[3], y = wxyz[1];
    wxyz[3] = x * cosY - y * sinY;  // Rotated X
    wxyz[1] = x * sinY + y * cosY;  // Rotated Y
    // Similar for pitch/roll on Z component
}
```

---

## Spatial Panning Algorithms

### VBAP (Vector Base Amplitude Panning)
Ville Pulkki's method. Pans a source to a virtual position using the nearest triangle of speakers (3D) or pair (2D).

**Algorithm**: For 3D, find the speaker triplet whose triangle contains the source direction. Compute gain vector: **g** = source_direction × inverse(speaker_matrix). Normalize gains.

**Advantages**: Sharp localization, pairs naturally with speaker arrays, computationally cheap.

### DBAP (Distance-Based Amplitude Panning)
Panning based on distance from source to each speaker. No need for speaker layout geometry — works with arbitrary configurations.

`gain_i = (1 / distance_i^rolloff) / sum(1 / distance_j^rolloff)`

### WFS (Wave Field Synthesis)
Physically recreates the sound field using dense speaker arrays (typically 50-200+ speakers). Based on Huygens' principle. Provides correct spatial cues for all listener positions, not just a sweet spot.

### DirAC (Directional Audio Coding)
Analysis-synthesis approach: analyze B-format signal to extract diffuseness and direction of arrival per time-frequency tile, then resynthesize for target format. Used in MPEG-H and Fraunhofer research.

---

## SPARTA & Spatial Audio Framework (SAF)

### SPARTA Plugin Suite
Open-source spatial audio plugins by Leo McCormack (Aalto University). Built on the Spatial Audio Framework (SAF).

**Key Plugins**:
- **sparta_ambiENC**: Ambisonic encoder (mono sources → HOA up to 7th order)
- **sparta_ambiDEC**: Ambisonic decoder with AllRAD, SAD, MMD, EPAD methods
- **sparta_ambiRoomSim**: Room simulation in Ambisonics with image-source method
- **sparta_binauraliser**: Binaural renderer with HRTF convolution and head tracking
- **sparta_multiConv**: Multi-channel convolver for BRIR playback
- **sparta_panner**: VBAP-based 3D panner
- **sparta_spreader**: Source spreading/widening in Ambisonics
- **COMPASS**: COding and Multi-Parameterised toolbox for Ambisonic Sound Scenes

### Google Resonance Audio
Open-source spatial audio SDK (Apache 2.0) optimized for mobile/desktop. Internally projects all sources into global HOA soundfield. Highly optimized DSP for spatializing hundreds of simultaneous 3D sound sources. SDKs for C/C++, Java, Objective-C, Web. Integrations for Unity, Unreal, FMOD, Wwise, DAWs. Omnitone companion library handles ambisonic decoding in Web Audio API.

### Spatial Audio Framework (SAF)
C library providing the DSP backbone for SPARTA. Modular design:

**Modules**:
- `saf_sh`: Spherical harmonic transforms, rotation, beamforming
- `saf_hrir`: HRTF processing, interpolation, diffuse-field equalization
- `saf_vbap`: VBAP gain computation for arbitrary speaker layouts
- `saf_reverb`: FDN reverb with frequency-dependent absorption
- `saf_utilities`: Matrix operations, FFT wrappers, convolution

**Integration with JUCE**: SAF provides C functions; SPARTA wraps them in JUCE AudioProcessor. Can use SAF directly in custom plugins via CMake.

---

## Scattering Delay Networks (Schlecht)

### Beyond Standard FDN
Sebastian Schlecht's research extends FDN reverb with physically-motivated scattering junctions, modeling how sound scatters at room boundaries.

**Scattering FDN**: Replace the single feedback matrix with a network of scattering junctions connected by delay lines. Each junction models the acoustic interaction at a wall/surface.

**Advantages over standard FDN**:
- More physically accurate energy distribution
- Natural frequency-dependent scattering
- Better modal density at low frequencies
- Parameterizable by room geometry

**Recent advances (Schlecht 2024)**: Optimizable scattering feedback matrices with attenuation filters reduce perceptual coloration of late reverberation. Allpass FDN design ensures colorless reverberation — narrow modal excitation distribution leads to high perceived modal density. Velvet feedback matrices offer superior computational cost with high echo density.

### Delay Network Topologies
- **Series-parallel**: Chain of allpass sections. Moorer/Schroeder classic.
- **Feedback Delay Network**: Parallel delays with dense feedback matrix. Jot/Stautner standard.
- **Scattering Delay Network**: Delays connected by scattering junctions in a graph topology matching room geometry.
- **Waveguide mesh**: 2D/3D grid of bidirectional delay lines. Highest physical accuracy, highest CPU cost.

### Lossless Condition
For stable, energy-preserving reverb: feedback/scattering matrices must be **unitary** (or orthogonal for real-valued). This ensures energy is neither created nor destroyed at each junction.

### Frequency-Dependent Processing in FDN
Apply absorption filters at each delay output (before feedback):
```cpp
// Per-delay-line absorption (graphic EQ approach)
for (int d = 0; d < numDelays; ++d) {
    delayOutput[d] = absorptionFilter[d].process(delayLine[d].read());
    // Then apply feedback matrix and write back
}
```

---

## Room Acoustic Modeling

### Image Source Method
Compute early reflections by mirroring the source across room walls. Each mirror image represents a reflection path.

**1st order**: 6 reflections (one per wall in a rectangular room)
**2nd order**: ~30 reflections
**Nth order**: grows exponentially → practical limit ~3rd-4th order

**Limitation**: Only models specular reflections. Best combined with ray tracing for diffuse/late energy.

### Ray Tracing
Emit many rays from source, trace bounces off surfaces, accumulate energy at receiver. Better for complex room geometries. Can handle diffuse reflections and scattering.

**Stochastic ray tracing**: Randomized ray directions with importance sampling. Converges to accurate result with enough rays. Produces multi-band energy histograms.

### Hybrid Simulators

**Wayverb** (C++14, OpenCL): Combines image-source (early reflections) + stochastic ray tracing (late reflections) + digital waveguide mesh (low frequencies). GPU-accelerated. Uses perfect-reconstruction frequency-domain filtering to combine sub-band IRs into broadband result. Models distance attenuation, frequency-dependent boundary absorption and scattering.

**Pyroomacoustics** (Python, C++ core): Fast prototyping platform with image source method + ray tracing for general polyhedral rooms. Includes beamforming algorithms, source separation, adaptive filtering, STFT processing. Shoebox rooms (rectangular) are most efficient to simulate. Excellent for training data generation.

**vaRays** (C++/Python): Open-source acoustic ray tracing with ambisonic convolver for real-time 3D auralization.

### Acoustic Parameters
- **RT60**: Time for sound to decay by 60dB. Measured per octave band.
- **EDT (Early Decay Time)**: Decay of first 10dB, extrapolated. Correlates with perceived reverberance.
- **C80 (Clarity)**: Ratio of early energy (0-80ms) to late energy. Higher = clearer speech/music.
- **D50 (Definition)**: Fraction of energy in first 50ms. Speech intelligibility metric.
- **IACC (Inter-Aural Cross Correlation)**: Measures spatial impression. Lower IACC = more enveloping sound.

### Distance Modeling
As source-listener distance increases:
1. **Inverse-square law**: Amplitude ∝ 1/distance (6dB per doubling)
2. **Air absorption**: High frequencies attenuated more over distance (~1dB/100m at 4kHz, ~5dB/100m at 8kHz)
3. **Direct-to-reverb ratio**: Decreases with distance (closer = more direct, farther = more reverberant)
4. **ILD/ITD changes**: Less pronounced at distance (source appears more diffuse)

```cpp
float computeDistanceGain(float distance, float refDistance = 1.0f) {
    return refDistance / juce::jmax(distance, 0.01f);  // Avoid div-by-zero
}

float computeAirAbsorption(float distance, float frequency) {
    // Approximate absorption coefficient (dB/meter)
    float alpha = 0.0001f * frequency;  // Simplified model
    return juce::Decibels::decibelsToGain(-alpha * distance);
}
```

---

## Immersive Audio Formats

### Dolby Atmos
Object-based + bed-based audio. Up to 128 audio objects with 3D position metadata (X, Y, Z coordinates). Renderer maps objects to speaker layout at playback in real-time.

**Plugin development**: Atmos renderer is proprietary (Dolby). Plugins output object-based audio via ADM (Audio Definition Model) metadata. JUCE supports multi-channel buses up to 7.1.4. ADM BWF (Broadcast Wave File) is the official master format containing all audio + metadata XML.

**Workflow**: Author spatial positions in DAW using 3D panner → positional metadata stored with audio → Dolby Atmos Renderer renders to monitoring speaker config and creates deliverables.

### Auro-3D
Layer-based: adds height channels to traditional surround (e.g., 9.1, 11.1, 13.1). Uses "Auro-Matic" upmixer for legacy content.

### MPEG-H
Open standard from Fraunhofer. Scene-based (Ambisonics) + object-based + channel-based hybrid. Used in broadcast (ATSC 3.0, DVB).

---

## References
- [SPARTA Plugins](https://leomccormack.github.io/sparta-site/) - Aalto University spatial audio suite
- [Spatial Audio Framework (SAF)](https://github.com/leomccormack/Spatial_Audio_Framework) - C library
- [Schlecht - Scattering Delay Networks](https://www.sebastianschlecht.com/) - Research publications
- [Pulkki - VBAP](https://doi.org/10.1121/1.424656) - Vector Base Amplitude Panning
- [libmysofa](https://github.com/hoene/libmysofa) - SOFA HRTF reader
- [3D Tune-In Toolkit](https://github.com/3DTune-In/3dti_AudioToolkit) - Binaural rendering
- [IEM Plugin Suite](https://plugins.iem.at/) - Ambisonics tools from Graz
- [COMPASS](https://github.com/polarch/compass) - Ambisonic parameterization
- [DirAC](https://research.aalto.fi/en/publications/directional-audio-coding) - Aalto research
- [DAFx Proceedings](https://www.dafx.de/) - Digital Audio Effects conference
- [AES AVAR Standard](https://www.aes.org/publications/standards/) - Audio formats documentation
