# Cinematic Reverb Sound Design SKILL

Design and implement studio-grade reverb plugins competitive with Valhalla Room, Lexicon 480L, and LiquidSonics Cinematic Rooms. Master FDN architectures, psychoacoustic principles, and advanced signal processing techniques.

## 1. Reverb Algorithm History & Foundations

Schroeder's 1962 seminal work "Natural Sounding Artificial Reverberation" established the parallel comb + series allpass architecture as the foundation for digital reverb. Moorer (1979) improved this with lowpass-filtered comb feedback, enabling natural high-frequency absorption. Jot & Chaigne (1991) formalized Feedback Delay Networks (FDN) as orthogonal matrix-based systems with superior diffuseness. Dattorro (1997) documented the elegant plate reverb algorithm in "Effect Design Part 1"—achieving excellent results with minimal computation through carefully chosen allpass loop topology. Välimäki's comprehensive review (2012/2016) covers 50+ years of reverberation design, while Costello's Valhalla DSP approach emphasizes psychoacoustic modeling over physical authenticity.

**Key insight**: The best-sounding reverbs prioritize perceptual quality and frequency-dependent behavior over geometric accuracy.

## 2. FDN (Feedback Delay Network) Deep Design

FDN represents the state-of-the-art in algorithmic reverb. Core architecture:

```cpp
// Simplified FDN feedback loop (Schlecht FDNTB toolbox approach)
void FDNReverb::process(float* input, float* output, int numSamples) {
    for (int n = 0; n < numSamples; ++n) {
        // Read delayed outputs
        float delayOut[N] = { delayLines[0].read(), ..., delayLines[N-1].read() };

        // Feedback matrix multiplication (Hadamard for N=power-of-2)
        float feedbackState[N];
        hadamardTransform(delayOut, feedbackState, N);

        // Apply damping filters (lowpass in feedback loop)
        for (int i = 0; i < N; ++i) {
            feedbackState[i] = dampingFilter[i].process(feedbackState[i]);
        }

        // Write to delays with modulation
        for (int i = 0; i < N; ++i) {
            float delayTime = baseDelay[i] + modulation[i].nextValue();
            delayLines[i].write(input[n] + feedbackState[i], delayTime);
        }

        // Output summation
        output[n] = 0.f;
        for (int i = 0; i < N; ++i) output[n] += delayOut[i];
    }
}
```

**Feedback matrices**: Hadamard matrices are computationally efficient (no multiplies for power-of-2) with maximum determinant (optimal scattering). Householder reflections (Jot, N=4) have all nonzero entries for maximum diffuseness. Hadamard is preferred for real-time DSP.

**Delay line selection**: Mutually prime lengths prevent periodicity. Modern approach: N=8 delays with lengths 353, 379, 409, 443, 479, 509, 557, 601 samples. Schlecht's completion problem theory optimizes unitary FDN properties.

**Modulation**: Random delay modulation (0.5-2.5ms deviation) prevents ringing. Lexicon 480L uses sophisticated random modulation on internal delay lines—crucial for cinematic quality.

**Damping filters**: Frequency-dependent RT60 control via multi-band IIR in feedback loop (FabFilter Pro-R approach with up to 6 bands). Example:

```cpp
// Per-band damping (simplified)
float decayRateHz[6] = {80, 250, 500, 2000, 4000, 8000};
float gainPerBand[6] = {0.95, 0.92, 0.88, 0.85, 0.80, 0.75};
// Use crossover + PEQ to apply per-band decay
```

## 3. Valhalla Room Architecture Analysis

Valhalla DSP's room simulator achieves superior psychoacoustic results through deliberate choices:

- **Early Section**: Not "early reflections" but "early energy"—dense, amorphous field without audible discrete taps
- **Late Section**: Algorithmic FDN tail with frequency-dependent decay
- **Design philosophy**: Render impression of ideal/composite room rather than physical accuracy
- **Independent Controls**: Separate early/late processing enables cinematic customization
- **Dark Room Mode**: Vintage character via high-damping, shorter pre-delay

The early section uses parallel paths without allpass delays—avoiding comb-filter coloration. This approach emphasizes spaciousness and warmth over discrete echo perception.

## 4. Advanced Reverb Techniques

**Velvet Noise Reverb** (Lähdeoja et al., Aalto): Sparse {-1, 0, +1} ternary sequences require 40x fewer operations than standard FIR while maintaining diffuseness. Filtered Velvet Noise (FVN) and Dark Velvet Noise (DVN) variants optimize tonality. Use as:
- Impulse response decorrelators
- Early reflection generators
- Diffuser elements in FDN

**Modal Reverb** (US9805704B1): Parallel resonant filters tuned to room eigenfrequencies. Controls per-mode amplitude and damping. Enables explicit room-dimension modeling with physical accuracy unavailable in pure FDN.

**Granular/Spectral Freeze**: Transform reverb tails into ambient textures. Up to 64 overlapping grains with independent pitch/time-stretch. Spectral freeze uses FFT-based processing for time-freezing without pitch change.

**Differentiable Artificial Reverberation (DAR)**: FIR approximations via frequency-sampling + gradient descent training. Enables end-to-end neural optimization of reverb parameters. Differentiable FDN implementations allow learnable delay times.

## 5. Convolution & Hybrid Approaches

**Gardner's non-uniform partitioned convolution** (1995): Early direct-form FIR (0-50ms) + later FFT blocks (block pattern 2N, N, N, 2N, 2N, 4N...). Minimizes latency and computation.

**FFTConvolver library**: C++ implementation of partitioned overlap-save with TwoStageFFTConvolver for non-uniform blocks. Critical for low-latency hybrid systems.

**LiquidSonics Cinematic Rooms approach**: Multi-sampling IR capture separates early/late components independently. Crucially, captures time-varying reverb impossible with static convolution—room response evolves with source movement.

**Hybrid implementation**:
```
INPUT → Early Convolution (Gardner, 0-100ms) → Early Output
      → Algorithmic FDN (late tail) → Late Output → Crossfade → OUTPUT
```

This combines IR clarity with algorithmic infinite tail and density control.

## 6. Impulse Response Measurement

**Farina's exponential sine sweep method** (~15dB better SNR than MLS): Swept sinusoid 20Hz-20kHz deconvolves to IR while measuring harmonic distortion simultaneously. Gold standard for studio acoustics.

**Deconvolution**: Linear convolution with analytical inverse filter (time-domain division by sweep spectrum).

**True stereo capture**: Dual microphone crossed pattern (X-Y or M-S) captures spatial information. Critical for cinematic realism.

**Processing**: Time-window IR (predelay, RT60 calculation), apply inverse distance law, normalize to perceptual loudness (LUFS).

## 7. Perceptual Quality & Psychoacoustics

**RT60**: Reverberation time in each octave band (63Hz-8kHz). Natural rooms exhibit 20-30% faster HF decay. Octave-band control essential for cinematic character.

**C80 (Clarity Index)**: Ratio of early energy (0-80ms) to total energy. Values >0dB indicate "clear" spaces (concert halls 0-2dB, bedrooms -5 to -10dB, cathedrals -8 to -10dB).

**IACC (Interaural Cross-Correlation)**:
- IACC_Early (0-80ms): Apparent Source Width (ASW). Lower IACC = wider perception
- IACC_Late (>80ms): Envelopment sensation. Values <0.4 perceived as enveloping

**Griesinger spaciousness research** (Lexicon): Late lateral energy >50ms after attack drives spaciousness perception. Most effective range 300-500ms—longer tails sound more cinematic.

**EDT (Early Decay Time)**: Initial slope steepness. Often faster than RT60, indicating early absorption.

**Echo density**: Minimum 5-10 echoes per 500ms to avoid discrete reflection perception. FDN achieves ~500+ echoes/second naturally.

## 8. Fractional Delay & Interpolation

**Thiran allpass filters** (Schlecht): Maximally-flat group delay, stable for D > N-1. Efficient closed-form coefficients for interpolating delays—essential for modulated delay lines:

```cpp
// Thiran N=1 (first-order): D = (1 - a*z^-1) / (z^-1 - a)
// where a = (D - 1) / (D + 1), D = desired fractional delay
float thiran_a = (fractionalDelay - 1.f) / (fractionalDelay + 1.f);
float y_n = thiran_a * (x_n - y_nm1) + x_nm1;
y_nm1 = y_n;
```

**Lagrange interpolation**: FIR approach better for rapidly varying delays (pitch-shifting reverb tails).

**Sinc interpolation**: Ideal bandlimited, windowed for practical use (Hann/Blackman window).

## 9. FAUST DSP Language for Reverb Prototyping

FAUST enables rapid reverb algorithm development:

```faust
// Simplified FDN-based reverb skeleton (FAUST)
import("stdfaust.lib");

fdn_size = 8;
delays(i) = (i+1) * 101 + i * 13;  // Mutually prime delay lines

process = _ :
  (split(fdn_size) : par(i, fdn_size, delay(delays(i)))) :
  hadamard(fdn_size) :
  (par(i, fdn_size, lowpass(6000, 0.9))) :  // Damping filters
  mix(fdn_size);
```

**Key libraries**:
- `zita_rev1` (Fons Adriaensen): FDN + allpass comb, frequency-dependent decay, stereo
- `freeverb`: Educational 4-parallel-allpass + 8-comb architecture
- `zita_rev1_ambi`: Ambisonic surround version

Export to C++/JUCE for production. FAUST compilation generates optimized DSP code.

## 10. Stereo & Spatial Processing

**Mid-Side decomposition**: Separate L/R into mid (mono) + side (difference). Apply reverb to mid, apply scaled reverb to side for stereo width control:

```cpp
float mid = (left + right) * 0.5f;
float side = (left - right) * 0.5f;
float mid_reverb = reverb.process(mid);
float side_reverb = reverb.process(side) * stereoWidth;
output_left = mid_reverb + side_reverb;
output_right = mid_reverb - side_reverb;
```

**Decorrelation**: Velvet-noise convolution, allpass cascade (6-8 stages), or frequency-dependent delay (~10-40ms for 1-5kHz bands).

**Cross-channel coupling** in FDN: Small percentage of channel-A output fed to channel-B delays creates natural stereo spread without excessive computational load.

**Haas effect**: 20-50ms pre-delay difference between channels enhances width perception.

## 11. Signalsmith Reverb Tutorial Approach

Modern, computationally efficient FDN without IIR allpass filters:

**Principles**:
- Minimum 8 internal channels for diffuseness
- Allpass diffuser uses irregular phase response via Hadamard matrix
- NO feedback allpass filters (simplifies tuning, improves stability)
- Early section: dense parallel delays (30-200ms) with cross-mixing
- Late section: FDN with frequency-dependent damping + modulation

**Advantages**: Clean, transparent algorithm with no resonance coloration. Superior to traditional allpass-heavy designs for cinematic applications.

## 12. Reference Implementations to Study

**Freeverb** (Schroeder/Moorer foundation): 4 parallel allpass + 8 parallel comb per channel. ~300 lines of code. Educational value: understand basic architecture limitations (notable comb coloration).

**Zita-Rev1** (Fons Adriaensen): Production FDN with frequency-dependent decay, modulation, stereo coupling. ~800 lines. Reference for professional quality.

**Dattorro plate reverb** (CCRMA 1997): Minimal network achieving excellent results. Study allpass loop topology. ~100 lines optimized C++.

**LiquidSonics reference**: Reverse-engineer via impulse response measurement + spectral analysis (STFT). Observe:
- Early section: dense energy ~40-100ms
- Echo density growth rate
- Frequency-dependent decay (measure RT60 per octave band)
- Spatial character (IACC measurements)

## 13. Design Workflow for Cinematic Reverb

**Phase 1: Specification**
1. Define psychoacoustic target: spaciousness (IACC_Late <0.4), warmth (emphasis 100-500Hz decay), clarity (C80 >-5dB), tail character (smooth vs. diffuse)
2. Target use cases: orchestral rooms, guitar chambers, plate/spring emulation, surreal ambience

**Phase 2: Architecture Selection**
3. Choose: pure FDN (simplest, most control), hybrid convolution+FDN (maximum clarity), or modal+FDN (physical grounding)
4. Select feedback matrix: Hadamard (efficiency), Householder (density), or optimized scattering matrix

**Phase 3: Implementation**
5. Implement early section: Valhalla-style dense energy (~40ms) vs. discrete reflection taps
6. Implement FDN core: 8+ delay lines, frequency-dependent damping (6-band EQ in feedback loop)
7. Add modulation: random LFO ±0.5-2.5ms on delay lines, chorus on outputs

**Phase 4: Stereo & Spatial**
8. Implement mid-side processing + decorrelation
9. Add cross-channel coupling (5-15% feedback)
10. Implement Haas effect pre-delay

**Phase 5: Tuning & Validation**
11. Measure RT60 per octave band (target: 2-5s depending on size, 15-25% HF roll-off)
12. Calculate C80 and IACC from measurements
13. A/B test impulse response against Valhalla Room, Lexicon 480L, Cinematic Rooms
14. Iterate damping, delay times, feedback matrix for psychoacoustic matching

**Phase 6: Optimization**
15. SIMD vectorization (4-8 parallel FDN computations)
16. Denormal prevention (flush subnormal floats to zero)
17. Matrix multiplication optimization (use SSE/AVX hadamard for power-of-2)
18. Profile: target <5% CPU per instance at 96kHz, 256-sample latency

**Phase 7: Parameter Interface**
- Size (0.1-10s RT60)
- Decay Rate EQ (6 bands, ±10dB per octave)
- Width (stereo decorrelation amount)
- Pre-delay (0-200ms)
- Early/Late balance
- Freeze mode (spectral lock)
- Wet/Dry mix

## Academic References & Further Study

- Jot, J.-M., & Chaigne, A. (1991). "Digital Delay Networks for Very High Order Interpolated FDN Design." AES 11th International Conference.
- Dattorro, J. (1997). "The 1997 Audio Engineering Society Convention Paper: Effect Design Part 1." *Journal of the AES*, 45(9).
- Välimäki, V., et al. (2012). "More Than 50 Years of Artificial Reverberation." *IEEE Signal Processing Magazine*, 29(6), 20-40.
- Schlecht, S. J., & Habets, E. A. (2017). "Towards High-Order Ambisonics Capturing for Spherical Microphone Arrays." *IEEE/ACM Transactions on Audio, Speech, and Language Processing*, 25(5).
- Gardner, W. G. (1995). "Efficient Convolution Without Input-Output Delay." *Journal of the AES*, 43(3), 127-136.
- Schroeder, M. R. (1962). "Natural Sounding Artificial Reverberation." *Journal of the Audio Engineering Society*, 10(3), 219-223.
- Moorer, J. A. (1979). "About This Reverberation Business." *Computer Music Journal*, 3(2), 13-28.
- Lähdeoja, O., Välimäki, V., & Karjalainen, M. (2009). "Capturing the Essence of Comb Filters with Sparse Velvet Noise." *IEEE Signal Processing Letters*, 16(1), 1-4.

---

**Last Updated**: 2026-02-28 | Comprehensive cinematic reverb design reference for studio-grade DSP implementation.