# Audio Plugin UI/UX Design SKILL

## 1. JUCE GUI Architecture

JUCE provides a powerful component-based GUI framework for audio plugins. The hierarchy flows from `AudioProcessorEditor` as the root, with child `Component` objects managed in a tree structure.

### Component Hierarchy & Paint Chain
```cpp
class MyPluginEditor : public juce::AudioProcessorEditor {
public:
    MyPluginEditor(MyAudioProcessor& processor)
        : AudioProcessorEditor(&processor) {
        setSize(800, 600);
        addAndMakeVisible(rotarySlider);
        addAndMakeVisible(levelMeter);
    }

    void paint(juce::Graphics& g) override {
        // Draw background, gradients, decorative elements
        g.fillAll(juce::Colour(30, 30, 30));  // Dark studio background

        // Use Graphics context for vector drawing
        juce::Path cornerPath;
        cornerPath.addRoundedRectangle(10, 10, 780, 580, 12.0f);
        g.setColour(juce::Colour(50, 50, 50));
        g.strokePath(cornerPath, juce::PathStrokeType(2.0f));
    }

private:
    juce::Slider rotarySlider;
    juce::Component levelMeter;
};
```

### Timer-Based Animation (Decouple from Audio Thread)
```cpp
class AnimatedLED : public juce::Component, public juce::Timer {
public:
    void startTimer() {
        Timer::startTimer(33);  // ~30fps, safe for UI thread
    }

    void timerCallback() override {
        // Update animation state on UI thread
        repaint();
    }

    void paint(juce::Graphics& g) override {
        // Draw LED with current brightness
        g.setColour(ledColour.withAlpha(currentBrightness));
        g.fillEllipse(0, 0, getWidth(), getHeight());
    }

private:
    float currentBrightness = 0.0f;
    juce::Colour ledColour = juce::Colours::red;
};
```

### LookAndFeel Customization
```cpp
class CustomLookAndFeel : public juce::LookAndFeel_V4 {
public:
    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                         float sliderPos, float rotaryStartAngle, float rotaryEndAngle,
                         juce::Slider& slider) override {
        auto diameter = juce::jmin(width, height);
        auto radius = diameter * 0.45f;
        auto centreX = x + width * 0.5f;
        auto centreY = y + height * 0.5f;

        // Draw knob background
        g.setColour(juce::Colour(40, 40, 40));
        g.fillEllipse(centreX - radius, centreY - radius, diameter, diameter);

        // Draw indicator line
        auto angle = rotaryStartAngle + sliderPos * (rotaryEndAngle - rotaryStartAngle);
        auto thumbX = centreX + radius * std::cos(angle - juce::MathConstants<float>::pi / 2.0f);
        auto thumbY = centreY + radius * std::sin(angle - juce::MathConstants<float>::pi / 2.0f);

        g.setColour(juce::Colours::orange);
        g.drawLine(centreX, centreY, thumbX, thumbY, 3.0f);
    }
};
```

### Resizable UI with Aspect Ratio Constraint
```cpp
class ResizablePluginEditor : public juce::AudioProcessorEditor {
public:
    void resized() override {
        // Apply aspect ratio constraint
        auto bounds = getLocalBounds();
        auto constrainedSize = constrainedRectangle(bounds);

        // Layout child components with scaling
        rotarySlider.setBounds(constrainedSize.reduced(20));
    }

private:
    juce::Rectangle<int> constrainedRectangle(juce::Rectangle<int> bounds) {
        auto targetRatio = 4.0f / 3.0f;
        auto currentRatio = static_cast<float>(bounds.getWidth()) / bounds.getHeight();

        if (currentRatio > targetRatio) {
            auto constrainedWidth = bounds.getHeight() * targetRatio;
            return bounds.withWidth(constrainedWidth);
        }
        return bounds;
    }
};
```

## 2. GPU-Accelerated Rendering

### Direct2D (Windows) - Hardware Accelerated
JUCE 8 introduces Direct2D support for Windows, providing significant GPU acceleration benefits. Enable with:
```cpp
// In your editor constructor
setOpaque(true);
// Direct2D is automatically used on Windows with JUCE 8+
```

**Key Performance Tips:**
- Avoid `setBufferedToImage(true)` for animated components; GPU↔CPU sync is expensive
- GPU internal bandwidth is enormous; leverage it for complex drawing operations
- CPU↔GPU bandwidth is the narrow bottleneck; minimize texture transfers
- Keep animated content on GPU side; only final composited result crosses to CPU

### OpenGL Context for Custom Shaders
```cpp
class GLComponent : public juce::Component {
public:
    GLComponent() {
        openGLContext.attachTo(*this);
    }

    void newOpenGLContextCreated() override {
        // Compile custom GLSL shaders
        auto vertexShader = juce::OpenGLShaderProgram::createVert(
            "attribute vec4 position; void main() { gl_Position = position; }");
    }

    void renderOpenGL() override {
        // Render using OpenGL context
        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
    }

private:
    juce::OpenGLContext openGLContext;
};
```

**Metal (macOS):** Apple's future direction as OpenGL deprecates. Plan shader migration accordingly.

## 3. Melatonin Libraries for Polish

### Melatonin Blur - Shadows & Effects
```cpp
#include <melatonin_blur/melatonin_blur.h>

class ShadowedComponent : public juce::Component {
public:
    ShadowedComponent() : shadow(4, 0.4f) {}  // radius=4, opacity=0.4

    void paint(juce::Graphics& g) override {
        juce::Path controlPath;
        controlPath.addRoundedRectangle(getBounds().reduced(5), 8.0f);

        // Render shadow
        shadow.render(g, controlPath);

        // Draw actual control
        g.setColour(juce::Colours::darkgrey);
        g.fillPath(controlPath);
    }

private:
    melatonin::DropShadow shadow;
};
```

### Melatonin Inspector - Visual Debugging
```cpp
// In editor constructor
#if JUCE_DEBUG
    auto* inspector = new melatonin::Inspector(*this);
    inspector->setVisible(true);  // Toggle with Ctrl+Shift+I
#endif
```

**Inspector Features:**
- Point-and-click component inspection (like browser DevTools)
- Size, position, and distance-to-parent display
- FPS meter overlay for profiling paint performance
- Parent/child hierarchy visualization

## 4. Visual Design Principles for Audio Plugins

### Color Theory for Dark Studio Environments
```cpp
// Dark theme reduces eye strain in mixing environments
static constexpr auto BG_DARK = juce::Colour(20, 20, 20);
static constexpr auto BG_PANEL = juce::Colour(35, 35, 35);
static constexpr auto ACCENT_PRIMARY = juce::Colour(0, 200, 255);    // Cyan accent
static constexpr auto ACCENT_SECONDARY = juce::Colour(255, 150, 0);  // Warm accent
static constexpr auto ALERT_COLOR = juce::Colour(200, 80, 80);       // Red for peaks

void paintPresetCategory(juce::Graphics& g) {
    g.setColour(BG_DARK);
    g.fillRect(0, 0, getWidth(), getHeight());

    g.setColour(ACCENT_PRIMARY);
    g.drawText("Room Presets", 10, 10, 100, 20, juce::Justification::left);
}
```

### Typography & Labeling
```cpp
g.setFont(juce::Font(11.0f, juce::Font::bold));
g.setColour(juce::Colour(200, 200, 200));
g.drawText("Decay Time (ms)", 10, 30, 150, 20, juce::Justification::left);

// Parameter value display
juce::String valueText = juce::String(decayTimeMs, 1) + " ms";
g.setFont(juce::Font(13.0f));
g.setColour(juce::Colours::orange);
g.drawText(valueText, 160, 30, 80, 20, juce::Justification::right);
```

## 5. Knob & Slider Design Patterns

### Custom Rotary Slider with Fine Control
```cpp
class FineTuneRotarySlider : public juce::Slider {
public:
    FineTuneRotarySlider() : juce::Slider(juce::Slider::RotaryHorizontalDrag,
                                          juce::Slider::NoTextBox) {
        setRange(0.0, 1.0, 0.001);
        setTooltip("Shift+drag for fine control");
    }

    void mouseDown(const juce::MouseEvent& event) override {
        if (event.mods.isShiftDown()) {
            setMouseDragSensitivity(200);  // Reduced sensitivity for fine control
        } else {
            setMouseDragSensitivity(100);
        }
        juce::Slider::mouseDown(event);
    }

    void mouseDoubleClick(const juce::MouseEvent& event) override {
        // Double-click to reset to default
        setValue(defaultValue);
    }

private:
    double defaultValue = 0.5;
};
```

### Bipolar Knob (Center-Zero)
```cpp
class BipolarKnob : public juce::Slider {
public:
    BipolarKnob() : juce::Slider(juce::Slider::RotaryHorizontalDrag,
                                  juce::Slider::NoTextBox) {
        setRange(-1.0, 1.0, 0.01);
        setValue(0.0);
    }
};

// Custom paint override for visual center indication
void CustomLookAndFeel::drawRotarySlider(juce::Graphics& g,
                                         int x, int y, int width, int height,
                                         float sliderPos, float rotaryStartAngle,
                                         float rotaryEndAngle, juce::Slider& slider) {
    auto radius = juce::jmin(width, height) * 0.45f;
    auto centreX = x + width * 0.5f;
    auto centreY = y + height * 0.5f;

    // Center line for zero position (bipolar center)
    auto centerAngle = rotaryStartAngle + (rotaryEndAngle - rotaryStartAngle) * 0.5f;
    auto cx = centreX + radius * std::cos(centerAngle - juce::MathConstants<float>::pi / 2.0f);
    auto cy = centreY + radius * std::sin(centerAngle - juce::MathConstants<float>::pi / 2.0f);

    g.setColour(juce::Colour(100, 100, 100));
    g.drawLine(centreX, centreY, cx, cy, 2.0f);
}
```

## 6. Reverb-Specific UI Elements

### Decay Visualization (Real-Time RT60)
```cpp
class DecayVisualizer : public juce::Component {
public:
    void updateDecayData(const std::vector<float>& envelopeData) {
        decayEnvelope = envelopeData;
        repaint();
    }

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat();
        g.setColour(juce::Colour(30, 30, 30));
        g.fillRect(bounds);

        // Draw decay curve
        juce::Path decayPath;
        auto sampleWidth = bounds.getWidth() / decayEnvelope.size();

        for (size_t i = 0; i < decayEnvelope.size(); ++i) {
            auto x = bounds.getX() + i * sampleWidth;
            auto y = bounds.getBottom() - (decayEnvelope[i] * bounds.getHeight());

            if (i == 0) decayPath.startNewSubPath(x, y);
            else decayPath.lineTo(x, y);
        }

        g.setColour(juce::Colours::cyan);
        g.strokePath(decayPath, juce::PathStrokeType(1.5f));
    }

private:
    std::vector<float> decayEnvelope;
};
```

### Level Meter with Peak Hold
```cpp
class LevelMeterDisplay : public juce::Component, public juce::Timer {
public:
    void setLevel(float rms, float peak) {
        currentRMS = rms;
        currentPeak = peak;

        // Update peak hold (decay over time)
        if (peak > peakHold) peakHold = peak;

        repaint();
    }

    void timerCallback() override {
        // Decay peak hold slowly
        peakHold *= 0.95f;
        repaint();
    }

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat();

        // RMS level bar
        auto rmsHeight = currentRMS * bounds.getHeight();
        g.setColour(juce::Colours::green);
        g.fillRect(juce::Rectangle<float>(bounds.getX(),
                                         bounds.getBottom() - rmsHeight,
                                         bounds.getWidth(), rmsHeight));

        // Peak hold indicator line
        auto peakY = bounds.getBottom() - (peakHold * bounds.getHeight());
        g.setColour(juce::Colours::red);
        g.drawHorizontalLine(peakY, bounds.getX(), bounds.getRight());
    }

private:
    float currentRMS = 0.0f, currentPeak = 0.0f, peakHold = 0.0f;
};
```

## 7. Responsive & Scalable UI

### DPI-Aware Scaling
```cpp
class DPIAwareEditor : public juce::AudioProcessorEditor {
public:
    void resized() override {
        auto scale = getApproximateScaleFactorForComponent(this);

        auto bounds = getLocalBounds();
        int scaledPadding = juce::roundToInt(20 * scale);

        rotarySlider.setBounds(bounds.reduced(scaledPadding));
    }

    void paint(juce::Graphics& g) override {
        auto displays = juce::Desktop::getInstance().getDisplays();
        auto currentDisplay = displays.getDisplayContaining(getScreenBounds().getCentre());

        auto dpi = currentDisplay.dpi;
        // Adjust font sizes based on DPI
    }
};
```

### Aspect Ratio Locking
```cpp
class AspectRatioComponent : public juce::Component {
public:
    void setAspectRatio(float ratio) { targetRatio = ratio; }

    void resized() override {
        auto bounds = getLocalBounds();
        auto currentRatio = static_cast<float>(bounds.getWidth()) / bounds.getHeight();

        juce::Rectangle<int> constrainedBounds = bounds;
        if (currentRatio > targetRatio) {
            constrainedBounds = bounds.withWidth(
                juce::roundToInt(bounds.getHeight() * targetRatio));
        } else {
            constrainedBounds = bounds.withHeight(
                juce::roundToInt(bounds.getWidth() / targetRatio));
        }

        // Layout children with constrainedBounds
    }

private:
    float targetRatio = 4.0f / 3.0f;
};
```

## 8. Animation & Visual Feedback

### Smooth Parameter Transitions
```cpp
class SmoothedSlider : public juce::Slider {
public:
    SmoothedSlider() : smoothedValue(0.0) {
        startTimer(33);  // ~30fps
    }

    void setValue(double newValue) override {
        targetValue = newValue;
    }

    void timerCallback() override {
        // Smoothly interpolate toward target
        smoothedValue.setTargetValue(targetValue);
        repaint();
    }

    double getSmoothedValue() const { return smoothedValue.getCurrentValue(); }

private:
    juce::SmoothedValue<double> smoothedValue;
    double targetValue = 0.0;
};
```

### Hover State Feedback
```cpp
class HighlightButton : public juce::Button {
public:
    void paint(juce::Graphics& g) override {
        auto colour = isMouseOver() ? juce::Colours::orange : juce::Colours::grey;
        g.setColour(colour);
        g.fillRoundedRectangle(getLocalBounds().toFloat(), 4.0f);

        g.setColour(juce::Colours::white);
        g.drawText(getButtonText(), getLocalBounds(), juce::Justification::centred);
    }
};
```

## 9. Accessibility

### Keyboard Navigation & Screen Reader Support
```cpp
class AccessibleSlider : public juce::Slider {
public:
    AccessibleSlider() {
        getAccessibilityHandler()->setLabel("Room Size (meters)");
        getAccessibilityHandler()->setDescription(
            "Adjust virtual room size from 1 to 50 meters");
    }

    void keyPressed(const juce::KeyPress& key) override {
        if (key == juce::KeyPress::upKey) {
            setValue(getValue() + 0.01);
        } else if (key == juce::KeyPress::downKey) {
            setValue(getValue() - 0.01);
        }
    }
};
```

## 10. UI Performance Optimization

### Repaint Only Dirty Regions
```cpp
void OptimizedComponent::parameterChanged(float newValue) {
    // Repaint only the affected component, not entire editor
    repaint(valueDisplayBounds);
}

// Cache static background images
class CachedBackgroundEditor : public juce::AudioProcessorEditor {
private:
    std::unique_ptr<juce::Image> cachedBackground;

    void createBackgroundImage() {
        cachedBackground = std::make_unique<juce::Image>(
            juce::Image::RGB, getWidth(), getHeight(), true);
        juce::Graphics g(*cachedBackground);
        // Draw gradient, decorative elements once
    }

    void paint(juce::Graphics& g) override {
        g.drawImageAt(*cachedBackground, 0, 0);
    }
};
```

### Profiling with Melatonin Inspector
Enable FPS meter overlay in Melatonin Inspector to profile painting performance. Target: 60fps minimum, <5% CPU for UI rendering.

## 11. Plugin Window Management

### Window Resize Handling & Preferences
```cpp
class ResizeablePluginEditor : public juce::AudioProcessorEditor {
public:
    void resized() override {
        // Store user-preferred size
        auto& properties = getProcessor().getPluginProperties();
        properties.set("editorWidth", getWidth());
        properties.set("editorHeight", getHeight());
    }

    // Restore previous size on launch
    void initialiseSize() {
        auto& properties = getProcessor().getPluginProperties();
        int width = properties.getInt("editorWidth", 800);
        int height = properties.getInt("editorHeight", 600);
        setSize(width, height);
    }
};
```

### Multiple Monitor Support
```cpp
void positionWindowOptimally() {
    auto displays = juce::Desktop::getInstance().getDisplays();
    auto currentDisplay = displays.getPrimaryDisplay();

    auto safeArea = currentDisplay->totalArea;
    auto editorSize = juce::Rectangle<int>(0, 0, 800, 600);

    editorSize.setCentre(safeArea.getCentre());
    topLevelWindow->setBounds(editorSize);
}
```

---

**Key Performance Targets:** Maintain 60fps UI rendering, <5% CPU overhead for UI layer. Use Melatonin Inspector to profile and optimize paint operations. Leverage GPU acceleration (Direct2D/Metal) for complex drawing and effects.

**Documentation:** See Melatonin blog posts on "Dealing with UI jank in JUCE" and "Big list of JUCE tips and tricks" for additional optimization strategies.
