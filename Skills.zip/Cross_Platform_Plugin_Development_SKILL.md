# Cross-Platform Plugin Development & Anti-Patterns SKILL

## 1. The Golden Rules of Real-Time Audio (What NOT to Do)

Based on Ross Bencina "Real-time audio programming 101: time waits for nothing" and Timur Doumler's CppCon/ADC talks:

**NEVER do these in processBlock() / audio callback:**
- Memory allocation (malloc, new, std::vector resize, std::string operations)
- Mutex/lock acquisition (even try_lock on std::mutex is NOT real-time safe)
- File I/O (reading/writing disk, logging, printf, NSLog)
- System calls (any OS API that might block)
- GUI/UI operations (never touch UI from audio thread)
- Network operations
- Throwing exceptions
- Calling third-party code you don't control

**ALWAYS do these instead:**
- Pre-allocate all buffers in prepareToPlay()
- Use lock-free SPSC (single-producer single-consumer) ring buffers for thread communication
- Use std::atomic<float> or std::atomic<int> for simple parameter passing
- Use juce::SmoothedValue for parameter smoothing
- Handle variable buffer sizes gracefully (FL Studio changes buffer mid-session!)
- Flush denormals (set FTZ/DAZ flags on x86)

### Real-Time Anti-Pattern Examples

```cpp
// ❌ BAD: Memory allocation in processBlock
void processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) {
    std::vector<float> temp(buffer.getNumSamples()); // CRASH RISK
    auto* ptr = new float[buffer.getNumSamples()];   // NEVER
}

// ✓ GOOD: Pre-allocate in prepareToPlay
void prepareToPlay(double sampleRate, int maxBlockSize) {
    scratchBuffer.setSize(1, maxBlockSize);
    fftWorkspace.resize(2048);
    delayLine.prepare({sampleRate, (uint32)maxBlockSize, 2});
}

void processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) {
    // Use pre-allocated scratchBuffer
    scratchBuffer.copyFrom(0, 0, buffer, 0, 0, buffer.getNumSamples());
}
```

```cpp
// ❌ BAD: Mutex lock in audio thread
void processBlock(...) {
    std::lock_guard<std::mutex> lock(paramMutex); // BLOCKS!
}

// ✓ GOOD: Lock-free atomic parameter
std::atomic<float> filterFreq{440.0f};

void processBlock(...) {
    float freq = filterFreq.load(std::memory_order_relaxed);
    // No lock, no blocking, no problem
}
```

```cpp
// ❌ BAD: String operation in audio thread
void processBlock(...) {
    juce::String debug = "Processing " + juce::String(blockSize);
}

// ✓ GOOD: Defer to message thread
void processBlock(...) {
    // Audio thread: write to SPSC queue
    debugQueue.push(blockSize);
}
// Message thread: consume queue and log
```

## 2. FL Studio Specific Compatibility

FL Studio (Image-Line) has unique behaviors JUCE developers MUST handle:

**Variable Buffer Size**: FL Studio changes buffer sizes mid-session by default (16 → 512 → 4096 in a single session). Always pre-allocate for maximum buffer size in prepareToPlay(), never assume fixed block size. Test with "Use fixed buffer size" both ON and OFF in FL settings.

**Keyboard Focus Bug**: VST3 plugins in FL Studio don't pass spacebar/transport keys back to DAW. Returning false from keyPressed() doesn't work in FL Studio like Ableton. Workaround:

```cpp
bool keyPressed(const juce::KeyPress& key) {
    if (auto* pht = dynamic_cast<juce::AudioProcessor*>(this)) {
        auto hostType = juce::PluginHostType::getPluginHostPathFor(pht);
        if (hostType.contains("FL")) {
            // FL Studio: implement custom transport handling
            return true; // Consume key to prevent DAW access
        }
    }
    return false; // Other DAWs: return false to let DAW handle transport
}
```

**Plugin Scanning Issues**: FL Studio can struggle scanning certain VST3 files. Ensure correct VST3 bundle structure on macOS, proper COM registration on Windows, and clean binary exports.

**VST2/VST3 Mixing**: FL Studio finds both formats but doesn't always combine them. Developers may need both installed for backward compatibility during transition period.

**FL Studio Plugin Standards**: Supports VST 1/2, VST3, CLAP, and FL Native format. On macOS also supports AU.

**CLAP in FL Studio**: FL Studio was among first DAWs adopting CLAP. Worth targeting if audience includes FL users.

## 3. DAW-Specific Quirks Checklist

| DAW | Key Quirks | Testing Priority |
|-----|-----------|-----------------|
| FL Studio | Variable buffer size, keyboard focus, VST3 scanning | Critical |
| Pro Tools | AAX only (needs PACE/iLok), offline bounce timing | For AAX targets |
| Logic Pro | AU required, strict auval validation, sandbox | macOS essential |
| Ableton Live | Session View transport, Max for Live interaction | High |
| Cubase/Nuendo | VST3 note expression, strict parameter ID stability | VST3 critical |
| Reaper | Very permissive, excellent testing host, all formats | All platforms |
| Bitwig | CLAP flagship, sandbox mode, modulation system | CLAP priority |
| Studio One | VST3 focus, drag-and-drop integration, PreSonus API | VST3/Windows |

**PluginHostType Detection Example:**
```cpp
void prepareToPlay(double sampleRate, int maxBlockSize) {
    auto hostType = juce::PluginHostType();

    if (hostType.isProTools())
        // Implement AAX-specific timing
    else if (hostType.isLogic())
        // Use AU-specific features
    else if (hostType.isFLStudio())
        // Use maximum buffer size, handle variable sizing
    else if (hostType.isCubase() || hostType.isNuendo())
        // VST3 note expression handling
}
```

## 4. Cross-Platform Build & Deployment

**CMake Best Practices:**
- Use Pamplejuce template as foundation (JUCE 8, Catch2, Pluginval, GitHub Actions CI)
- juce_add_plugin() with all format targets (VST3, AU, AAX, CLAP)
- Separate Debug/Release configurations
- Enable address sanitizer in Debug builds

**Platform-Specific Issues:**

**macOS**: Apple Silicon (arm64) + Intel (x86_64) universal binaries required. Code signing and notarization mandatory. Hardened Runtime entitlements needed for VST3.

```cmake
juce_add_plugin(MyPlugin
    FORMATS VST3 AU CLAP
    COPY_PLUGIN_AFTER_BUILD TRUE
)

# Universal binary on macOS
set_target_properties(MyPlugin PROPERTIES
    OSX_ARCHITECTURES "arm64;x86_64"
)
```

**Windows**: EV code signing required since June 2023. Azure Trusted Signing for CI/CD. Distribute via InnoSetup installer.

**Linux**: Growing but less common. Package for .deb/.rpm. Test on Ubuntu 20.04+ and Fedora. VST3 and CLAP are primary targets.

**Compiler Differences:**
- Clang (macOS/Linux) vs MSVC (Windows): different warnings, optimization behaviors
- Use `-Wall -Wextra -Werror` everywhere
- MSVC: `/W4 /permissive-` catches C++ standard violations
- Denormal handling differs: set FTZ/DAZ flags explicitly on x86
- Ensure bit-identical DSP across compilers using deterministic algorithms

## 5. Essential Developer Resources & International Research

**Foundational Textbooks (International):**
- Udo Zölzer (German, Hamburg): "DAFX: Digital Audio Effects" - comprehensive reference, 2nd ed. Wiley
- Julius O. Smith III (Stanford CCRMA): "Physical Audio Signal Processing", free online
- Vesa Välimäki (Finnish, Aalto University): Fractional delay filters, reverb design
- Davide Rocchesso (Italian): "Introduction to Sound Processing", DAFx contributor

**Key Conference Archives (All Open Access):**
- DAFx (dafx.de) - International Conference on Digital Audio Effects, all papers open access
- AES (aes.org) - Audio Engineering Society journal and convention papers
- ICMC - International Computer Music Conference
- SMC - Sound and Music Computing
- ISMIR - International Society for Music Information Retrieval

**Expert Blogs & Resources:**
- Sean Costello / Valhalla DSP blog (psychoacoustic reverb design)
- Signalsmith Audio blog (modern reverb, DSP techniques)
- Melatonin.dev / Sudara (JUCE tips, Pamplejuce, Inspector, Blur)
- timur.audio / Timur Doumler (C++ real-time, lock-free programming)
- Ross Bencina (real-time audio fundamentals)
- Jatin Chowdhury / ChowDSP (open-source plugins, RTNeural, WDF)
- The Wolfsound / Jan Wilczek (JUCE tutorials, DSP fundamentals)
- audiodev.blog (beginner resources)
- awesome-juce (GitHub, nightly-updated curated list)
- awesome-musicdsp (GitHub, Oliver Larkin)

**Open Source Plugin References:**
- Chowdhury DSP (ChowTapeModel, BYOD, ChowMatrix) - exemplary C++ architecture
- Surge Synthesizer - large-scale synth with excellent design
- Vital by Matt Tytel - wavetable synth, polished UI
- Airwindows by Chris Johnson - hundreds of minimal DSP plugins
- Dexed, OB-Xd - classic instrument recreations

## 6. Memory Management Patterns

**Pre-allocation Pattern:**
```cpp
void prepareToPlay(double sampleRate, int maxBlockSize) {
    // Allocate EVERYTHING here, NEVER in processBlock
    scratchBuffer.setSize(2, maxBlockSize);
    fftWorkspace.resize(fftSize);
    delayLine.prepare({sampleRate, (uint32)maxBlockSize, 2});

    // Pre-allocate parameter update queue
    paramQueue.setSize(1024);
}

void releaseResources() {
    scratchBuffer.clear();
    fftWorkspace.clear();
    delayLine.reset();
}
```

**Lock-Free Parameter Update (SPSC):**
```cpp
class ParameterQueue {
    juce::AbstractFifo fifo{1024};
    struct Update { int paramID; float value; };
    std::array<Update, 1024> queue;

public:
    void push(int id, float val) {  // Message thread
        int start = 0, blockSize = 1;
        if (fifo.prepareToWrite(blockSize) > 0) {
            queue[fifo.getWritePointer()] = {id, val};
            fifo.finishedWrite(1);
        }
    }

    void process() {  // Audio thread - lock-free!
        int start = 0, blockSize = 1;
        while (fifo.prepareToRead(blockSize) > 0) {
            auto [id, val] = queue[fifo.getReadPointer()];
            updateParameter(id, val);
            fifo.finishedRead(1);
        }
    }
};
```

**Atomic Parameter Pattern:**
```cpp
std::atomic<float> filterFreq{440.0f};
std::atomic<int> algorithm{0};

void processBlock(...) {
    float freq = filterFreq.load(std::memory_order_relaxed);
    int algo = algorithm.load(std::memory_order_acquire);
    // No blocking, no allocation, real-time safe
}
```

## 7. Common C++ Anti-Patterns in Audio

**❌ std::function in audio path (may allocate):**
```cpp
void processBlock(...) {
    std::function<void(float)> processor = someAlgorithm; // STACK ALLOCATION
    applyProcessor(buffer, processor);
}
```

**✓ Use function pointers or direct function calls:**
```cpp
void processBlock(...) {
    applyProcessor(buffer, &SomeClass::staticMethod); // Zero overhead
}
```

**❌ std::shared_ptr in audio path (atomic refcount):**
```cpp
void processBlock(...) {
    auto data = std::make_shared<Buffer>(...); // Atomic increment = slow!
}
```

**✓ Use raw pointers with pre-allocated ownership:**
```cpp
std::unique_ptr<Buffer> data; // Pre-allocated

void prepareToPlay(...) {
    data = std::make_unique<Buffer>(...);
}

void processBlock(...) {
    processData(*data); // Raw pointer, zero overhead
}
```

**❌ Virtual function calls in tight DSP loops (branch prediction penalty):**
```cpp
void processBlock(...) {
    for (int i = 0; i < numSamples; ++i) {
        out[i] = filter->process(in[i]); // Branch prediction misses every iteration
    }
}
```

**✓ Use template specialization or direct function calls:**
```cpp
template <typename FilterType>
void processBlock(...) {
    FilterType filter = ...;
    for (int i = 0; i < numSamples; ++i) {
        out[i] = filter.process(in[i]); // Inlined, no virtual dispatch
    }
}
```

**❌ String operations in processBlock:**
```cpp
void processBlock(...) {
    juce::String log = "Sample: " + juce::String(buffer[0]);
    // Multiple allocations, non-deterministic time
}
```

**✓ Defer to message thread:**
```cpp
juce::AbstractFifo logQueue{4096};

void processBlock(...) {
    logQueue.push(buffer[0]); // Lock-free write
}

void timerCallback() {
    while (auto val = logQueue.pop()) {
        DBG("Sample: " << *val);
    }
}
```

**❌ Throwing exceptions in processBlock (unbounded unwinding time):**
```cpp
void processBlock(...) {
    if (badCondition) throw std::runtime_error("..."); // Stack unwinding = variable time
}
```

**✓ Return error codes, handle off audio thread:**
```cpp
bool errorOccurred{false};

void processBlock(...) {
    if (badCondition) errorOccurred = true; // Atomic flag, constant time
    if (errorOccurred) return; // Skip processing
}
```

## 8. Testing Across Platforms

**CI Matrix (All Platforms):**
```yaml
# GitHub Actions matrix
strategy:
  matrix:
    os: [ubuntu-latest, macos-latest, windows-latest]
    arch: ['x64', 'arm64']  # arm64 on macOS only
    config: [Debug, Release]
```

**Testing Checklist:**
- Run Pluginval strictness 5+ on all platforms
- Catch2 unit tests for DSP correctness (deterministic seeds)
- Verify bit-exact output across platforms OR document acceptable deviation
- Test sample rates: 44.1, 48, 88.2, 96, 192 kHz
- Test buffer sizes: 32, 64, 256, 512, 2048, 4096
- Memory sanitizers: AddressSanitizer, ThreadSanitizer in Debug builds
- FL Studio: Test with variable buffer size enabled/disabled
- macOS: Verify universal binary with `lipo -info PluginName.vst3`

**Memory Safety Testing:**
```bash
# Linux/macOS
cmake -B build -DCMAKE_CXX_FLAGS="-fsanitize=address,undefined"

# Windows
# Enable AddressSanitizer in Visual Studio project settings
```

**Pluginval Integration:**
```bash
pluginval --validate "path/to/plugin.vst3" --strictness-level 5 --verbose
```

---

**Last Updated:** 2026-02-28
**Focus:** Production-ready cross-platform plugin development with emphasis on real-time safety, FL Studio compatibility, and international research standards.
