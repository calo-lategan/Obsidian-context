# Audio Plugin Testing & Quality Assurance SKILL

## 1. Pluginval - Cross-Platform Validation

Tracktion's **pluginval** is an open-source tool that validates plugins as a DAW would. It loads plugins in isolation, testing stability and compliance with plugin specifications.

**Key Features:**
- Strictness levels 1-10 (10 = most rigorous)
- Command-line headless mode for CI integration
- Tests: state save/restore, sample rate/block size switching, audio thread memory allocation detection
- Minimal dependencies, fast feedback loop

**Running pluginval in CI:**
```bash
./pluginval --strictness 10 --validate /path/to/plugin.vst3
./pluginval --strictness 10 --verbose /path/to/plugin.au
```

**CMake Integration for Debugging:**
```cmake
add_custom_target(validate_plugin
  COMMAND pluginval --strictness 10 --validate ${PLUGIN_PATH}
  DEPENDS ${TARGET_NAME}
  COMMENT "Running pluginval validation..."
)
```

Run pluginval on macOS (AU, VST3), Windows (VST3, AAX), and Linux (VST3) in CI pipeline. Treat validation failures as blocking.

---

## 2. Unit Testing with Catch2

Catch2 integrates seamlessly with JUCE for DSP processor testing. Custom audio buffer matchers and frequency-domain comparators enable precise validation.

**JUCE + Catch2 Integration:**
```cpp
// tests/ProcessorTest.cpp
#include <juce_audio_processors/juce_audio_processors.h>
#include <catch2/catch_all.hpp>

// Custom JUCE initialization for tests
class JuceTestEnvironment {
public:
    JuceTestEnvironment() {
        juce::initialiseJuce_GUI();
    }
    ~JuceTestEnvironment() {
        juce::shutdownJuce_GUI();
    }
};

static JuceTestEnvironment juce_env;

TEST_CASE("AudioProcessor Name", "[processor]") {
    auto processor = std::make_unique<YourAudioProcessor>();
    REQUIRE(processor->getName() == "Your Plugin Name");
}

TEST_CASE("Bus Layout Support", "[processor]") {
    auto processor = std::make_unique<YourAudioProcessor>();
    juce::AudioChannelSet stereo = juce::AudioChannelSet::stereo();
    REQUIRE(processor->isBusesLayoutSupported({stereo, stereo}));
}
```

**Audio Buffer Matcher for DSP Testing:**
```cpp
TEST_CASE("DSP Processing Correctness", "[dsp]") {
    YourDSPProcessor dsp;
    juce::AudioBuffer<float> input(2, 512);
    juce::AudioBuffer<float> output(2, 512);

    // Fill input with test signal
    for (int ch = 0; ch < 2; ++ch) {
        for (int i = 0; i < 512; ++i) {
            input.setSample(ch, i, std::sin(2.0f * M_PI * i / 512.0f));
        }
    }

    dsp.process(input, output);

    // Verify peak level doesn't exceed expected range
    float max_level = output.getRMSLevel(0, 0, 512);
    REQUIRE(max_level > 0.0f);
    REQUIRE(max_level < 1.5f);
}
```

**Benchmark Macros:**
```cpp
TEST_CASE("Performance: Filter Processing", "[benchmark]") {
    YourFilter filter;
    juce::AudioBuffer<float> buffer(2, 4096);
    buffer.clear();

    auto start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < 1000; ++i) {
        filter.process(buffer);
    }
    auto end = std::chrono::high_resolution_clock::now();

    auto duration_ms = std::chrono::duration<double, std::milli>(end - start).count();
    REQUIRE(duration_ms < 100.0); // Should complete 1000 iterations in <100ms
}
```

**CMake Configuration (Pamplejuce template):**
```cmake
include(FetchContent)
FetchContent_Declare(catch2 URL https://github.com/catchorg/Catch2/archive/refs/tags/v3.4.0.tar.gz)
FetchContent_MakeAvailable(catch2)

add_executable(PluginTests tests/ProcessorTest.cpp)
target_link_libraries(PluginTests PRIVATE catch2_with_main juce::juce_audio_processors)
add_test(NAME PluginTests COMMAND PluginTests)
```

---

## 3. CI/CD Pipeline (GitHub Actions + Pamplejuce)

Automate cross-platform builds, validation, and installer creation.

**GitHub Actions Workflow (macOS/Windows/Linux):**
```yaml
# .github/workflows/build.yml
name: Build & Test

on: [push, pull_request]

jobs:
  build:
    strategy:
      matrix:
        os: [macos-latest, windows-latest, ubuntu-latest]
    runs-on: ${{ matrix.os }}
    steps:
      - uses: actions/checkout@v3
        with:
          submodules: recursive

      - name: Build Plugin
        run: |
          cmake -B build -DCMAKE_BUILD_TYPE=Release
          cmake --build build --config Release

      - name: Run Tests
        run: |
          cmake --build build --target PluginTests
          ./build/bin/PluginTests

      - name: Validate with pluginval
        run: |
          pluginval --strictness 10 --validate ./build/bin/YourPlugin.vst3

      - name: Upload Artifacts
        uses: actions/upload-artifact@v3
        with:
          name: plugin-${{ matrix.os }}
          path: build/bin/
```

**macOS Code Signing & Notarization:**
```bash
# Sign plugin
codesign --deep --force --verify --verbose --timestamp --options=runtime \
  --entitlements entitlements.plist \
  --sign "Developer ID Application: Company Name (TEAM_ID)" \
  YourPlugin.vst3

# Notarize
xcrun notarytool submit YourPlugin.zip \
  --apple-id your-email@apple.com \
  --team-id TEAM_ID \
  --password app-specific-password \
  --wait

# Verify
spctl -a -v -t install YourPlugin.vst3
```

**Windows EV Code Signing (Azure Trusted Signing):**
```bash
# Requires EV certificate since June 2023
# Use Azure Trusted Signing for CI
azureSignTool sign --file-digest sha256 \
  --timestamp-rfc3161 http://timestamp.globalsign.com/tsa/tsr \
  --endpoint https://eus.codesigning.azure.net/ \
  --identity-server-url https://eus.codesigning.azure.net/ \
  --certificate-profile YourCertProfile \
  YourPlugin.vst3
```

**Installer Creation:**
- **Windows:** InnoSetup (pre-installed on GitHub Actions)
- **macOS:** Packages or create .dmg with code-signed .pkg

---

## 4. Perceptual Audio Evaluation

Subjective testing validates that processing sounds natural and transparent.

**MUSHRA (ITU-R BS.1534):**
- Multiple Stimuli with Hidden Reference and Anchor
- Ideal for intermediate quality assessment
- Listeners rate samples on 0-100 scale relative to reference
- Web-based implementation via webMUSHRA

**webMUSHRA Framework:**
```json
{
  "testname": "Plugin Quality Assessment",
  "rating": "MUSHRA",
  "stimuli": [
    {
      "id": "reference",
      "url": "audio/reference.wav",
      "label": "Reference"
    },
    {
      "id": "anchor_low",
      "url": "audio/anchor_low.wav",
      "label": "Anchor (Low Quality)"
    },
    {
      "id": "plugin_v1",
      "url": "audio/plugin_processed.wav",
      "label": "Plugin Version 1"
    }
  ]
}
```

**A/B and ABX Blind Testing:**
- Eliminates confirmation bias, brand bias, price bias
- ABX: A/B comparison with hidden third sample (A, B, or X)
- Use Blind VST tool for real-time plugin evaluation during mixing
- Loudness match with MeterPlugs Perception AB (prevents loudness deception)

**Listening Test Protocol:**
1. Calibrate playback level to 85dB SPL
2. Use reference-grade headphones or treated monitoring
3. Test in 15-20 minute sessions (listener fatigue after 20 min)
4. Compare at least 20 listeners for statistical significance
5. Document anchor levels (low quality sample for calibration)

---

## 5. Audio Quality Metrics

Objective measurements validate plugin output against specifications.

**RT60 Measurement (Reverb Plugins):**
```python
import numpy as np
from scipy import signal

def measure_rt60(impulse_response, sample_rate):
    """Schroeder backwards integration method"""
    ir = np.array(impulse_response)
    power = ir ** 2

    # Backwards cumulative sum
    energy = np.flip(np.cumsum(np.flip(power)))
    energy_db = 10 * np.log10(energy / np.max(energy))

    # Find -60dB point
    indices = np.where(energy_db < -60)[0]
    if len(indices) > 0:
        rt60_samples = indices[0]
        rt60_seconds = rt60_samples / sample_rate
        return rt60_seconds
    return None
```

**C80 (Clarity Index):**
```
C80 = 10 * log10(E_early / E_late)
where:
  E_early = energy from 0-80ms
  E_late = energy after 80ms
```
Higher C80 = more intelligible/clear (useful for speech plugins).

**IACC (InterAural Cross-Correlation):**
- Measures spatial width in binaural recordings
- IACC_Early (0-80ms): Apparent Source Width (ASW)
- IACC_Late (>80ms): Listener Envelopment (LEV)

**Spectral Analysis:**
- FFT-based frequency response analysis
- Spectrogram visualization for time-frequency behavior
- Waterfall plots for resonance/ringing detection
- Use Room EQ Wizard (REW) for acoustic measurements

**Essential Metrics:**
- SNR (Signal-to-Noise Ratio): >100dB for digital plugins
- THD (Total Harmonic Distortion): <0.01% for linear plugins
- Dynamic Range: peak signal - noise floor

---

## 6. Automated Testing Strategies

**Deterministic Tests:**
```cpp
TEST_CASE("Deterministic Output", "[dsp]") {
    YourProcessor proc;
    juce::AudioBuffer<float> input(1, 1024);
    juce::AudioBuffer<float> output(1, 1024);

    // Fixed input → expected output
    input.clear();
    input.setSample(0, 0, 1.0f); // Impulse

    proc.process(input, output);

    // Compare against golden file
    auto expected = loadGoldenFile("impulse_response_44k.wav");
    REQUIRE(buffersMatchWithinTolerance(output, expected, 1e-6f));
}
```

**Regression Testing (Golden File Snapshots):**
```cpp
TEST_CASE("Regression: Filter Frequency Response", "[regression]") {
    YourFilter filter;
    filter.setFrequency(1000.0f);

    // Compare against baseline
    compareAgainstSnapshot("filter_1khz_response.wav",
                          processTestSignal(filter));
}
```

**Fuzz Testing:**
```cpp
TEST_CASE("Fuzz: Random Automation", "[fuzz]") {
    YourProcessor proc;
    juce::Random rng(12345);

    for (int iteration = 0; iteration < 1000; ++iteration) {
        // Random parameters
        float param_value = rng.nextFloat();
        proc.setParameter("Cutoff", param_value);

        // Random buffer size (32-2048 samples)
        int block_size = rng.nextInt({32, 2048});

        // Should never crash or assert
        juce::AudioBuffer<float> buffer(2, block_size);
        buffer.clear();
        REQUIRE_NOTHROW(proc.processBlock(buffer, ...));
    }
}
```

**Stress Testing:**
- Extreme parameter values (0%, 100%, rapid sweeps)
- Rapid preset switching every 1-10 ms
- High CPU load (multiple instances)
- Monitor for crashes, hangs, or audio glitches

**Memory Safety:**
- **Valgrind** (Linux): Detect memory leaks, invalid accesses
- **AddressSanitizer** (ASAN): Compile with `-fsanitize=address`
- **ThreadSanitizer** (TSAN): Race condition detection
- **Real-time Thread Checker:** Use JUCE's AudioProcessor to detect audio thread allocations

---

## 7. DAW Compatibility Testing

Test on all major DAWs to ensure compatibility.

**Priority DAWs:**
1. Pro Tools (AAX format) - Industry standard
2. Logic Pro (AU) - macOS ecosystem
3. Ableton Live - Electronic/production workflows
4. Cubase/Nuendo (VST3) - Professional audio workstations
5. Reaper - Feature-rich independent DAW
6. FL Studio, Studio One, Bitwig

**Format-Specific Quirks:**
- **AAX:** Requires iLok/PACE wrapping via Eden SDK
- **AU:** Validate with `auval -v -vv PluginName`
- **VST3:** JUCE automatically handles most compatibility

**Test Scenarios (per DAW):**
```
[ ] Insert on track (mono, stereo)
[ ] Bypass toggle (audio shouldn't click)
[ ] Automation recording and playback
[ ] Session save/reload (state preservation)
[ ] Offline bounce/export
[ ] Sidechain routing (if applicable)
[ ] MIDI note-on/off handling (for synths)
[ ] Sample rate switching (44.1→96kHz mid-session)
[ ] Buffer size changes (32→2048 samples)
[ ] CPU meter stability
[ ] GUI responsiveness (no audio dropouts)
```

**Sample Rates to Test:** 44.1, 48, 88.2, 96, 176.4, 192 kHz
**Buffer Sizes:** 32, 64, 128, 256, 512, 1024, 2048 samples

---

## 8. Installer & Distribution Testing

**macOS Distribution:**
```bash
# Create universal binary (Intel + Apple Silicon)
lipo -create x86_64.vst3 arm64.vst3 -output universal.vst3

# Create .pkg installer
pkgbuild --component universal.vst3 \
  --install-location "/Library/Audio/Plug-Ins/VST3" \
  --scripts scripts/ \
  YourPlugin.pkg

# Test notarization
spctl -a -v -t install YourPlugin.pkg

# Verify code signature
codesign --verify --verbose YourPlugin.vst3
```

**Windows Distribution:**
```bash
# Create InnoSetup installer (pre-installed on GitHub Actions)
iscc YourPlugin.iss

# Verify code signature
signtool verify /pa /v YourPlugin.exe

# Test on clean VM (check registry, file placement)
# Installer should place files in:
#   C:\Program Files\Common Files\VST3\
#   HKEY_LOCAL_MACHINE\SOFTWARE\VST (if applicable)
```

**Uninstallation Testing:**
- Verify complete removal of all plugin files
- Check registry is clean (Windows)
- Verify plugin no longer loads in DAW

**AAX Distribution:**
- Wrap with iLok Eden SDK (PACE wrapping)
- Test on Pro Tools with iLok authorization
- Verify ilok.key file is generated correctly

---

## 9. Performance Profiling

**CPU Usage Monitoring (JUCE):**
```cpp
class PerformanceMonitor : public juce::AudioProcessor {
    void processBlock(juce::AudioBuffer<float>& buffer,
                     juce::MidiBuffer& midi) override {
        auto t0 = juce::Time::getHighResolutionTicks();

        // Your processing here
        performProcessing(buffer, midi);

        auto t1 = juce::Time::getHighResolutionTicks();
        auto elapsed_ms = juce::Time::highResolutionTicksToSeconds(t1 - t0) * 1000.0;

        cpu_usage_percent = (elapsed_ms / block_duration_ms) * 100.0;
    }

private:
    double cpu_usage_percent = 0.0;
};
```

**Real-Time Safety Checklist:**
- [ ] No `new` / `malloc` in audio thread
- [ ] No locks (spinlocks, mutexes) in audio thread
- [ ] No I/O operations (file, network) in audio thread
- [ ] No blocking calls to other threads
- [ ] Use lock-free FIFO for cross-thread communication

**Profiling Tools:**
- **macOS:** Instruments (Xcode > Open Developer Tool > Instruments)
- **Windows:** VTune (Intel), Windows Performance Analyzer
- **Linux:** `perf`, `flamegraph`

**Target Performance:**
- Single plugin instance at 44.1kHz / 512 buffer: **<5% CPU**
- 8 instances: **<40% single core**
- Monitor sustained (not just first block)

---

## Summary Checklist for Commercial Release

- [ ] pluginval validation passes at strictness level 10
- [ ] Unit tests pass (Catch2 with >80% code coverage)
- [ ] Regression test baseline established
- [ ] Perceptual tests complete (MUSHRA with 20+ listeners)
- [ ] Audio quality metrics verified
- [ ] Tested on: Pro Tools, Logic, Cubase, Reaper, Ableton
- [ ] All sample rates (44.1-192kHz) working
- [ ] All buffer sizes (32-2048) stable
- [ ] Code signed and notarized (macOS)
- [ ] EV code signed (Windows)
- [ ] CPU usage <5% single instance
- [ ] No memory leaks (Valgrind/ASAN clean)
- [ ] Installer tested on clean systems
- [ ] Uninstallation clean and complete

**Reference Tools:**
- Pluginval: https://github.com/Tracktion/pluginval
- Catch2: https://github.com/catchorg/Catch2
- Pamplejuce: https://github.com/sudara/pamplejuce
- webMUSHRA: https://github.com/audiolabs/webMUSHRA
- Room EQ Wizard: https://www.roomeqwizard.com/
